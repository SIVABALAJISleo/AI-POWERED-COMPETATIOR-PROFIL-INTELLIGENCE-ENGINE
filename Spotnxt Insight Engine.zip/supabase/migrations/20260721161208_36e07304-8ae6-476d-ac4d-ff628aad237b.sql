
-- 1. Retention setting on organizations
ALTER TABLE public.organizations
  ADD COLUMN IF NOT EXISTS export_retention_days INT NOT NULL DEFAULT 30
  CHECK (export_retention_days BETWEEN 1 AND 365);

-- 2. In-app notifications
CREATE TABLE IF NOT EXISTS public.notifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  org_id UUID REFERENCES public.organizations(id) ON DELETE CASCADE,
  kind TEXT NOT NULL,
  title TEXT NOT NULL,
  body TEXT,
  target_type TEXT,
  target_id UUID,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  read_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.notifications TO authenticated;
GRANT ALL ON public.notifications TO service_role;

ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "own notifications read"
  ON public.notifications FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "own notifications update"
  ON public.notifications FOR UPDATE
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "own notifications delete"
  ON public.notifications FOR DELETE
  USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_notifications_user_created
  ON public.notifications (user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_notifications_user_unread
  ON public.notifications (user_id, read_at) WHERE read_at IS NULL;

-- Realtime
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime' AND schemaname = 'public' AND tablename = 'notifications'
  ) THEN
    EXECUTE 'ALTER PUBLICATION supabase_realtime ADD TABLE public.notifications';
  END IF;
END $$;

-- 3. Tighten export access via RLS. Drop legacy permissive policies first if any.
DO $$
DECLARE p RECORD;
BEGIN
  FOR p IN SELECT policyname FROM pg_policies WHERE schemaname='public' AND tablename='exports'
  LOOP
    EXECUTE format('DROP POLICY %I ON public.exports', p.policyname);
  END LOOP;
END $$;

-- Any workspace member may see export rows for their orgs (history browsing).
CREATE POLICY "members read exports"
  ON public.exports FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.organization_members m
      WHERE m.org_id = exports.org_id AND m.user_id = auth.uid()
    )
  );

-- Insert/update permissions kept for service role only via authenticated? Server functions
-- use supabaseAdmin for the actual writes, but we also allow the requester to insert.
CREATE POLICY "members enqueue exports"
  ON public.exports FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.organization_members m
      WHERE m.org_id = exports.org_id AND m.user_id = auth.uid()
    )
  );

-- 4. Purge function: null the artifact and mark rows expired past retention.
CREATE OR REPLACE FUNCTION public.purge_expired_exports()
RETURNS INT
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  affected INT;
BEGIN
  UPDATE public.exports e
     SET artifact = NULL,
         status = 'expired',
         updated_at = now()
    FROM public.organizations o
   WHERE e.org_id = o.id
     AND e.artifact IS NOT NULL
     AND e.status = 'done'
     AND e.completed_at IS NOT NULL
     AND e.completed_at < now() - make_interval(days => o.export_retention_days);
  GET DIAGNOSTICS affected = ROW_COUNT;
  RETURN affected;
END $$;

REVOKE ALL ON FUNCTION public.purge_expired_exports() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.purge_expired_exports() TO service_role;
