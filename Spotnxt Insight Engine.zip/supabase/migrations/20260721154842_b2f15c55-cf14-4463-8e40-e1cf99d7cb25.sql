
CREATE OR REPLACE FUNCTION public.set_updated_at() RETURNS TRIGGER
LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;

CREATE TABLE public.ingest_quarantine (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  competitor_id UUID NOT NULL REFERENCES public.competitors(id) ON DELETE CASCADE,
  submitted_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  source TEXT NOT NULL,
  batch_id UUID,
  row_index INT,
  raw JSONB NOT NULL,
  issues JSONB NOT NULL DEFAULT '[]'::jsonb,
  status TEXT NOT NULL DEFAULT 'pending',
  resolved_at TIMESTAMPTZ,
  resolved_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ingest_quarantine_org_status_idx ON public.ingest_quarantine(org_id, status, created_at DESC);
CREATE INDEX ingest_quarantine_competitor_idx ON public.ingest_quarantine(competitor_id, status, created_at DESC);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.ingest_quarantine TO authenticated;
GRANT ALL ON public.ingest_quarantine TO service_role;

ALTER TABLE public.ingest_quarantine ENABLE ROW LEVEL SECURITY;

CREATE POLICY "quarantine_select_member" ON public.ingest_quarantine
  FOR SELECT TO authenticated
  USING (internal.is_member(org_id, auth.uid()));
CREATE POLICY "quarantine_insert_writer" ON public.ingest_quarantine
  FOR INSERT TO authenticated
  WITH CHECK (internal.is_member(org_id, auth.uid()));
CREATE POLICY "quarantine_update_writer" ON public.ingest_quarantine
  FOR UPDATE TO authenticated
  USING (internal.is_member(org_id, auth.uid()))
  WITH CHECK (internal.is_member(org_id, auth.uid()));
CREATE POLICY "quarantine_delete_writer" ON public.ingest_quarantine
  FOR DELETE TO authenticated
  USING (internal.is_member(org_id, auth.uid()));

CREATE TRIGGER ingest_quarantine_updated_at
  BEFORE UPDATE ON public.ingest_quarantine
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

ALTER PUBLICATION supabase_realtime ADD TABLE public.ingest_quarantine;
