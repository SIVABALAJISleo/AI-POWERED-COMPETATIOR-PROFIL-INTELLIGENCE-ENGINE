
-- Broaden audit_events visibility to all org members (was admin only)
DROP POLICY IF EXISTS audit_read ON public.audit_events;
CREATE POLICY audit_read ON public.audit_events
  FOR SELECT TO authenticated
  USING (internal.is_member(auth.uid(), org_id));

-- Allow org members to read jobs scoped to their org (via payload->>org_id)
CREATE POLICY jobs_read_members ON public.jobs
  FOR SELECT TO authenticated
  USING (
    internal.is_member(
      auth.uid(),
      NULLIF(payload->>'org_id','')::uuid
    )
  );
GRANT SELECT ON public.jobs TO authenticated;

-- Enable realtime streams
ALTER TABLE public.jobs REPLICA IDENTITY FULL;
ALTER TABLE public.audit_events REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.jobs;
ALTER PUBLICATION supabase_realtime ADD TABLE public.audit_events;
