
CREATE SCHEMA IF NOT EXISTS internal;

CREATE OR REPLACE FUNCTION internal.is_member(_user UUID, _org UUID)
RETURNS BOOLEAN LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.organization_members WHERE user_id = _user AND org_id = _org)
$$;

CREATE OR REPLACE FUNCTION internal.has_role(_user UUID, _org UUID, _min public.app_role)
RETURNS BOOLEAN LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.organization_members m
    WHERE m.user_id = _user AND m.org_id = _org
      AND CASE _min
        WHEN 'viewer'  THEN m.role IN ('viewer','analyst','admin','owner')
        WHEN 'analyst' THEN m.role IN ('analyst','admin','owner')
        WHEN 'admin'   THEN m.role IN ('admin','owner')
        WHEN 'owner'   THEN m.role = 'owner'
      END
  )
$$;

REVOKE ALL ON FUNCTION internal.is_member(UUID, UUID) FROM PUBLIC;
REVOKE ALL ON FUNCTION internal.has_role(UUID, UUID, public.app_role) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION internal.is_member(UUID, UUID) TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION internal.has_role(UUID, UUID, public.app_role) TO authenticated, service_role;
GRANT USAGE ON SCHEMA internal TO authenticated, service_role;

-- Rewrite every policy to use internal.* helpers, then drop the public helpers.

-- organizations
DROP POLICY IF EXISTS "org_member_read" ON public.organizations;
DROP POLICY IF EXISTS "org_owner_update" ON public.organizations;
CREATE POLICY "org_member_read" ON public.organizations FOR SELECT TO authenticated
  USING (internal.is_member(auth.uid(), id));
CREATE POLICY "org_owner_update" ON public.organizations FOR UPDATE TO authenticated
  USING (internal.has_role(auth.uid(), id, 'admin')) WITH CHECK (internal.has_role(auth.uid(), id, 'admin'));

-- organization_members
DROP POLICY IF EXISTS "member_read_own_org" ON public.organization_members;
DROP POLICY IF EXISTS "member_self_insert" ON public.organization_members;
DROP POLICY IF EXISTS "member_admin_write" ON public.organization_members;
CREATE POLICY "member_read_own_org" ON public.organization_members FOR SELECT TO authenticated
  USING (internal.is_member(auth.uid(), org_id));
CREATE POLICY "member_self_insert" ON public.organization_members FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid());
CREATE POLICY "member_admin_write" ON public.organization_members FOR ALL TO authenticated
  USING (internal.has_role(auth.uid(), org_id, 'admin'))
  WITH CHECK (internal.has_role(auth.uid(), org_id, 'admin'));

-- competitors
DROP POLICY IF EXISTS "comp_read" ON public.competitors;
DROP POLICY IF EXISTS "comp_write" ON public.competitors;
CREATE POLICY "comp_read" ON public.competitors FOR SELECT TO authenticated USING (internal.is_member(auth.uid(), org_id));
CREATE POLICY "comp_write" ON public.competitors FOR ALL TO authenticated
  USING (internal.has_role(auth.uid(), org_id, 'analyst'))
  WITH CHECK (internal.has_role(auth.uid(), org_id, 'analyst'));

-- competitor_handles
DROP POLICY IF EXISTS "handles_read" ON public.competitor_handles;
DROP POLICY IF EXISTS "handles_write" ON public.competitor_handles;
CREATE POLICY "handles_read" ON public.competitor_handles FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.competitors c WHERE c.id = competitor_id AND internal.is_member(auth.uid(), c.org_id)));
CREATE POLICY "handles_write" ON public.competitor_handles FOR ALL TO authenticated
  USING (EXISTS (SELECT 1 FROM public.competitors c WHERE c.id = competitor_id AND internal.has_role(auth.uid(), c.org_id, 'analyst')))
  WITH CHECK (EXISTS (SELECT 1 FROM public.competitors c WHERE c.id = competitor_id AND internal.has_role(auth.uid(), c.org_id, 'analyst')));

-- posts
DROP POLICY IF EXISTS "posts_read" ON public.posts;
DROP POLICY IF EXISTS "posts_write" ON public.posts;
CREATE POLICY "posts_read" ON public.posts FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.competitors c WHERE c.id = competitor_id AND internal.is_member(auth.uid(), c.org_id)));
CREATE POLICY "posts_write" ON public.posts FOR ALL TO authenticated
  USING (EXISTS (SELECT 1 FROM public.competitors c WHERE c.id = competitor_id AND internal.has_role(auth.uid(), c.org_id, 'analyst')))
  WITH CHECK (EXISTS (SELECT 1 FROM public.competitors c WHERE c.id = competitor_id AND internal.has_role(auth.uid(), c.org_id, 'analyst')));

-- data_confidence_scores
DROP POLICY IF EXISTS "conf_read" ON public.data_confidence_scores;
DROP POLICY IF EXISTS "conf_write" ON public.data_confidence_scores;
CREATE POLICY "conf_read" ON public.data_confidence_scores FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.competitors c WHERE c.id = competitor_id AND internal.is_member(auth.uid(), c.org_id)));
CREATE POLICY "conf_write" ON public.data_confidence_scores FOR ALL TO authenticated
  USING (EXISTS (SELECT 1 FROM public.competitors c WHERE c.id = competitor_id AND internal.has_role(auth.uid(), c.org_id, 'analyst')))
  WITH CHECK (EXISTS (SELECT 1 FROM public.competitors c WHERE c.id = competitor_id AND internal.has_role(auth.uid(), c.org_id, 'analyst')));

-- pillars
DROP POLICY IF EXISTS "pillars_rw" ON public.content_pillars;
CREATE POLICY "pillars_rw" ON public.content_pillars FOR ALL TO authenticated
  USING (internal.is_member(auth.uid(), org_id))
  WITH CHECK (internal.has_role(auth.uid(), org_id, 'analyst'));

DROP POLICY IF EXISTS "post_pillars_rw" ON public.post_pillars;
CREATE POLICY "post_pillars_rw" ON public.post_pillars FOR ALL TO authenticated
  USING (EXISTS (SELECT 1 FROM public.posts p JOIN public.competitors c ON c.id = p.competitor_id WHERE p.id = post_id AND internal.is_member(auth.uid(), c.org_id)))
  WITH CHECK (EXISTS (SELECT 1 FROM public.posts p JOIN public.competitors c ON c.id = p.competitor_id WHERE p.id = post_id AND internal.has_role(auth.uid(), c.org_id, 'analyst')));

DROP POLICY IF EXISTS "ctags_rw" ON public.creative_tags;
CREATE POLICY "ctags_rw" ON public.creative_tags FOR ALL TO authenticated
  USING (EXISTS (SELECT 1 FROM public.posts p JOIN public.competitors c ON c.id = p.competitor_id WHERE p.id = post_id AND internal.is_member(auth.uid(), c.org_id)))
  WITH CHECK (EXISTS (SELECT 1 FROM public.posts p JOIN public.competitors c ON c.id = p.competitor_id WHERE p.id = post_id AND internal.has_role(auth.uid(), c.org_id, 'analyst')));

DROP POLICY IF EXISTS "fp_rw" ON public.creative_fingerprints;
CREATE POLICY "fp_rw" ON public.creative_fingerprints FOR ALL TO authenticated
  USING (EXISTS (SELECT 1 FROM public.competitors c WHERE c.id = competitor_id AND internal.is_member(auth.uid(), c.org_id)))
  WITH CHECK (EXISTS (SELECT 1 FROM public.competitors c WHERE c.id = competitor_id AND internal.has_role(auth.uid(), c.org_id, 'analyst')));

DROP POLICY IF EXISTS "camp_rw" ON public.campaign_detections;
CREATE POLICY "camp_rw" ON public.campaign_detections FOR ALL TO authenticated
  USING (EXISTS (SELECT 1 FROM public.competitors c WHERE c.id = competitor_id AND internal.is_member(auth.uid(), c.org_id)))
  WITH CHECK (EXISTS (SELECT 1 FROM public.competitors c WHERE c.id = competitor_id AND internal.has_role(auth.uid(), c.org_id, 'analyst')));

DROP POLICY IF EXISTS "promo_rw" ON public.promo_classifications;
CREATE POLICY "promo_rw" ON public.promo_classifications FOR ALL TO authenticated
  USING (EXISTS (SELECT 1 FROM public.posts p JOIN public.competitors c ON c.id = p.competitor_id WHERE p.id = post_id AND internal.is_member(auth.uid(), c.org_id)))
  WITH CHECK (EXISTS (SELECT 1 FROM public.posts p JOIN public.competitors c ON c.id = p.competitor_id WHERE p.id = post_id AND internal.has_role(auth.uid(), c.org_id, 'analyst')));

DROP POLICY IF EXISTS "ws_rw" ON public.whitespace_gaps;
CREATE POLICY "ws_rw" ON public.whitespace_gaps FOR ALL TO authenticated
  USING (internal.is_member(auth.uid(), org_id))
  WITH CHECK (internal.has_role(auth.uid(), org_id, 'analyst'));

DROP POLICY IF EXISTS "recs_rw" ON public.recommendations;
CREATE POLICY "recs_rw" ON public.recommendations FOR ALL TO authenticated
  USING (internal.is_member(auth.uid(), org_id))
  WITH CHECK (internal.has_role(auth.uid(), org_id, 'analyst'));

DROP POLICY IF EXISTS "evi_rw" ON public.evidence_links;
CREATE POLICY "evi_rw" ON public.evidence_links FOR ALL TO authenticated
  USING (EXISTS (SELECT 1 FROM public.recommendations r WHERE r.id = recommendation_id AND internal.is_member(auth.uid(), r.org_id)))
  WITH CHECK (EXISTS (SELECT 1 FROM public.recommendations r WHERE r.id = recommendation_id AND internal.has_role(auth.uid(), r.org_id, 'analyst')));

DROP POLICY IF EXISTS "reports_rw" ON public.reports;
CREATE POLICY "reports_rw" ON public.reports FOR ALL TO authenticated
  USING (internal.is_member(auth.uid(), org_id))
  WITH CHECK (internal.has_role(auth.uid(), org_id, 'analyst'));

DROP POLICY IF EXISTS "audit_read" ON public.audit_events;
DROP POLICY IF EXISTS "audit_insert" ON public.audit_events;
CREATE POLICY "audit_read" ON public.audit_events FOR SELECT TO authenticated
  USING (internal.has_role(auth.uid(), org_id, 'admin'));
CREATE POLICY "audit_insert" ON public.audit_events FOR INSERT TO authenticated
  WITH CHECK (internal.is_member(auth.uid(), org_id));

DROP POLICY IF EXISTS "flags_read" ON public.feature_flags;
DROP POLICY IF EXISTS "flags_write" ON public.feature_flags;
CREATE POLICY "flags_read" ON public.feature_flags FOR SELECT TO authenticated USING (internal.is_member(auth.uid(), org_id));
CREATE POLICY "flags_write" ON public.feature_flags FOR ALL TO authenticated
  USING (internal.has_role(auth.uid(), org_id, 'admin'))
  WITH CHECK (internal.has_role(auth.uid(), org_id, 'admin'));

-- Drop the public-schema versions so they're no longer exposed via the Data API.
DROP FUNCTION IF EXISTS public.is_member(UUID, UUID);
DROP FUNCTION IF EXISTS public.has_role(UUID, UUID, public.app_role);
