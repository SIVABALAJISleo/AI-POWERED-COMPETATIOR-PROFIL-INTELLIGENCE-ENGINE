
-- 1) Webhook delivery traceability
ALTER TABLE public.export_webhook_deliveries
  ADD COLUMN IF NOT EXISTS idempotency_key text,
  ADD COLUMN IF NOT EXISTS correlation_id  text;

-- Backfill existing rows deterministically
UPDATE public.export_webhook_deliveries
   SET idempotency_key = 'legacy-' || id::text
 WHERE idempotency_key IS NULL;

UPDATE public.export_webhook_deliveries
   SET correlation_id = COALESCE(export_id::text, id::text)
 WHERE correlation_id IS NULL;

-- Enforce per-webhook uniqueness so a repeated key cannot double-deliver
CREATE UNIQUE INDEX IF NOT EXISTS export_webhook_deliveries_webhook_idem_uidx
  ON public.export_webhook_deliveries (webhook_id, idempotency_key);

CREATE INDEX IF NOT EXISTS export_webhook_deliveries_correlation_idx
  ON public.export_webhook_deliveries (correlation_id);

-- 2) Backfill pre-versioning exports to lock a template version
UPDATE public.exports e
   SET params = jsonb_set(
         COALESCE(e.params, '{}'::jsonb),
         '{template,version}',
         to_jsonb(COALESCE(t.current_version, 1))
       )
  FROM public.export_templates t
 WHERE (e.params->'template'->>'id') = t.id::text
   AND (e.params->'template' ? 'version') = FALSE;
