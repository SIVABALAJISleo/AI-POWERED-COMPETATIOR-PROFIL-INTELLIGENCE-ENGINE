
-- Revoke public execute; only server-side code (via service_role) and RLS policies (which run inline) need these.
REVOKE EXECUTE ON FUNCTION public.is_member(UUID, UUID) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.has_role(UUID, UUID, public.app_role) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;

-- Drop overly-permissive INSERT-any-org policy; orgs are created via the signup trigger only.
DROP POLICY IF EXISTS "org_insert_authed" ON public.organizations;

-- Explicitly block direct authenticated access to internal job queue (service_role bypasses RLS).
REVOKE ALL ON public.jobs FROM authenticated;
CREATE POLICY "jobs_deny_all" ON public.jobs FOR ALL TO authenticated USING (false) WITH CHECK (false);
