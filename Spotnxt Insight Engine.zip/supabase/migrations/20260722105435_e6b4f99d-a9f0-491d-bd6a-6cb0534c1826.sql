
ALTER TABLE public.export_webhooks
  ADD COLUMN IF NOT EXISTS signing_version TEXT NOT NULL DEFAULT 'v1',
  ADD COLUMN IF NOT EXISTS require_timestamp BOOLEAN NOT NULL DEFAULT FALSE,
  ADD COLUMN IF NOT EXISTS timestamp_tolerance_seconds INT NOT NULL DEFAULT 300,
  ADD COLUMN IF NOT EXISTS last_failure_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS last_failure_reason TEXT,
  ADD COLUMN IF NOT EXISTS consecutive_failures INT NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS max_attempts INT NOT NULL DEFAULT 6;

ALTER TABLE public.export_webhook_deliveries
  ADD COLUMN IF NOT EXISTS payload JSONB,
  ADD COLUMN IF NOT EXISTS dead_lettered BOOLEAN NOT NULL DEFAULT FALSE,
  ADD COLUMN IF NOT EXISTS signed_timestamp BIGINT;

CREATE INDEX IF NOT EXISTS idx_wh_deliveries_next_retry
  ON public.export_webhook_deliveries (next_retry_at)
  WHERE next_retry_at IS NOT NULL AND dead_lettered = FALSE;

CREATE INDEX IF NOT EXISTS idx_wh_deliveries_org_created
  ON public.export_webhook_deliveries (org_id, created_at DESC);

ALTER TABLE public.export_share_links
  ADD COLUMN IF NOT EXISTS download_limit_per_min INT NOT NULL DEFAULT 30;

CREATE TABLE IF NOT EXISTS public.share_link_rate_hits (
  token TEXT NOT NULL,
  ip_hash TEXT NOT NULL,
  window_start TIMESTAMPTZ NOT NULL,
  hits INT NOT NULL DEFAULT 1,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (token, ip_hash, window_start)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.share_link_rate_hits TO service_role;
ALTER TABLE public.share_link_rate_hits ENABLE ROW LEVEL SECURITY;
-- No policies: service_role bypasses RLS; authenticated/anon have no access.

CREATE INDEX IF NOT EXISTS idx_rate_hits_window
  ON public.share_link_rate_hits (window_start);
