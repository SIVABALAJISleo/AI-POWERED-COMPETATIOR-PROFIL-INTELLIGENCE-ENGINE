
REVOKE EXECUTE ON FUNCTION public.purge_expired_exports() FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.purge_expired_exports() FROM anon;
REVOKE EXECUTE ON FUNCTION public.purge_expired_exports() FROM authenticated;
GRANT EXECUTE ON FUNCTION public.purge_expired_exports() TO service_role;
