GRANT SELECT ON public.export_template_versions TO authenticated;
GRANT ALL ON public.export_template_versions TO service_role;

CREATE POLICY "Workspace members can view template versions"
  ON public.export_template_versions
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1
      FROM public.export_templates t
      JOIN public.organization_members m ON m.org_id = t.org_id
      WHERE t.id = export_template_versions.template_id
        AND m.user_id = auth.uid()
    )
  );
