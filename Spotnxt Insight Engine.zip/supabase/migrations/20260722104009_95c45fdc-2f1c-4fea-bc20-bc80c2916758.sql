
-- ============ Share links ============
CREATE TABLE public.export_share_links (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  export_id UUID NOT NULL REFERENCES public.exports(id) ON DELETE CASCADE,
  org_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  token TEXT NOT NULL UNIQUE,
  created_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  expires_at TIMESTAMPTZ NOT NULL,
  max_downloads INTEGER NOT NULL DEFAULT 10 CHECK (max_downloads > 0),
  download_count INTEGER NOT NULL DEFAULT 0,
  revoked_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_esl_export ON public.export_share_links(export_id);
CREATE INDEX idx_esl_org ON public.export_share_links(org_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.export_share_links TO authenticated;
GRANT ALL ON public.export_share_links TO service_role;

ALTER TABLE public.export_share_links ENABLE ROW LEVEL SECURITY;

CREATE POLICY "members can view org share links"
  ON public.export_share_links FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.organization_members m
                 WHERE m.org_id = export_share_links.org_id AND m.user_id = auth.uid()));

CREATE POLICY "requester or admin can create share links"
  ON public.export_share_links FOR INSERT TO authenticated
  WITH CHECK (
    EXISTS (SELECT 1 FROM public.exports e
            WHERE e.id = export_share_links.export_id
              AND e.org_id = export_share_links.org_id
              AND (
                e.requested_by = auth.uid()
                OR EXISTS (SELECT 1 FROM public.organization_members m
                           WHERE m.org_id = e.org_id AND m.user_id = auth.uid()
                             AND m.role IN ('owner','admin'))
              ))
  );

CREATE POLICY "requester or admin can update share links"
  ON public.export_share_links FOR UPDATE TO authenticated
  USING (
    created_by = auth.uid()
    OR EXISTS (SELECT 1 FROM public.organization_members m
               WHERE m.org_id = export_share_links.org_id AND m.user_id = auth.uid()
                 AND m.role IN ('owner','admin'))
  );

CREATE TRIGGER trg_esl_updated
  BEFORE UPDATE ON public.export_share_links
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


-- ============ Export templates ============
CREATE TABLE public.export_templates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  kind TEXT NOT NULL CHECK (kind IN ('csv','pdf')),
  config JSONB NOT NULL DEFAULT '{}'::jsonb,
  is_default BOOLEAN NOT NULL DEFAULT false,
  created_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_etpl_org ON public.export_templates(org_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.export_templates TO authenticated;
GRANT ALL ON public.export_templates TO service_role;

ALTER TABLE public.export_templates ENABLE ROW LEVEL SECURITY;

CREATE POLICY "members can view org templates"
  ON public.export_templates FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.organization_members m
                 WHERE m.org_id = export_templates.org_id AND m.user_id = auth.uid()));

CREATE POLICY "writers can insert templates"
  ON public.export_templates FOR INSERT TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM public.organization_members m
                      WHERE m.org_id = export_templates.org_id AND m.user_id = auth.uid()
                        AND m.role IN ('owner','admin','analyst')));

CREATE POLICY "writers can update templates"
  ON public.export_templates FOR UPDATE TO authenticated
  USING (EXISTS (SELECT 1 FROM public.organization_members m
                 WHERE m.org_id = export_templates.org_id AND m.user_id = auth.uid()
                   AND m.role IN ('owner','admin','analyst')));

CREATE POLICY "writers can delete templates"
  ON public.export_templates FOR DELETE TO authenticated
  USING (EXISTS (SELECT 1 FROM public.organization_members m
                 WHERE m.org_id = export_templates.org_id AND m.user_id = auth.uid()
                   AND m.role IN ('owner','admin','analyst')));

CREATE TRIGGER trg_etpl_updated
  BEFORE UPDATE ON public.export_templates
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


-- ============ Webhooks ============
CREATE TABLE public.export_webhooks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  url TEXT NOT NULL,
  secret TEXT NOT NULL,
  events TEXT[] NOT NULL DEFAULT ARRAY['export.completed','export.failed']::text[],
  enabled BOOLEAN NOT NULL DEFAULT true,
  created_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_ewh_org ON public.export_webhooks(org_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.export_webhooks TO authenticated;
GRANT ALL ON public.export_webhooks TO service_role;

ALTER TABLE public.export_webhooks ENABLE ROW LEVEL SECURITY;

CREATE POLICY "admins can view org webhooks"
  ON public.export_webhooks FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.organization_members m
                 WHERE m.org_id = export_webhooks.org_id AND m.user_id = auth.uid()
                   AND m.role IN ('owner','admin')));

CREATE POLICY "admins can insert webhooks"
  ON public.export_webhooks FOR INSERT TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM public.organization_members m
                      WHERE m.org_id = export_webhooks.org_id AND m.user_id = auth.uid()
                        AND m.role IN ('owner','admin')));

CREATE POLICY "admins can update webhooks"
  ON public.export_webhooks FOR UPDATE TO authenticated
  USING (EXISTS (SELECT 1 FROM public.organization_members m
                 WHERE m.org_id = export_webhooks.org_id AND m.user_id = auth.uid()
                   AND m.role IN ('owner','admin')));

CREATE POLICY "admins can delete webhooks"
  ON public.export_webhooks FOR DELETE TO authenticated
  USING (EXISTS (SELECT 1 FROM public.organization_members m
                 WHERE m.org_id = export_webhooks.org_id AND m.user_id = auth.uid()
                   AND m.role IN ('owner','admin')));

CREATE TRIGGER trg_ewh_updated
  BEFORE UPDATE ON public.export_webhooks
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


-- ============ Webhook deliveries ============
CREATE TABLE public.export_webhook_deliveries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  webhook_id UUID NOT NULL REFERENCES public.export_webhooks(id) ON DELETE CASCADE,
  export_id UUID NOT NULL REFERENCES public.exports(id) ON DELETE CASCADE,
  org_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  event TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','delivered','failed','dead')),
  attempts INTEGER NOT NULL DEFAULT 0,
  status_code INTEGER,
  response_body TEXT,
  error TEXT,
  next_retry_at TIMESTAMPTZ,
  delivered_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_ewd_webhook ON public.export_webhook_deliveries(webhook_id);
CREATE INDEX idx_ewd_org ON public.export_webhook_deliveries(org_id);
CREATE INDEX idx_ewd_pending ON public.export_webhook_deliveries(status, next_retry_at);

GRANT SELECT ON public.export_webhook_deliveries TO authenticated;
GRANT ALL ON public.export_webhook_deliveries TO service_role;

ALTER TABLE public.export_webhook_deliveries ENABLE ROW LEVEL SECURITY;

CREATE POLICY "admins can view deliveries"
  ON public.export_webhook_deliveries FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.organization_members m
                 WHERE m.org_id = export_webhook_deliveries.org_id AND m.user_id = auth.uid()
                   AND m.role IN ('owner','admin')));

CREATE TRIGGER trg_ewd_updated
  BEFORE UPDATE ON public.export_webhook_deliveries
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
