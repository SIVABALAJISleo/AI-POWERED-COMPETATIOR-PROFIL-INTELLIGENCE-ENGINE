
-- Template version history: snapshot on every save; export params can reference a specific version.
CREATE TABLE public.export_template_versions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  template_id UUID NOT NULL REFERENCES public.export_templates(id) ON DELETE CASCADE,
  org_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  version INT NOT NULL,
  name TEXT NOT NULL,
  kind TEXT NOT NULL,
  config JSONB NOT NULL DEFAULT '{}'::jsonb,
  is_default BOOLEAN NOT NULL DEFAULT FALSE,
  change_type TEXT NOT NULL DEFAULT 'update',
  changed_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  diff JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (template_id, version)
);

GRANT SELECT ON public.export_template_versions TO authenticated;
GRANT ALL ON public.export_template_versions TO service_role;

ALTER TABLE public.export_template_versions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Members read template versions"
  ON public.export_template_versions FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.organization_members m
      WHERE m.org_id = export_template_versions.org_id
        AND m.user_id = auth.uid()
    )
  );

CREATE INDEX idx_export_template_versions_template ON public.export_template_versions(template_id, version DESC);
CREATE INDEX idx_export_template_versions_org ON public.export_template_versions(org_id, created_at DESC);

-- Track the "current" version on the template row for fast lookup.
ALTER TABLE public.export_templates
  ADD COLUMN IF NOT EXISTS current_version INT NOT NULL DEFAULT 1;
