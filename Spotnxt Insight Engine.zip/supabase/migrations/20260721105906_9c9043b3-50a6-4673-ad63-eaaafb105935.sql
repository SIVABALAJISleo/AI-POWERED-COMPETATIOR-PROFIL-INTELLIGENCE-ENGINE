
-- ============ ENUMS ============
CREATE TYPE public.app_role AS ENUM ('owner','admin','analyst','viewer');
CREATE TYPE public.platform AS ENUM ('instagram','facebook','linkedin','x','youtube','tiktok');
CREATE TYPE public.promo_type AS ENUM ('discount','launch','giveaway','awareness','none');
CREATE TYPE public.job_status AS ENUM ('pending','running','done','failed','dead');

-- ============ CORE TABLES ============
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  display_name TEXT,
  avatar_url TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "profiles_self_read" ON public.profiles FOR SELECT TO authenticated USING (auth.uid() = id);
CREATE POLICY "profiles_self_write" ON public.profiles FOR UPDATE TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);
CREATE POLICY "profiles_self_insert" ON public.profiles FOR INSERT TO authenticated WITH CHECK (auth.uid() = id);

CREATE TABLE public.organizations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  is_demo BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.organizations TO authenticated;
GRANT ALL ON public.organizations TO service_role;
ALTER TABLE public.organizations ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.organization_members (
  org_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.app_role NOT NULL DEFAULT 'viewer',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (org_id, user_id)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.organization_members TO authenticated;
GRANT ALL ON public.organization_members TO service_role;
ALTER TABLE public.organization_members ENABLE ROW LEVEL SECURITY;

-- Security-definer helpers to avoid RLS recursion
CREATE OR REPLACE FUNCTION public.is_member(_user UUID, _org UUID)
RETURNS BOOLEAN LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.organization_members WHERE user_id = _user AND org_id = _org)
$$;

CREATE OR REPLACE FUNCTION public.has_role(_user UUID, _org UUID, _min public.app_role)
RETURNS BOOLEAN LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.organization_members m
    WHERE m.user_id = _user AND m.org_id = _org
      AND CASE _min
        WHEN 'viewer'  THEN m.role IN ('viewer','analyst','admin','owner')
        WHEN 'analyst' THEN m.role IN ('analyst','admin','owner')
        WHEN 'admin'   THEN m.role IN ('admin','owner')
        WHEN 'owner'   THEN m.role = 'owner'
      END
  )
$$;

-- Orgs & members policies (using helpers to avoid recursion)
CREATE POLICY "org_member_read" ON public.organizations FOR SELECT TO authenticated
  USING (public.is_member(auth.uid(), id));
CREATE POLICY "org_owner_update" ON public.organizations FOR UPDATE TO authenticated
  USING (public.has_role(auth.uid(), id, 'admin')) WITH CHECK (public.has_role(auth.uid(), id, 'admin'));
CREATE POLICY "org_insert_authed" ON public.organizations FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "member_read_own_org" ON public.organization_members FOR SELECT TO authenticated
  USING (public.is_member(auth.uid(), org_id));
CREATE POLICY "member_self_insert" ON public.organization_members FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid());
CREATE POLICY "member_admin_write" ON public.organization_members FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), org_id, 'admin'))
  WITH CHECK (public.has_role(auth.uid(), org_id, 'admin'));

-- ============ COMPETITORS ============
CREATE TABLE public.competitors (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  industry TEXT,
  logo_url TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX competitors_org_idx ON public.competitors(org_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.competitors TO authenticated;
GRANT ALL ON public.competitors TO service_role;
ALTER TABLE public.competitors ENABLE ROW LEVEL SECURITY;
CREATE POLICY "comp_read" ON public.competitors FOR SELECT TO authenticated USING (public.is_member(auth.uid(), org_id));
CREATE POLICY "comp_write" ON public.competitors FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), org_id, 'analyst'))
  WITH CHECK (public.has_role(auth.uid(), org_id, 'analyst'));

CREATE TABLE public.competitor_handles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  competitor_id UUID NOT NULL REFERENCES public.competitors(id) ON DELETE CASCADE,
  platform public.platform NOT NULL,
  handle TEXT NOT NULL,
  external_id TEXT,
  connected_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(competitor_id, platform)
);
CREATE INDEX handles_comp_idx ON public.competitor_handles(competitor_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.competitor_handles TO authenticated;
GRANT ALL ON public.competitor_handles TO service_role;
ALTER TABLE public.competitor_handles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "handles_read" ON public.competitor_handles FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.competitors c WHERE c.id = competitor_id AND public.is_member(auth.uid(), c.org_id)));
CREATE POLICY "handles_write" ON public.competitor_handles FOR ALL TO authenticated
  USING (EXISTS (SELECT 1 FROM public.competitors c WHERE c.id = competitor_id AND public.has_role(auth.uid(), c.org_id, 'analyst')))
  WITH CHECK (EXISTS (SELECT 1 FROM public.competitors c WHERE c.id = competitor_id AND public.has_role(auth.uid(), c.org_id, 'analyst')));

-- ============ POSTS ============
CREATE TABLE public.posts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  competitor_id UUID NOT NULL REFERENCES public.competitors(id) ON DELETE CASCADE,
  platform public.platform NOT NULL,
  external_id TEXT,
  url TEXT,
  caption TEXT,
  media_url TEXT,
  hashtags TEXT[] DEFAULT '{}',
  likes INT NOT NULL DEFAULT 0,
  comments INT NOT NULL DEFAULT 0,
  shares INT NOT NULL DEFAULT 0,
  views INT NOT NULL DEFAULT 0,
  engagement_rate NUMERIC(6,4) NOT NULL DEFAULT 0,
  posted_at TIMESTAMPTZ NOT NULL,
  raw JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(platform, external_id)
);
CREATE INDEX posts_comp_time_idx ON public.posts(competitor_id, posted_at DESC);
CREATE INDEX posts_platform_idx ON public.posts(competitor_id, platform);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.posts TO authenticated;
GRANT ALL ON public.posts TO service_role;
ALTER TABLE public.posts ENABLE ROW LEVEL SECURITY;
CREATE POLICY "posts_read" ON public.posts FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.competitors c WHERE c.id = competitor_id AND public.is_member(auth.uid(), c.org_id)));
CREATE POLICY "posts_write" ON public.posts FOR ALL TO authenticated
  USING (EXISTS (SELECT 1 FROM public.competitors c WHERE c.id = competitor_id AND public.has_role(auth.uid(), c.org_id, 'analyst')))
  WITH CHECK (EXISTS (SELECT 1 FROM public.competitors c WHERE c.id = competitor_id AND public.has_role(auth.uid(), c.org_id, 'analyst')));

-- ============ CONFIDENCE ============
CREATE TABLE public.data_confidence_scores (
  competitor_id UUID NOT NULL REFERENCES public.competitors(id) ON DELETE CASCADE,
  platform public.platform NOT NULL,
  completeness_pct NUMERIC(5,2) NOT NULL DEFAULT 0,
  tracking_start_date DATE,
  limitations JSONB,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (competitor_id, platform)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.data_confidence_scores TO authenticated;
GRANT ALL ON public.data_confidence_scores TO service_role;
ALTER TABLE public.data_confidence_scores ENABLE ROW LEVEL SECURITY;
CREATE POLICY "conf_read" ON public.data_confidence_scores FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.competitors c WHERE c.id = competitor_id AND public.is_member(auth.uid(), c.org_id)));
CREATE POLICY "conf_write" ON public.data_confidence_scores FOR ALL TO authenticated
  USING (EXISTS (SELECT 1 FROM public.competitors c WHERE c.id = competitor_id AND public.has_role(auth.uid(), c.org_id, 'analyst')))
  WITH CHECK (EXISTS (SELECT 1 FROM public.competitors c WHERE c.id = competitor_id AND public.has_role(auth.uid(), c.org_id, 'analyst')));

-- ============ FORWARD-LOOKING PLACEHOLDERS ============
CREATE TABLE public.content_pillars (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  color TEXT
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.content_pillars TO authenticated;
GRANT ALL ON public.content_pillars TO service_role;
ALTER TABLE public.content_pillars ENABLE ROW LEVEL SECURITY;
CREATE POLICY "pillars_rw" ON public.content_pillars FOR ALL TO authenticated
  USING (public.is_member(auth.uid(), org_id))
  WITH CHECK (public.has_role(auth.uid(), org_id, 'analyst'));

CREATE TABLE public.post_pillars (
  post_id UUID NOT NULL REFERENCES public.posts(id) ON DELETE CASCADE,
  pillar_id UUID NOT NULL REFERENCES public.content_pillars(id) ON DELETE CASCADE,
  confidence NUMERIC(4,3) NOT NULL DEFAULT 0,
  PRIMARY KEY (post_id, pillar_id)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.post_pillars TO authenticated;
GRANT ALL ON public.post_pillars TO service_role;
ALTER TABLE public.post_pillars ENABLE ROW LEVEL SECURITY;
CREATE POLICY "post_pillars_rw" ON public.post_pillars FOR ALL TO authenticated
  USING (EXISTS (SELECT 1 FROM public.posts p JOIN public.competitors c ON c.id = p.competitor_id WHERE p.id = post_id AND public.is_member(auth.uid(), c.org_id)))
  WITH CHECK (EXISTS (SELECT 1 FROM public.posts p JOIN public.competitors c ON c.id = p.competitor_id WHERE p.id = post_id AND public.has_role(auth.uid(), c.org_id, 'analyst')));

CREATE TABLE public.creative_tags (
  post_id UUID PRIMARY KEY REFERENCES public.posts(id) ON DELETE CASCADE,
  palette JSONB,
  has_text_overlay BOOLEAN DEFAULT FALSE,
  face_ratio NUMERIC(4,3),
  product_ratio NUMERIC(4,3),
  style_embedding JSONB,
  tagged_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.creative_tags TO authenticated;
GRANT ALL ON public.creative_tags TO service_role;
ALTER TABLE public.creative_tags ENABLE ROW LEVEL SECURITY;
CREATE POLICY "ctags_rw" ON public.creative_tags FOR ALL TO authenticated
  USING (EXISTS (SELECT 1 FROM public.posts p JOIN public.competitors c ON c.id = p.competitor_id WHERE p.id = post_id AND public.is_member(auth.uid(), c.org_id)))
  WITH CHECK (EXISTS (SELECT 1 FROM public.posts p JOIN public.competitors c ON c.id = p.competitor_id WHERE p.id = post_id AND public.has_role(auth.uid(), c.org_id, 'analyst')));

CREATE TABLE public.creative_fingerprints (
  competitor_id UUID PRIMARY KEY REFERENCES public.competitors(id) ON DELETE CASCADE,
  dominant_palette JSONB,
  logo_consistency NUMERIC(4,3),
  face_product_ratio NUMERIC(4,3),
  text_overlay_density NUMERIC(4,3),
  style_embedding JSONB,
  computed_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.creative_fingerprints TO authenticated;
GRANT ALL ON public.creative_fingerprints TO service_role;
ALTER TABLE public.creative_fingerprints ENABLE ROW LEVEL SECURITY;
CREATE POLICY "fp_rw" ON public.creative_fingerprints FOR ALL TO authenticated
  USING (EXISTS (SELECT 1 FROM public.competitors c WHERE c.id = competitor_id AND public.is_member(auth.uid(), c.org_id)))
  WITH CHECK (EXISTS (SELECT 1 FROM public.competitors c WHERE c.id = competitor_id AND public.has_role(auth.uid(), c.org_id, 'analyst')));

CREATE TABLE public.campaign_detections (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  competitor_id UUID NOT NULL REFERENCES public.competitors(id) ON DELETE CASCADE,
  name TEXT,
  hashtag_cluster JSONB,
  start_date DATE,
  end_date DATE,
  confidence NUMERIC(4,3),
  cross_platform_sync NUMERIC(4,3),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.campaign_detections TO authenticated;
GRANT ALL ON public.campaign_detections TO service_role;
ALTER TABLE public.campaign_detections ENABLE ROW LEVEL SECURITY;
CREATE POLICY "camp_rw" ON public.campaign_detections FOR ALL TO authenticated
  USING (EXISTS (SELECT 1 FROM public.competitors c WHERE c.id = competitor_id AND public.is_member(auth.uid(), c.org_id)))
  WITH CHECK (EXISTS (SELECT 1 FROM public.competitors c WHERE c.id = competitor_id AND public.has_role(auth.uid(), c.org_id, 'analyst')));

CREATE TABLE public.promo_classifications (
  post_id UUID PRIMARY KEY REFERENCES public.posts(id) ON DELETE CASCADE,
  promo_type public.promo_type NOT NULL DEFAULT 'none',
  confidence NUMERIC(4,3) NOT NULL DEFAULT 0
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.promo_classifications TO authenticated;
GRANT ALL ON public.promo_classifications TO service_role;
ALTER TABLE public.promo_classifications ENABLE ROW LEVEL SECURITY;
CREATE POLICY "promo_rw" ON public.promo_classifications FOR ALL TO authenticated
  USING (EXISTS (SELECT 1 FROM public.posts p JOIN public.competitors c ON c.id = p.competitor_id WHERE p.id = post_id AND public.is_member(auth.uid(), c.org_id)))
  WITH CHECK (EXISTS (SELECT 1 FROM public.posts p JOIN public.competitors c ON c.id = p.competitor_id WHERE p.id = post_id AND public.has_role(auth.uid(), c.org_id, 'analyst')));

CREATE TABLE public.whitespace_gaps (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  competitor_set_hash TEXT NOT NULL,
  gap_type TEXT NOT NULL,
  description TEXT,
  evidence JSONB,
  generated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.whitespace_gaps TO authenticated;
GRANT ALL ON public.whitespace_gaps TO service_role;
ALTER TABLE public.whitespace_gaps ENABLE ROW LEVEL SECURITY;
CREATE POLICY "ws_rw" ON public.whitespace_gaps FOR ALL TO authenticated
  USING (public.is_member(auth.uid(), org_id))
  WITH CHECK (public.has_role(auth.uid(), org_id, 'analyst'));

CREATE TABLE public.recommendations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'open',
  priority TEXT NOT NULL DEFAULT 'medium',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.recommendations TO authenticated;
GRANT ALL ON public.recommendations TO service_role;
ALTER TABLE public.recommendations ENABLE ROW LEVEL SECURITY;
CREATE POLICY "recs_rw" ON public.recommendations FOR ALL TO authenticated
  USING (public.is_member(auth.uid(), org_id))
  WITH CHECK (public.has_role(auth.uid(), org_id, 'analyst'));

CREATE TABLE public.evidence_links (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  recommendation_id UUID NOT NULL REFERENCES public.recommendations(id) ON DELETE CASCADE,
  source_type TEXT NOT NULL,
  source_id UUID,
  snippet TEXT
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.evidence_links TO authenticated;
GRANT ALL ON public.evidence_links TO service_role;
ALTER TABLE public.evidence_links ENABLE ROW LEVEL SECURITY;
CREATE POLICY "evi_rw" ON public.evidence_links FOR ALL TO authenticated
  USING (EXISTS (SELECT 1 FROM public.recommendations r WHERE r.id = recommendation_id AND public.is_member(auth.uid(), r.org_id)))
  WITH CHECK (EXISTS (SELECT 1 FROM public.recommendations r WHERE r.id = recommendation_id AND public.has_role(auth.uid(), r.org_id, 'analyst')));

CREATE TABLE public.reports (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  kind TEXT NOT NULL,
  params JSONB,
  payload JSONB,
  status TEXT NOT NULL DEFAULT 'pending',
  pdf_url TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.reports TO authenticated;
GRANT ALL ON public.reports TO service_role;
ALTER TABLE public.reports ENABLE ROW LEVEL SECURITY;
CREATE POLICY "reports_rw" ON public.reports FOR ALL TO authenticated
  USING (public.is_member(auth.uid(), org_id))
  WITH CHECK (public.has_role(auth.uid(), org_id, 'analyst'));

CREATE TABLE public.audit_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  actor_user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  action TEXT NOT NULL,
  target_type TEXT,
  target_id UUID,
  metadata JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.audit_events TO authenticated;
GRANT ALL ON public.audit_events TO service_role;
ALTER TABLE public.audit_events ENABLE ROW LEVEL SECURITY;
CREATE POLICY "audit_read" ON public.audit_events FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), org_id, 'admin'));
CREATE POLICY "audit_insert" ON public.audit_events FOR INSERT TO authenticated
  WITH CHECK (public.is_member(auth.uid(), org_id));

CREATE TABLE public.feature_flags (
  org_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  key TEXT NOT NULL,
  enabled BOOLEAN NOT NULL DEFAULT FALSE,
  config JSONB,
  PRIMARY KEY (org_id, key)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.feature_flags TO authenticated;
GRANT ALL ON public.feature_flags TO service_role;
ALTER TABLE public.feature_flags ENABLE ROW LEVEL SECURITY;
CREATE POLICY "flags_read" ON public.feature_flags FOR SELECT TO authenticated USING (public.is_member(auth.uid(), org_id));
CREATE POLICY "flags_write" ON public.feature_flags FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), org_id, 'admin'))
  WITH CHECK (public.has_role(auth.uid(), org_id, 'admin'));

CREATE TABLE public.jobs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  kind TEXT NOT NULL,
  payload JSONB,
  status public.job_status NOT NULL DEFAULT 'pending',
  attempts INT NOT NULL DEFAULT 0,
  last_error TEXT,
  run_after TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX jobs_pending_idx ON public.jobs(status, run_after);
GRANT SELECT ON public.jobs TO authenticated;
GRANT ALL ON public.jobs TO service_role;
ALTER TABLE public.jobs ENABLE ROW LEVEL SECURITY;
-- Jobs are internal; admins in any org can read via service_role only.

-- ============ SIGNUP TRIGGER ============
-- Auto-create profile, personal org, and add user as viewer to demo org
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  new_org UUID;
  demo_org UUID;
  disp TEXT;
BEGIN
  disp := COALESCE(
    NEW.raw_user_meta_data->>'full_name',
    NEW.raw_user_meta_data->>'name',
    split_part(NEW.email, '@', 1)
  );
  INSERT INTO public.profiles(id, display_name, avatar_url)
    VALUES (NEW.id, disp, NEW.raw_user_meta_data->>'avatar_url')
    ON CONFLICT (id) DO NOTHING;

  -- Personal org
  INSERT INTO public.organizations(name, slug, is_demo)
    VALUES (disp || '''s Workspace', 'ws-' || substr(NEW.id::text, 1, 8), FALSE)
    RETURNING id INTO new_org;
  INSERT INTO public.organization_members(org_id, user_id, role)
    VALUES (new_org, NEW.id, 'owner');

  -- Attach to demo org as viewer
  SELECT id INTO demo_org FROM public.organizations WHERE is_demo = TRUE LIMIT 1;
  IF demo_org IS NOT NULL THEN
    INSERT INTO public.organization_members(org_id, user_id, role)
      VALUES (demo_org, NEW.id, 'viewer')
      ON CONFLICT DO NOTHING;
  END IF;
  RETURN NEW;
END; $$;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- ============ DEMO SEED DATA ============
DO $seed$
DECLARE
  demo_org UUID := '00000000-0000-0000-0000-000000000d10';
  comp RECORD;
  plat public.platform;
  comp_row RECORD;
  incomplete_platform public.platform;
  post_date TIMESTAMPTZ;
  n_posts INT;
  i INT;
  likes_val INT;
  comments_val INT;
  shares_val INT;
  views_val INT;
  followers INT;
  eng NUMERIC;
  hashtags_pool TEXT[][] := ARRAY[
    ARRAY['#launch','#innovation','#future'],
    ARRAY['#sale','#deal','#limited'],
    ARRAY['#howto','#tips','#tutorial'],
    ARRAY['#team','#culture','#hiring'],
    ARRAY['#giveaway','#contest','#win']
  ];
  captions_pool TEXT[] := ARRAY[
    'Excited to announce our newest product line — built for creators like you.',
    'Limited-time offer: 30% off everything through the weekend.',
    'Behind the scenes with the team that makes it all happen.',
    'Three tips to level up your workflow this week.',
    'Giveaway time! Tag a friend to enter.',
    'Customer spotlight — see how @user built something incredible.',
    'What we learned shipping v2 to 10,000 users.',
    'Big news: we just crossed a major milestone thanks to you.'
  ];
BEGIN
  -- Demo organization
  INSERT INTO public.organizations(id, name, slug, is_demo)
    VALUES (demo_org, 'Spotnxt Demo', 'spotnxt-demo', TRUE)
    ON CONFLICT (id) DO NOTHING;

  -- 5 competitors
  FOR comp IN
    SELECT * FROM (VALUES
      ('11111111-1111-1111-1111-111111111111'::UUID, 'Northwind DTC',      'Consumer Goods'),
      ('22222222-2222-2222-2222-222222222222'::UUID, 'Helix Fitness',      'Health & Fitness'),
      ('33333333-3333-3333-3333-333333333333'::UUID, 'Lumen Cosmetics',    'Beauty'),
      ('44444444-4444-4444-4444-444444444444'::UUID, 'Foundry Analytics',  'B2B SaaS'),
      ('55555555-5555-5555-5555-555555555555'::UUID, 'Cascade Outdoors',   'Apparel')
    ) AS t(id, name, industry)
  LOOP
    INSERT INTO public.competitors(id, org_id, name, industry)
      VALUES (comp.id, demo_org, comp.name, comp.industry)
      ON CONFLICT (id) DO NOTHING;
  END LOOP;

  -- Handles + confidence rows + posts per competitor
  FOR comp_row IN SELECT * FROM public.competitors WHERE org_id = demo_org LOOP
    -- Deterministically pick one "incomplete" platform per competitor
    incomplete_platform := (ARRAY['linkedin','tiktok','facebook','x','youtube']::public.platform[])[
      1 + (abs(hashtext(comp_row.id::text)) % 5)
    ];
    followers := 15000 + (abs(hashtext(comp_row.id::text)) % 200000);

    FOR plat IN SELECT unnest(ARRAY['instagram','facebook','linkedin','x','youtube','tiktok']::public.platform[]) LOOP
      INSERT INTO public.competitor_handles(competitor_id, platform, handle)
        VALUES (comp_row.id, plat, '@' || lower(regexp_replace(comp_row.name, '\s+', '', 'g')))
        ON CONFLICT DO NOTHING;

      -- Confidence: incomplete platform gets low pct + explicit limitation
      IF plat = incomplete_platform THEN
        INSERT INTO public.data_confidence_scores(competitor_id, platform, completeness_pct, tracking_start_date, limitations)
          VALUES (
            comp_row.id, plat, 22.0, CURRENT_DATE - INTERVAL '30 days',
            jsonb_build_object(
              'reason', CASE plat
                WHEN 'linkedin' THEN 'LinkedIn has no public competitor-analysis API. Data is limited to what''s manually observable.'
                WHEN 'tiktok'   THEN 'TikTok Research API access pending. Historical backfill unavailable.'
                ELSE 'Historical data only available from the date tracking began.'
              END,
              'tracking_start', (CURRENT_DATE - INTERVAL '30 days')::text
            )
          )
          ON CONFLICT (competitor_id, platform) DO NOTHING;
      ELSE
        INSERT INTO public.data_confidence_scores(competitor_id, platform, completeness_pct, tracking_start_date, limitations)
          VALUES (comp_row.id, plat, 88.0 + (random()*10)::numeric(5,2), CURRENT_DATE - INTERVAL '180 days', NULL)
          ON CONFLICT (competitor_id, platform) DO NOTHING;
      END IF;

      -- Posts: incomplete platform = 4 posts total; others = ~4/week for 6 months
      n_posts := CASE WHEN plat = incomplete_platform THEN 4 ELSE 90 END;

      FOR i IN 1..n_posts LOOP
        -- Spread posts over 180 days; incomplete ones over last 30 days
        IF plat = incomplete_platform THEN
          post_date := now() - (random() * INTERVAL '30 days');
        ELSE
          post_date := now() - (random() * INTERVAL '180 days');
        END IF;

        likes_val := (100 + random()*4000)::INT;
        comments_val := (5 + random()*300)::INT;
        shares_val := (2 + random()*150)::INT;
        views_val := CASE WHEN plat IN ('youtube','tiktok') THEN (2000 + random()*80000)::INT ELSE (500 + random()*20000)::INT END;
        eng := ROUND(((likes_val + comments_val + shares_val)::NUMERIC / GREATEST(followers,1)) * 100, 4);

        INSERT INTO public.posts(
          competitor_id, platform, external_id, url, caption, media_url, hashtags,
          likes, comments, shares, views, engagement_rate, posted_at
        ) VALUES (
          comp_row.id, plat,
          comp_row.id::text || '-' || plat::text || '-' || i::text,
          'https://example.com/' || plat::text || '/' || i,
          captions_pool[1 + (i % array_length(captions_pool,1))],
          'https://picsum.photos/seed/' || comp_row.id::text || i::text || '/600/600',
          hashtags_pool[1 + (i % array_length(hashtags_pool,1))][1:3],
          likes_val, comments_val, shares_val, views_val, eng,
          post_date
        )
        ON CONFLICT (platform, external_id) DO NOTHING;
      END LOOP;
    END LOOP;
  END LOOP;

  -- Seed a couple of illustrative recommendations with evidence
  INSERT INTO public.recommendations(id, org_id, title, body, priority)
  VALUES
    ('a0000000-0000-0000-0000-000000000001', demo_org,
     'Northwind is winning weekends — you post Mon-Fri only',
     'Northwind DTC drives 62% of weekly engagement from Saturday and Sunday posts. Your calendar shows zero weekend activity in the last 90 days. Consider a lightweight weekend content track.',
     'high'),
    ('a0000000-0000-0000-0000-000000000002', demo_org,
     'Whitespace: educational short-form video on TikTok',
     'None of your five tracked competitors post educational how-to content on TikTok. This pillar is unclaimed in your category.',
     'medium')
  ON CONFLICT (id) DO NOTHING;

  INSERT INTO public.evidence_links(recommendation_id, source_type, source_id, snippet)
  SELECT 'a0000000-0000-0000-0000-000000000001', 'post', p.id,
         'Weekend post: ' || left(p.caption, 80)
  FROM public.posts p
  WHERE p.competitor_id = '11111111-1111-1111-1111-111111111111'
    AND EXTRACT(DOW FROM p.posted_at) IN (0,6)
  ORDER BY p.engagement_rate DESC LIMIT 3;

  INSERT INTO public.evidence_links(recommendation_id, source_type, snippet)
  VALUES ('a0000000-0000-0000-0000-000000000002', 'analysis', 'Content-pillar distribution across 5 tracked competitors shows 0 posts tagged "education" on TikTok.');
END $seed$;
