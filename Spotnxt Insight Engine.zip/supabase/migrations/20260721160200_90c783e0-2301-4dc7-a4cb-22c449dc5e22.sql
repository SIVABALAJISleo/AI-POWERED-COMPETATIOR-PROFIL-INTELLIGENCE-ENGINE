
CREATE TABLE IF NOT EXISTS public.exports (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  competitor_id UUID REFERENCES public.competitors(id) ON DELETE SET NULL,
  kind TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  format TEXT NOT NULL,
  filename TEXT,
  mime_type TEXT,
  params JSONB NOT NULL DEFAULT '{}'::jsonb,
  artifact TEXT,
  size_bytes INTEGER,
  row_count INTEGER,
  progress INTEGER NOT NULL DEFAULT 0,
  error TEXT,
  requested_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  completed_at TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_exports_org_created ON public.exports(org_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_exports_status ON public.exports(status) WHERE status IN ('pending','running');

GRANT SELECT, INSERT, UPDATE, DELETE ON public.exports TO authenticated;
GRANT ALL ON public.exports TO service_role;

ALTER TABLE public.exports ENABLE ROW LEVEL SECURITY;

CREATE POLICY "members can read org exports"
  ON public.exports FOR SELECT TO authenticated
  USING (internal.is_member(auth.uid(), org_id));

CREATE POLICY "writers can insert exports for their org"
  ON public.exports FOR INSERT TO authenticated
  WITH CHECK (
    internal.is_member(auth.uid(), org_id)
    AND requested_by = auth.uid()
  );

CREATE POLICY "requesters can update their pending exports"
  ON public.exports FOR UPDATE TO authenticated
  USING (requested_by = auth.uid())
  WITH CHECK (requested_by = auth.uid());

CREATE TRIGGER exports_set_updated_at
  BEFORE UPDATE ON public.exports
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

ALTER PUBLICATION supabase_realtime ADD TABLE public.exports;
ALTER TABLE public.exports REPLICA IDENTITY FULL;
