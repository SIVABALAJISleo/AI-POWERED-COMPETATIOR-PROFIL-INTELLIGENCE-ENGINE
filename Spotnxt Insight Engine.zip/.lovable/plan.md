# Plan — 5 export enhancements

## 1. Share links (expiring, permission-checked)
- New table `public.export_share_links`: id, export_id (FK→exports), org_id, token (unique, 32-byte hex), created_by, expires_at, max_downloads, download_count, revoked_at, created_at.
- RLS: owner/admin/requester of the parent export can create/list/revoke; artifact fetch happens via public route (token-authenticated), not RLS.
- Server fns (`exports.functions.ts`):
  - `createExportShareLink({ exportId, ttlHours, maxDownloads })` — role-checked (requester or admin), only for `status='done'` with artifact.
  - `listExportShareLinks({ exportId })`, `revokeExportShareLink({ id })`.
- Public route `src/routes/api/public/share/exports/$token.ts`: validates token, not revoked, not expired, `download_count < max_downloads`, artifact not purged; increments count, streams artifact with correct Content-Type/Disposition. Audit-logged.
- UI: "Share" button in `ExportsPanel` on `done` rows → dialog with TTL (1h/24h/7d/30d), max downloads, generated URL (copy button), list of active links with revoke.

## 2. Configurable export templates
- New table `public.export_templates`: id, org_id, name, kind (`csv`|`pdf`), config JSONB, created_by, is_default.
- `config` shape:
  - CSV: `{ columns: string[] }` — subset+order of canonical evidence columns.
  - PDF: `{ sections: { summary, metrics, thumbnails, evidenceTable, snippets }: boolean, orientation: 'portrait'|'landscape' }`.
- `export-helpers.ts`: extend `buildCsv` to accept column list; add `renderPdfSections` config knobs.
- `exports.functions.ts`: `enqueueExport` accepts `templateId` OR inline `templateConfig`, persisted into `exports.params.template`.
- Server fns: `listExportTemplates`, `saveExportTemplate`, `deleteExportTemplate`.
- UI: template picker in the export trigger dialog; a "Manage templates" panel (dashboard sidebar) to CRUD.

## 3. Webhook callbacks
- New table `public.export_webhooks`: id, org_id, url, secret, events (text[] of `export.completed`,`export.failed`), enabled, created_at.
- New table `public.export_webhook_deliveries`: id, webhook_id, export_id, event, status_code, response_body (truncated), attempt, delivered_at, next_retry_at, error.
- After export finalize (done/failed) in worker: enqueue deliveries; HMAC-SHA256 signature header `X-Spotnxt-Signature: sha256=<hex>` over raw JSON body; retry with backoff up to 5 attempts.
- Server fns: `listExportWebhooks`, `createExportWebhook` (returns secret once), `deleteExportWebhook`, `testExportWebhook`, `listWebhookDeliveries`.
- UI: "Webhooks" section in retention/admin panel — owner/admin only.

## 4. Bulk retry
- Server fn `retryExportsBulk({ ids: string[] })` — per-id RBAC check, reuses `retryExport` logic; returns `{ succeeded, failed }`.
- UI: checkbox column in `ExportsPanel` (only visible for `failed`/`expired` rows), sticky action bar with count + "Retry N" button; audit event `export.bulk_retry` with count.

## 5. Deep links
- Extend `exports.params` writes to include `job_ids?: string[]` (populated at enqueue when applicable) and reuse existing `origin_batch_ids`/etc when relevant.
- Add `audit_ref` (audit event id) already logged; link to filtered audit view.
- UI: each export row gets a small "Trace" dropdown → items:
  - "View jobs" → `/dashboard?jobs=<id,id>` (JobsPanel reads query param, filters).
  - "View audit trail" → `/dashboard?audit_export=<id>` (AuditLogPanel filter).
  - "View recommendations" for `recommendation_ids`.
- `JobsPanel`/`AuditLogPanel` read `useSearch()` and apply the filter on mount.

## Migration order
Single migration for all four new tables + GRANTs + RLS + policies + `exports.params.job_ids` (JSONB stays; no schema change). Add index on `export_share_links.token` (unique), `export_webhook_deliveries.webhook_id`, `export_templates.org_id`.

## Technical notes
- Public share route lives under `/api/public/*` (auth bypass) with token check inside; sets `Content-Disposition: attachment; filename="..."`.
- Webhook worker runs inside existing background export processor; failed deliveries are re-scanned on each `processExportInternal` tick (bounded).
- All new server fns use `requireSupabaseAuth`; admin-only ones re-check role via `has_role`.
- Templates default to canonical CSV columns / all PDF sections when none selected.

Files touched:
- Migration (new).
- `src/lib/exports.functions.ts` (bulk retry, share links, webhooks, template plumbing).
- `src/lib/export-helpers.ts` (column subsetting, PDF section flags).
- `src/lib/evidence-render.server.ts` (respect PDF section config).
- `src/components/spotnxt/exports-panel.tsx` (share dialog, bulk select, trace menu, template picker on trigger).
- New: `src/components/spotnxt/export-templates-panel.tsx`, `export-webhooks-panel.tsx`, `share-link-dialog.tsx`.
- `src/routes/api/public/share/exports/$token.ts` (new).
- `src/routes/_authenticated/dashboard.tsx` (wire new panels, read query params).
- `src/components/spotnxt/jobs-panel.tsx`, `audit-log-panel.tsx` (query-param filters).
