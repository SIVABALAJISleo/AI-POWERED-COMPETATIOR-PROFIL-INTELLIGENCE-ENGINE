import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

export type Competitor = {
  id: string;
  org_id: string;
  name: string;
  industry: string | null;
  logo_url: string | null;
  org_name: string;
  is_demo: boolean;
  post_count: number;
  avg_engagement: number;
  platforms: string[];
};

export const listOrgs = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("organization_members")
      .select("role, organizations(id, name, slug, is_demo)")
      .eq("user_id", context.userId);
    if (error) throw error;
    return (data ?? []).map((row) => ({
      role: row.role as string,
      
      org: row.organizations as { id: string; name: string; slug: string; is_demo: boolean },
    }));
  });

export const listCompetitors = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<Competitor[]> => {
    const { data: comps, error } = await context.supabase
      .from("competitors")
      .select("id, org_id, name, industry, logo_url, organizations(name, is_demo)")
      .order("name");
    if (error) throw error;
    if (!comps || comps.length === 0) return [];

    const ids = comps.map((c) => c.id);
    const { data: posts } = await context.supabase
      .from("posts")
      .select("competitor_id, platform, engagement_rate")
      .in("competitor_id", ids);

    const agg = new Map<string, { count: number; sum: number; platforms: Set<string> }>();
    for (const id of ids) agg.set(id, { count: 0, sum: 0, platforms: new Set() });
    for (const p of posts ?? []) {
      const a = agg.get(p.competitor_id)!;
      a.count += 1;
      a.sum += Number(p.engagement_rate ?? 0);
      a.platforms.add(p.platform);
    }

    return comps.map((c) => {
      const a = agg.get(c.id)!;
      
      const orgInfo = c.organizations as { name: string; is_demo: boolean };
      return {
        id: c.id,
        org_id: c.org_id,
        name: c.name,
        industry: c.industry,
        logo_url: c.logo_url,
        org_name: orgInfo?.name ?? "",
        is_demo: orgInfo?.is_demo ?? false,
        post_count: a.count,
        avg_engagement: a.count > 0 ? a.sum / a.count : 0,
        platforms: [...a.platforms].sort(),
      };
    });
  });

const idSchema = z.object({ competitorId: z.string().uuid() });

export const getCompetitor = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => idSchema.parse(data))
  .handler(async ({ data, context }) => {
    const { data: comp, error } = await context.supabase
      .from("competitors")
      .select("id, org_id, name, industry, logo_url, created_at")
      .eq("id", data.competitorId)
      .maybeSingle();
    if (error) throw error;
    if (!comp) throw new Error("Competitor not found");

    const { data: handles } = await context.supabase
      .from("competitor_handles")
      .select("platform, handle")
      .eq("competitor_id", data.competitorId);

    const { data: confidence } = await context.supabase
      .from("data_confidence_scores")
      .select("platform, completeness_pct, tracking_start_date, limitations")
      .eq("competitor_id", data.competitorId);

    return { competitor: comp, handles: handles ?? [], confidence: confidence ?? [] };
  });

const filterSchema = z.object({
  competitorId: z.string().uuid(),
  platforms: z.array(z.string()).optional(),
  from: z.string().datetime().optional().nullable(),
  to: z.string().datetime().optional().nullable(),
});

type QB = {
  in: (col: string, vals: string[]) => QB;
  gte: (col: string, val: string) => QB;
  lte: (col: string, val: string) => QB;
};
function applyFilters(
  q: QB,
  data: { platforms?: string[]; from?: string | null; to?: string | null },
) {
  if (data.platforms && data.platforms.length > 0) q = q.in("platform", data.platforms);
  if (data.from) q = q.gte("posted_at", data.from);
  if (data.to) q = q.lte("posted_at", data.to);
  return q;
}

export const getFrequency = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => filterSchema.parse(data))
  .handler(async ({ data, context }) => {
    let q = context.supabase
      .from("posts")
      .select("posted_at, platform, engagement_rate, likes, comments, shares")
      .eq("competitor_id", data.competitorId);
    q = applyFilters(q as unknown as QB, data) as unknown as typeof q;
    const { data: posts, error } = await q
      .order("posted_at", { ascending: false })
      .limit(2000);
    if (error) throw error;

    const heatmap: number[][] = Array.from({ length: 7 }, () => Array(24).fill(0));
    const weeks: { week: string; count: number }[] = [];
    const weekMap = new Map<string, number>();
    const perPlatform = new Map<string, number>();

    let totalEng = 0;
    let engCount = 0;
    let bestPost: { engagement: number; likes: number; posted_at: string } | null = null;

    const now = Date.now();
    for (const p of posts ?? []) {
      const d = new Date(p.posted_at);
      heatmap[d.getUTCDay()][d.getUTCHours()] += 1;

      const daysAgo = Math.floor((now - d.getTime()) / (24 * 3600 * 1000));
      if (daysAgo <= 182) {
        const weekIdx = Math.floor(daysAgo / 7);
        const key = `${weekIdx}`;
        weekMap.set(key, (weekMap.get(key) ?? 0) + 1);
      }
      perPlatform.set(p.platform, (perPlatform.get(p.platform) ?? 0) + 1);

      const eng = Number(p.engagement_rate ?? 0);
      totalEng += eng;
      engCount += 1;
      if (!bestPost || eng > bestPost.engagement) {
        bestPost = { engagement: eng, likes: p.likes ?? 0, posted_at: p.posted_at };
      }
    }

    for (let i = 25; i >= 0; i--) {
      weeks.push({ week: `${i}w ago`, count: weekMap.get(`${i}`) ?? 0 });
    }

    return {
      heatmap,
      weeks,
      perPlatform: [...perPlatform.entries()].map(([platform, count]) => ({ platform, count })),
      totalPosts: posts?.length ?? 0,
      avgEngagement: engCount > 0 ? totalEng / engCount : 0,
      bestPost,
    };
  });

export const getRecommendations = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data: recs, error } = await context.supabase
      .from("recommendations")
      .select("id, org_id, title, body, priority, status, created_at, evidence_links(id, source_type, source_id, snippet)")
      .order("created_at", { ascending: false })
      .limit(20);
    if (error) throw error;
    return recs ?? [];
  });

export const getCreativeDNA = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => filterSchema.parse(data))
  .handler(async ({ data, context }) => {
    const { data: fp } = await context.supabase
      .from("creative_fingerprints")
      .select("dominant_palette, logo_consistency, face_product_ratio, text_overlay_density, computed_at")
      .eq("competitor_id", data.competitorId)
      .maybeSingle();

    let gq = context.supabase
      .from("posts")
      .select("id, platform, media_url, caption, engagement_rate, posted_at")
      .eq("competitor_id", data.competitorId);
    gq = applyFilters(gq as unknown as QB, data) as unknown as typeof gq;
    const { data: gallery } = await gq
      .order("engagement_rate", { ascending: false })
      .limit(12);

    let pq = context.supabase
      .from("posts")
      .select("id, promo_classifications(promo_type)")
      .eq("competitor_id", data.competitorId);
    pq = applyFilters(pq as unknown as QB, data) as unknown as typeof pq;
    const { data: promos } = await pq.limit(2000);

    const mix = new Map<string, number>();
    for (const row of promos ?? []) {
      const pc = (row as { promo_classifications: { promo_type: string } | { promo_type: string }[] | null }).promo_classifications;
      const t = Array.isArray(pc) ? pc[0]?.promo_type : pc?.promo_type;
      if (!t) continue;
      mix.set(t, (mix.get(t) ?? 0) + 1);
    }
    const total = [...mix.values()].reduce((a, b) => a + b, 0) || 1;
    const promoMix = [...mix.entries()].map(([type, count]) => ({
      type,
      count,
      pct: count / total,
    }));

    return { fingerprint: fp, gallery: gallery ?? [], promoMix };
  });

export const getCampaigns = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => filterSchema.parse(data))
  .handler(async ({ data, context }) => {
    let q = context.supabase
      .from("campaign_detections")
      .select("id, name, hashtag_cluster, start_date, end_date, confidence, cross_platform_sync")
      .eq("competitor_id", data.competitorId);
    if (data.from) q = q.gte("start_date", data.from.slice(0, 10));
    if (data.to) q = q.lte("end_date", data.to.slice(0, 10));
    const { data: rows, error } = await q.order("start_date", { ascending: true });
    if (error) throw error;
    return rows ?? [];
  });

export const getTopPosts = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => filterSchema.parse(data))
  .handler(async ({ data, context }) => {
    let q = context.supabase
      .from("posts")
      .select("id, platform, caption, media_url, url, likes, comments, shares, views, engagement_rate, posted_at, hashtags")
      .eq("competitor_id", data.competitorId);
    q = applyFilters(q as unknown as QB, data) as unknown as typeof q;
    const { data: posts, error } = await q
      .order("engagement_rate", { ascending: false })
      .limit(9);
    if (error) throw error;
    return posts ?? [];
  });

export const getEvidenceDetail = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) =>
    z.object({
      sourceType: z.string(),
      sourceId: z.string().uuid(),
    }).parse(data),
  )
  .handler(async ({ data, context }) => {
    if (data.sourceType === "post") {
      const { data: post, error } = await context.supabase
        .from("posts")
        .select("id, platform, caption, media_url, url, likes, comments, shares, views, engagement_rate, posted_at")
        .eq("id", data.sourceId)
        .maybeSingle();
      if (error) throw error;
      if (!post) return null;
      return { kind: "post" as const, post };
    }

    // Metric-type evidence: aggregate breakdown around the referenced post/competitor
    const { data: post } = await context.supabase
      .from("posts")
      .select("competitor_id, platform, engagement_rate")
      .eq("id", data.sourceId)
      .maybeSingle();

    if (!post) {
      return {
        kind: "metric" as const,
        description: "Aggregate metric derived from tracked activity.",
        breakdown: [] as { label: string; value: string }[],
      };
    }

    const { data: peers } = await context.supabase
      .from("posts")
      .select("engagement_rate, platform")
      .eq("competitor_id", post.competitor_id)
      .limit(500);
    const list = peers ?? [];
    const avg = list.length > 0
      ? list.reduce((s: number, p) => s + Number(p.engagement_rate ?? 0), 0) / list.length
      : 0;
    const sameP = list.filter((p) => p.platform === post.platform);
    const sameAvg = sameP.length > 0
      ? sameP.reduce((s: number, p) => s + Number(p.engagement_rate ?? 0), 0) / sameP.length
      : 0;

    return {
      kind: "metric" as const,
      description: `Engagement performance for this ${post.platform} post vs. competitor's rolling averages.`,
      breakdown: [
        { label: "This post engagement", value: `${Number(post.engagement_rate ?? 0).toFixed(2)}%` },
        { label: "Competitor avg (all platforms)", value: `${avg.toFixed(2)}%` },
        { label: `Competitor avg on ${post.platform}`, value: `${sameAvg.toFixed(2)}%` },
        { label: "Sample size", value: String(list.length) },
      ],
    };
  });
