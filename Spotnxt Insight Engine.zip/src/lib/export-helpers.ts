/**
 * Pure helpers shared between CSV/PDF/bulk exports and their tests.
 * Keeping evidence-row assembly in one place is what lets the parity tests
 * assert CSV and PDF describe the same underlying posts/metrics.
 */

export type EvidencePost = {
  id: string;
  platform: string;
  caption: string | null;
  url: string | null;
  media_url: string | null;
  likes: number;
  comments: number;
  shares: number;
  views: number;
  engagement_rate: number;
  posted_at: string;
};

export type EvidenceLink = {
  id: string;
  source_type: string;
  source_id: string | null;
  snippet: string | null;
};

export type Recommendation = {
  id: string;
  org_id: string;
  title: string;
  body: string | null;
  priority: string;
  status: string;
  created_at?: string;
  evidence_links: EvidenceLink[];
};

export type ExportFilters = {
  platforms?: string[];
  from?: string | null;
  to?: string | null;
};

export type EvidenceRow = {
  recommendation_id: string;
  recommendation_title: string;
  priority: string;
  evidence_id: string;
  evidence_kind: string;
  post_id: string | null;
  platform: string | null;
  posted_at: string | null;
  engagement_rate: number | null;
  likes: number | null;
  comments: number | null;
  shares: number | null;
  views: number | null;
  caption: string | null;
  media_url: string | null;
  url: string | null;
  snippet: string | null;
};

/**
 * Assemble the canonical list of evidence rows for one recommendation.
 * Rows are filtered against platform/date filters when the evidence resolves
 * to a post. Same input → same rows → the CSV and PDF exports stay in sync.
 */
export function buildEvidenceRows(
  rec: Recommendation,
  posts: EvidencePost[],
  filters: ExportFilters = {},
): EvidenceRow[] {
  const byId = new Map(posts.map((p) => [p.id, p]));
  const hasFilter = Boolean(filters.platforms?.length || filters.from || filters.to);
  const rows: EvidenceRow[] = [];
  for (const e of rec.evidence_links ?? []) {
    const p = e.source_type === "post" && e.source_id ? byId.get(e.source_id) : undefined;
    // If a filter is active and the evidence is a post that didn't match, drop it.
    if (e.source_type === "post" && !p && hasFilter) continue;
    rows.push({
      recommendation_id: rec.id,
      recommendation_title: rec.title,
      priority: rec.priority,
      evidence_id: e.id,
      evidence_kind: e.source_type,
      post_id: p?.id ?? e.source_id ?? null,
      platform: p?.platform ?? null,
      posted_at: p?.posted_at ?? null,
      engagement_rate: p?.engagement_rate ?? null,
      likes: p?.likes ?? null,
      comments: p?.comments ?? null,
      shares: p?.shares ?? null,
      views: p?.views ?? null,
      caption: p?.caption ?? null,
      media_url: p?.media_url ?? null,
      url: p?.url ?? null,
      snippet: e.snippet ?? null,
    });
  }
  return rows;
}

export const CSV_COLUMNS = [
  "recommendation_title",
  "priority",
  "evidence_kind",
  "post_id",
  "platform",
  "posted_at",
  "engagement_rate",
  "likes",
  "comments",
  "shares",
  "views",
  "caption",
  "media_url",
  "url",
  "snippet",
] as const;
export type CsvColumn = (typeof CSV_COLUMNS)[number];

export type CsvTemplateConfig = { columns?: CsvColumn[] };
export type PdfTemplateConfig = {
  sections?: {
    summary?: boolean;
    metrics?: boolean;
    thumbnails?: boolean;
    evidenceTable?: boolean;
    snippets?: boolean;
  };
  orientation?: "portrait" | "landscape";
};

function pickColumns(cfg?: CsvTemplateConfig): CsvColumn[] {
  const valid = new Set<string>(CSV_COLUMNS);
  const list = (cfg?.columns ?? []).filter((c): c is CsvColumn => valid.has(c));
  return list.length ? list : [...CSV_COLUMNS];
}

export function csvHeader(cfg?: CsvTemplateConfig): string {
  return pickColumns(cfg).join(",");
}

export function csvEscape(v: unknown): string {
  const s = v == null ? "" : String(v);
  return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

function rowValue(r: EvidenceRow, col: CsvColumn): unknown {
  const v = (r as unknown as Record<string, unknown>)[col];
  return v ?? "";
}

export function csvLineFromRow(r: EvidenceRow, cfg?: CsvTemplateConfig): string {
  return pickColumns(cfg).map((c) => csvEscape(rowValue(r, c))).join(",");
}

export function buildCsv(rows: EvidenceRow[], cfg?: CsvTemplateConfig): string {
  return [csvHeader(cfg), ...rows.map((r) => csvLineFromRow(r, cfg))].join("\n");
}

export function slugForTitle(title: string): string {
  return title.replace(/[^a-z0-9]+/gi, "-").toLowerCase().slice(0, 60);
}
