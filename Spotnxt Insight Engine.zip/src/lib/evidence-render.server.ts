/**
 * Server-only helpers for building evidence artifacts (CSV / PDF / ZIP).
 * Blocked from client bundles via the .server.ts suffix.
 *
 * Kept separate from ingestion.functions.ts so both the sync export
 * server functions and the async export worker share the exact same
 * evidence-loading and PDF-rendering logic — one source of truth.
 */

import {
  buildEvidenceRows,
  buildCsv,
  type CsvTemplateConfig,
  type PdfTemplateConfig,
  type EvidencePost,
  type ExportFilters,
  type Recommendation,
} from "./export-helpers";

export type EvidenceEntry = {
  rec: Recommendation;
  filters: ExportFilters;
  rows: ReturnType<typeof buildEvidenceRows>;
  postsById: Map<string, EvidencePost>;
};

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export async function loadRecommendationEvidence(
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  supabase: any,
  input: {
    recommendationId: string;
    platforms?: string[];
    from?: string | null;
    to?: string | null;
  },
): Promise<{ rec: Recommendation; posts: EvidencePost[] }> {
  const { data: rec, error } = await supabase
    .from("recommendations")
    .select(
      "id, org_id, title, body, priority, status, created_at, evidence_links(id, source_type, source_id, snippet)",
    )
    .eq("id", input.recommendationId)
    .maybeSingle();
  if (error || !rec) throw new Error("Recommendation not found");

  const postIds = ((rec as Recommendation).evidence_links ?? [])
    .filter((e) => e.source_type === "post" && !!e.source_id)
    .map((e) => e.source_id as string);

  let posts: EvidencePost[] = [];
  if (postIds.length > 0) {
    let q = supabase
      .from("posts")
      .select(
        "id, platform, caption, url, media_url, likes, comments, shares, views, engagement_rate, posted_at",
      )
      .in("id", postIds);
    if (input.platforms && input.platforms.length > 0) {
      q = q.in(
        "platform",
        input.platforms as ("facebook" | "instagram" | "linkedin" | "tiktok" | "x" | "youtube")[],
      );
    }
    if (input.from) q = q.gte("posted_at", input.from);
    if (input.to) q = q.lte("posted_at", input.to);
    const { data: rows } = await q;
    posts = (rows ?? []) as EvidencePost[];
  }
  return { rec: rec as Recommendation, posts };
}

export async function buildEntry(
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  supabase: any,
  recommendationId: string,
  filters: ExportFilters,
): Promise<EvidenceEntry> {
  const { rec, posts } = await loadRecommendationEvidence(supabase, {
    recommendationId,
    platforms: filters.platforms,
    from: filters.from,
    to: filters.to,
  });
  const rows = buildEvidenceRows(rec, posts, filters);
  const postsById = new Map(posts.map((p) => [p.id, p]));
  return { rec, filters, rows, postsById };
}

export async function renderEvidencePdf(sections: {
  title: string;
  subtitle?: string;
  entries: EvidenceEntry[];
  onProgress?: (frac: number) => Promise<void> | void;
  pdfConfig?: PdfTemplateConfig;
}): Promise<{ base64: string; rowCount: number }> {
  const cfg = sections.pdfConfig?.sections ?? {};
  const showSummary = cfg.summary !== false;
  const showMetrics = cfg.metrics !== false;
  const showTable = cfg.evidenceTable !== false;
  const showSnippets = cfg.snippets !== false;
  const showThumbnails = cfg.thumbnails !== false; // links to media_url when present
  const { PDFDocument, StandardFonts, rgb } = await import("pdf-lib");
  const pdf = await PDFDocument.create();
  const font = await pdf.embedFont(StandardFonts.Helvetica);
  const bold = await pdf.embedFont(StandardFonts.HelveticaBold);

  let page = pdf.addPage([595, 842]);
  const margin = 40;
  let y = 802;
  const sanitize = (s: string) => s.replace(/[^\x20-\x7E\xA0-\xFF]/g, "?");
  const line = (
    text: string,
    opts: { size?: number; bold?: boolean; color?: [number, number, number] } = {},
  ) => {
    const size = opts.size ?? 10;
    if (y < margin + size + 4) {
      page = pdf.addPage([595, 842]);
      y = 802;
    }
    const clean = sanitize(text);
    const max = 100;
    const chunks: string[] = [];
    for (let i = 0; i < clean.length; i += max) chunks.push(clean.slice(i, i + max));
    for (const chunk of chunks.length ? chunks : [""]) {
      if (y < margin + size + 4) {
        page = pdf.addPage([595, 842]);
        y = 802;
      }
      page.drawText(chunk, {
        x: margin,
        y,
        size,
        font: opts.bold ? bold : font,
        color: rgb(...(opts.color ?? [0.1, 0.1, 0.15])),
      });
      y -= size + 3;
    }
  };
  const hr = () => {
    page.drawLine({
      start: { x: margin, y: y - 2 },
      end: { x: 595 - margin, y: y - 2 },
      thickness: 0.5,
      color: rgb(0.8, 0.8, 0.85),
    });
    y -= 8;
  };

  line(sections.title, { size: 18, bold: true });
  if (sections.subtitle) line(sections.subtitle, { size: 10, color: [0.45, 0.45, 0.5] });
  line(`Generated: ${new Date().toISOString()}`, { size: 9, color: [0.45, 0.45, 0.5] });
  hr();

  let totalRows = 0;
  const total = sections.entries.length || 1;
  let done = 0;
  for (const entry of sections.entries) {
    const { rec, filters, rows, postsById } = entry;
    if (showSummary) {
      line(rec.title, { size: 13, bold: true });
      line(`Priority: ${rec.priority}   ·   Status: ${rec.status}`, {
        size: 9,
        color: [0.45, 0.45, 0.5],
      });
      if (rec.body) line(rec.body, { size: 10 });

      const filterBits: string[] = [];
      if (filters.platforms?.length) filterBits.push(`platforms=${filters.platforms.join(",")}`);
      if (filters.from) filterBits.push(`from=${filters.from}`);
      if (filters.to) filterBits.push(`to=${filters.to}`);
      if (filterBits.length) line(`Filters: ${filterBits.join(" · ")}`, { size: 9, color: [0.45, 0.45, 0.5] });
    }

    if (showTable) {
      line(`Evidence (${rows.length})`, { size: 11, bold: true });
      let idx = 0;
      for (const r of rows) {
        idx += 1;
        totalRows += 1;
        const p = r.post_id ? postsById.get(r.post_id) : undefined;
        line(
          `${idx}. [${r.evidence_kind}] ${p ? `${p.platform.toUpperCase()} · ${p.posted_at.slice(0, 10)}` : r.post_id ?? ""}`,
          { size: 10, bold: true },
        );
        if (p && showMetrics) {
          line(
            `   Engagement ${p.engagement_rate}%   likes ${p.likes}   comments ${p.comments}   shares ${p.shares}   views ${p.views}`,
            { size: 9 },
          );
        }
        if (p?.caption && showSnippets) line(`   "${p.caption}"`, { size: 9, color: [0.3, 0.3, 0.35] });
        if (p?.url) line(`   ${p.url}`, { size: 8, color: [0.2, 0.4, 0.85] });
        if (p?.media_url && showThumbnails) line(`   media: ${p.media_url}`, { size: 8, color: [0.45, 0.45, 0.5] });
        if (r.snippet && showSnippets) line(`   note: ${r.snippet}`, { size: 9, color: [0.3, 0.3, 0.35] });
        y -= 2;
      }
    } else {
      totalRows += rows.length;
    }
    hr();
    done += 1;
    if (sections.onProgress) await sections.onProgress(done / total);
  }

  const bytes = await pdf.save();
  let bin = "";
  for (let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
  const base64 = typeof btoa !== "undefined" ? btoa(bin) : Buffer.from(bytes).toString("base64");
  return { base64, rowCount: totalRows };
}

/** Build a ZIP with one CSV per recommendation plus a combined-evidence PDF. */
export async function renderEvidenceZip(
  entries: EvidenceEntry[],
  onProgress?: (frac: number) => Promise<void> | void,
  templates?: { csvConfig?: CsvTemplateConfig; pdfConfig?: PdfTemplateConfig },
): Promise<{ base64: string; rowCount: number }> {
  const { zipSync, strToU8 } = await import("fflate");
  const files: Record<string, Uint8Array> = {};

  let totalRows = 0;
  entries.forEach((e, i) => {
    const csv = buildCsv(e.rows, templates?.csvConfig);
    const slug = (e.rec.title || `rec-${i + 1}`).replace(/[^a-z0-9]+/gi, "-").toLowerCase().slice(0, 60);
    files[`${String(i + 1).padStart(2, "0")}-${slug}.csv`] = strToU8(csv);
    totalRows += e.rows.length;
  });

  if (onProgress) await onProgress(0.4);

  const pdf = await renderEvidencePdf({
    title: "Evidence Bundle",
    subtitle: `${entries.length} recommendation(s)`,
    entries,
    pdfConfig: templates?.pdfConfig,
    onProgress: onProgress
      ? async (frac) => {
          await onProgress(0.4 + frac * 0.5);
        }
      : undefined,
  });
  const pdfBytes = Uint8Array.from(atob(pdf.base64), (c) => c.charCodeAt(0));
  files["bundle.pdf"] = pdfBytes;

  const manifest = {
    generated_at: new Date().toISOString(),
    recommendation_count: entries.length,
    total_rows: totalRows,
    recommendations: entries.map((e) => ({
      id: e.rec.id,
      title: e.rec.title,
      priority: e.rec.priority,
      rows: e.rows.length,
    })),
  };
  files["manifest.json"] = strToU8(JSON.stringify(manifest, null, 2));

  const zipped = zipSync(files, { level: 6 });
  let bin = "";
  for (let i = 0; i < zipped.length; i++) bin += String.fromCharCode(zipped[i]);
  const base64 = typeof btoa !== "undefined" ? btoa(bin) : Buffer.from(zipped).toString("base64");
  if (onProgress) await onProgress(1);
  return { base64, rowCount: totalRows };
}
