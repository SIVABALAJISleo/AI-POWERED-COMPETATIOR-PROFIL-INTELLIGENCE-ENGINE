/**
 * Async export pipeline with retention, RBAC, and notifications.
 *
 * - Every CSV/PDF/ZIP request creates a durable `exports` row streamed via Realtime.
 * - Failed exports keep original params for a one-click retry.
 * - Downloads and retries are RBAC-scoped: only the requester or a workspace
 *   admin/owner can act on an export.
 * - On completion or failure the requester receives an in-app notification and
 *   (best-effort) an email through the Lovable email API.
 * - Expired artifacts are purged lazily whenever the history is listed.
 */

import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";
import {
  buildCsv,
  slugForTitle,
  CSV_COLUMNS,
  type CsvColumn,
  type CsvTemplateConfig,
  type PdfTemplateConfig,
  type ExportFilters,
} from "./export-helpers";

const filterSchema = z.object({
  platforms: z.array(z.string()).optional(),
  from: z.string().datetime().optional().nullable(),
  to: z.string().datetime().optional().nullable(),
});

const csvColumnSchema = z.enum(CSV_COLUMNS as unknown as [CsvColumn, ...CsvColumn[]]);
const csvTemplateSchema = z.object({ columns: z.array(csvColumnSchema).optional() });
const pdfTemplateSchema = z.object({
  sections: z
    .object({
      summary: z.boolean().optional(),
      metrics: z.boolean().optional(),
      thumbnails: z.boolean().optional(),
      evidenceTable: z.boolean().optional(),
      snippets: z.boolean().optional(),
    })
    .optional(),
  orientation: z.enum(["portrait", "landscape"]).optional(),
});

const enqueueSchema = z.object({
  kind: z.enum(["csv", "pdf", "bulk_pdf", "zip"]),
  recommendationIds: z.array(z.string().uuid()).min(1).max(50),
  filters: filterSchema.optional().default({}),
  templateId: z.string().uuid().optional(),
  templateConfig: z
    .object({
      csv: csvTemplateSchema.optional(),
      pdf: pdfTemplateSchema.optional(),
    })
    .optional(),
});

/* eslint-disable @typescript-eslint/no-explicit-any */
async function logAudit(
  supabase: any,
  entry: {
    org_id: string;
    actor_user_id: string | null;
    action: string;
    target_type?: string | null;
    target_id?: string | null;
    metadata?: Record<string, unknown>;
  },
) {
  try {
    await supabase.from("audit_events").insert({
      org_id: entry.org_id,
      actor_user_id: entry.actor_user_id,
      action: entry.action,
      target_type: entry.target_type ?? null,
      target_id: entry.target_id ?? null,
      metadata: entry.metadata ?? {},
    });
  } catch {
    /* audit failures never break the flow */
  }
}

async function getMembership(
  supabase: any,
  orgId: string,
  userId: string,
): Promise<{ role: "owner" | "admin" | "analyst" | "viewer" } | null> {
  const { data } = await supabase
    .from("organization_members")
    .select("role")
    .eq("org_id", orgId)
    .eq("user_id", userId)
    .maybeSingle();
  return data ?? null;
}

async function resolveOrg(
  supabase: any,
  userId: string,
  recommendationIds: string[],
): Promise<string> {
  const { data: recs, error } = await supabase
    .from("recommendations")
    .select("id, org_id")
    .in("id", recommendationIds);
  if (error) throw error;
  if (!recs || recs.length === 0) throw new Error("Recommendations not found");
  const orgIds = new Set((recs as { org_id: string }[]).map((r) => r.org_id));
  if (orgIds.size !== 1)
    throw new Error("All selected recommendations must belong to the same workspace");
  const orgId = [...orgIds][0];
  const mem = await getMembership(supabase, orgId, userId);
  if (!mem) throw new Error("Forbidden");
  return orgId;
}

/* ================ enqueue ================ */

export const enqueueExport = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => enqueueSchema.parse(data))
  .handler(async ({ data, context }) => {
    const orgId = await resolveOrg(context.supabase, context.userId, data.recommendationIds);

    if ((data.kind === "csv" || data.kind === "pdf") && data.recommendationIds.length !== 1) {
      throw new Error(`${data.kind.toUpperCase()} export takes exactly one recommendation`);
    }

    const mime =
      data.kind === "csv"
        ? "text/csv"
        : data.kind === "zip"
        ? "application/zip"
        : "application/pdf";
    const format = data.kind === "csv" ? "csv" : data.kind === "zip" ? "zip" : "pdf";

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    // Resolve template: explicit id > inline config > org default for kind.
    // A resolved template locks its current_version onto the export so retries
    // and history always render the exact configuration that was used.
    let template: {
      id: string | null;
      version: number | null;
      csv?: CsvTemplateConfig;
      pdf?: PdfTemplateConfig;
    } | null = null;
    if (data.templateId) {
      const { data: t } = await (supabaseAdmin as unknown as {
        from: (n: string) => { select: (s: string) => { eq: (c: string, v: string) => { maybeSingle: () => Promise<{ data: { id: string; kind: string; config: unknown; org_id: string; current_version: number } | null }> } } };
      })
        .from("export_templates")
        .select("id, kind, config, org_id, current_version")
        .eq("id", data.templateId)
        .maybeSingle();
      if (!t || t.org_id !== orgId) throw new Error("Template not found in workspace");
      const cfg = (t.config ?? {}) as { csv?: CsvTemplateConfig; pdf?: PdfTemplateConfig };
      template = { id: t.id, version: t.current_version ?? 1, csv: cfg.csv, pdf: cfg.pdf };
    } else if (data.templateConfig) {
      template = { id: null, version: null, csv: data.templateConfig.csv, pdf: data.templateConfig.pdf };
    } else {
      const templateKind = data.kind === "csv" ? "csv" : "pdf";
      const { data: def } = await (supabaseAdmin as unknown as {
        from: (n: string) => { select: (s: string) => { eq: (c: string, v: string) => { eq: (c: string, v: string) => { eq: (c: string, v: boolean) => { maybeSingle: () => Promise<{ data: { id: string; kind: string; config: unknown; current_version: number } | null }> } } } } };
      })
        .from("export_templates")
        .select("id, kind, config, current_version")
        .eq("org_id", orgId)
        .eq("kind", templateKind)
        .eq("is_default", true)
        .maybeSingle();
      if (def) {
        const cfg = (def.config ?? {}) as { csv?: CsvTemplateConfig; pdf?: PdfTemplateConfig };
        template = { id: def.id, version: def.current_version ?? 1, csv: cfg.csv, pdf: cfg.pdf };
      }
    }

    const { data: inserted, error } = await supabaseAdmin
      .from("exports")
      .insert({
        org_id: orgId,
        kind: data.kind,
        format,
        mime_type: mime,
        status: "pending",
        progress: 0,
        params: {
          recommendation_ids: data.recommendationIds,
          filters: data.filters,
          template: template
            ? {
                id: template.id,
                version: template.version,
                csv: template.csv ?? null,
                pdf: template.pdf ?? null,
              }
            : null,
        },
        requested_by: context.userId,
      })
      .select("id")
      .single();
    if (error || !inserted) throw error ?? new Error("Failed to enqueue export");

    await logAudit(context.supabase, {
      org_id: orgId,
      actor_user_id: context.userId,
      action: "export.enqueue",
      target_type: "export",
      target_id: inserted.id,
      metadata: {
        kind: data.kind,
        recommendation_ids: data.recommendationIds,
        filters: data.filters ?? {},
        template_id: template?.id ?? null,
        template_version: template?.version ?? null,
      },
    });

    void processExportInternal(inserted.id).catch(() => {});
    return { id: inserted.id as string };
  });

/* ================ list w/ filters ================ */

const listSchema = z.object({
  orgId: z.string().uuid().optional(),
  competitorId: z.string().uuid().optional(),
  kinds: z.array(z.enum(["csv", "pdf", "bulk_pdf", "zip"])).optional(),
  statuses: z.array(z.enum(["pending", "running", "done", "failed", "expired"])).optional(),
  from: z.string().datetime().optional(),
  to: z.string().datetime().optional(),
  search: z.string().max(200).optional(),
  limit: z.number().int().min(1).max(200).optional().default(50),
});

export const listExports = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => listSchema.parse(data))
  .handler(async ({ data, context }) => {
    // Lazy purge — cheap: bounded to rows already past retention.
    try {
      const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
      await supabaseAdmin.rpc("purge_expired_exports");
    } catch {
      /* purge is best-effort */
    }

    let q = context.supabase
      .from("exports")
      .select(
        "id, org_id, competitor_id, kind, status, format, filename, mime_type, params, size_bytes, row_count, progress, error, requested_by, created_at, updated_at, completed_at",
      )
      .order("created_at", { ascending: false })
      .limit(data.limit);
    if (data.orgId) q = q.eq("org_id", data.orgId);
    if (data.competitorId) q = q.eq("competitor_id", data.competitorId);
    if (data.kinds && data.kinds.length) q = q.in("kind", data.kinds);
    if (data.statuses && data.statuses.length) q = q.in("status", data.statuses);
    if (data.from) q = q.gte("created_at", data.from);
    if (data.to) q = q.lte("created_at", data.to);
    if (data.search) q = q.ilike("filename", `%${data.search}%`);
    const { data: rows, error } = await q;
    if (error) return [];
    return rows ?? [];
  });

/* ================ retry (RBAC) ================ */

const idSchema = z.object({ id: z.string().uuid() });

async function canManageExport(
  supabase: any,
  userId: string,
  exp: { org_id: string; requested_by: string | null },
): Promise<boolean> {
  if (exp.requested_by === userId) return true;
  const mem = await getMembership(supabase, exp.org_id, userId);
  return mem?.role === "owner" || mem?.role === "admin";
}

export const retryExport = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => idSchema.parse(data))
  .handler(async ({ data, context }) => {
    const { data: exp } = await context.supabase
      .from("exports")
      .select("id, org_id, status, kind, requested_by")
      .eq("id", data.id)
      .maybeSingle();
    if (!exp) throw new Error("Export not found");
    if (!(await canManageExport(context.supabase, context.userId, exp))) {
      throw new Error("Only the requester or a workspace admin can retry this export");
    }

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    // Preserve original params — the retry replays the same `params` row.
    await supabaseAdmin
      .from("exports")
      .update({
        status: "pending",
        error: null,
        progress: 0,
        artifact: null,
        completed_at: null,
      })
      .eq("id", data.id);

    await logAudit(context.supabase, {
      org_id: exp.org_id,
      actor_user_id: context.userId,
      action: "export.retry",
      target_type: "export",
      target_id: data.id,
      metadata: { kind: exp.kind },
    });

    void processExportInternal(data.id).catch(() => {});
    return { ok: true };
  });

/* ================ download (RBAC) ================ */

export const getExportArtifact = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => idSchema.parse(data))
  .handler(async ({ data, context }) => {
    const { data: exp } = await context.supabase
      .from("exports")
      .select(
        "id, org_id, status, filename, mime_type, artifact, format, kind, row_count, size_bytes, requested_by",
      )
      .eq("id", data.id)
      .maybeSingle();
    if (!exp) throw new Error("Export not found");
    if (!(await canManageExport(context.supabase, context.userId, exp))) {
      throw new Error("Only the requester or a workspace admin can download this export");
    }
    if (exp.status === "expired") {
      throw new Error("This export was purged by the workspace retention policy — retry to regenerate.");
    }
    if (exp.status !== "done" || !exp.artifact) {
      throw new Error(`Export not ready (status: ${exp.status})`);
    }

    await logAudit(context.supabase, {
      org_id: exp.org_id,
      actor_user_id: context.userId,
      action: "export.download",
      target_type: "export",
      target_id: data.id,
      metadata: { kind: exp.kind, size_bytes: exp.size_bytes, rows: exp.row_count },
    });

    return {
      filename: exp.filename as string,
      mimeType: exp.mime_type as string,
      base64: exp.artifact as string,
      format: exp.format as string,
      rows: exp.row_count as number,
    };
  });

/* ================ retention settings ================ */

export const getRetentionSettings = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => z.object({ orgId: z.string().uuid() }).parse(data))
  .handler(async ({ data, context }) => {
    const mem = await getMembership(context.supabase, data.orgId, context.userId);
    if (!mem) throw new Error("Forbidden");
    const { data: org } = await context.supabase
      .from("organizations")
      .select("id, name, export_retention_days")
      .eq("id", data.orgId)
      .maybeSingle();
    return {
      orgId: data.orgId,
      retentionDays: (org?.export_retention_days as number) ?? 30,
      canEdit: mem.role === "owner" || mem.role === "admin",
      role: mem.role,
    };
  });

export const setRetentionSettings = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) =>
    z.object({ orgId: z.string().uuid(), retentionDays: z.number().int().min(1).max(365) }).parse(data),
  )
  .handler(async ({ data, context }) => {
    const mem = await getMembership(context.supabase, data.orgId, context.userId);
    if (!mem || (mem.role !== "owner" && mem.role !== "admin")) {
      throw new Error("Only workspace admins can change retention");
    }
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    await supabaseAdmin
      .from("organizations")
      .update({ export_retention_days: data.retentionDays })
      .eq("id", data.orgId);

    await logAudit(context.supabase, {
      org_id: data.orgId,
      actor_user_id: context.userId,
      action: "retention.update",
      target_type: "organization",
      target_id: data.orgId,
      metadata: { retention_days: data.retentionDays },
    });

    // Trigger immediate purge to reflect the new policy.
    try {
      await supabaseAdmin.rpc("purge_expired_exports");
    } catch { /* best-effort */ }

    return { ok: true, retentionDays: data.retentionDays };
  });

/* ================ Worker + notifications ================ */

function humanizeError(msg: string): { title: string; hint: string } {
  const m = msg.toLowerCase();
  if (m.includes("not ready") || m.includes("running")) {
    return { title: "Not ready", hint: "Export still processing — wait for it to finish." };
  }
  if (m.includes("recommendations not found") || m.includes("not found")) {
    return {
      title: "Missing data",
      hint: "Underlying recommendation was deleted. Regenerate recommendations, then retry.",
    };
  }
  if (m.includes("permission") || m.includes("forbidden") || m.includes("rls")) {
    return {
      title: "Permission denied",
      hint: "You don't have access. Ask a workspace admin, or sign in with the correct account.",
    };
  }
  if (m.includes("timeout") || m.includes("timed out")) {
    return {
      title: "Timed out",
      hint: "Batch too large — narrow the date range or export fewer items, then retry.",
    };
  }
  if (m.includes("network") || m.includes("fetch")) {
    return { title: "Network error", hint: "Transient upstream failure. Retry usually resolves it." };
  }
  if (m.includes("belong to the same workspace")) {
    return {
      title: "Cross-workspace selection",
      hint: "Only recommendations from a single workspace can be exported together.",
    };
  }
  return { title: "Export failed", hint: "Retry, or contact support if the error persists." };
}

async function notify(
  supabase: any,
  userId: string,
  orgId: string,
  entry: {
    kind: string;
    title: string;
    body: string;
    target_type: string;
    target_id: string;
    metadata?: Record<string, unknown>;
  },
) {
  try {
    await supabase.from("notifications").insert({
      user_id: userId,
      org_id: orgId,
      kind: entry.kind,
      title: entry.title,
      body: entry.body,
      target_type: entry.target_type,
      target_id: entry.target_id,
      metadata: entry.metadata ?? {},
    });
  } catch {
    /* non-fatal */
  }
}

async function sendExportEmail(
  supabaseAdmin: any,
  userId: string,
  subject: string,
  html: string,
): Promise<void> {
  try {
    const { data: userRes } = await supabaseAdmin.auth.admin.getUserById(userId);
    const email = userRes?.user?.email;
    if (!email) return;
    const { sendLovableEmail } = await import("@lovable.dev/email-js");
    const text = html
      .replace(/<[^>]+>/g, " ")
      .replace(/\s+/g, " ")
      .trim();
    await sendLovableEmail(
      {
        from: `Spotnxt <notify@${process.env.EMAIL_SENDER_DOMAIN ?? "example.com"}>`,
        to: email,
        subject,
        html,
        text,
      },
      { apiKey: process.env.LOVABLE_API_KEY! },
    );
  } catch {
    /* email is best-effort; requires a verified sender domain */
  }
}

export async function processExportInternal(exportId: string): Promise<void> {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

  const { data: claim } = await supabaseAdmin
    .from("exports")
    .update({ status: "running", progress: 5, error: null })
    .eq("id", exportId)
    .eq("status", "pending")
    .select("id, org_id, kind, params, requested_by")
    .maybeSingle();
  if (!claim) return;

  const params = (claim.params ?? {}) as {
    recommendation_ids: string[];
    filters: ExportFilters;
    template?: {
      id: string | null;
      csv?: CsvTemplateConfig | null;
      pdf?: PdfTemplateConfig | null;
    } | null;
  };
  const csvConfig = params.template?.csv ?? undefined;
  const pdfConfig = params.template?.pdf ?? undefined;

  try {
    const { buildEntry, renderEvidencePdf, renderEvidenceZip } = await import(
      "./evidence-render.server"
    );

    const entries = [] as Awaited<ReturnType<typeof buildEntry>>[];
    for (let i = 0; i < params.recommendation_ids.length; i++) {
      const id = params.recommendation_ids[i];
      entries.push(await buildEntry(supabaseAdmin, id, params.filters ?? {}));
      const pct = 10 + Math.round(((i + 1) / params.recommendation_ids.length) * 30);
      await supabaseAdmin.from("exports").update({ progress: pct }).eq("id", exportId);
    }

    let artifact = "";
    let filename = "";
    let rowCount = 0;
    const dateSlug = new Date().toISOString().slice(0, 10);
    const setProgress = async (p: number) => {
      await supabaseAdmin.from("exports").update({ progress: Math.min(95, p) }).eq("id", exportId);
    };

    if (claim.kind === "csv") {
      const rows = entries[0].rows;
      const csv = buildCsv(rows, csvConfig);
      artifact = typeof btoa !== "undefined" ? btoa(csv) : Buffer.from(csv).toString("base64");
      filename = `evidence-${slugForTitle(entries[0].rec.title)}-${dateSlug}.csv`;
      rowCount = rows.length;
      await setProgress(90);
    } else if (claim.kind === "pdf") {
      const res = await renderEvidencePdf({
        title: "Recommendation Evidence",
        subtitle: entries[0].rec.title,
        entries,
        pdfConfig,
        onProgress: async (f) => setProgress(40 + Math.round(f * 50)),
      });
      artifact = res.base64;
      filename = `evidence-${slugForTitle(entries[0].rec.title)}-${dateSlug}.pdf`;
      rowCount = res.rowCount;
    } else if (claim.kind === "bulk_pdf") {
      const res = await renderEvidencePdf({
        title: "Evidence Bundle",
        subtitle: `${entries.length} recommendation(s)`,
        entries,
        pdfConfig,
        onProgress: async (f) => setProgress(40 + Math.round(f * 50)),
      });
      artifact = res.base64;
      filename = `evidence-bundle-${dateSlug}.pdf`;
      rowCount = res.rowCount;
    } else if (claim.kind === "zip") {
      const res = await renderEvidenceZip(
        entries,
        async (f) => setProgress(40 + Math.round(f * 55)),
        { csvConfig, pdfConfig },
      );
      artifact = res.base64;
      filename = `evidence-bundle-${dateSlug}.zip`;
      rowCount = res.rowCount;
    } else {
      throw new Error(`Unknown export kind: ${claim.kind}`);
    }

    const sizeBytes = Math.round((artifact.length * 3) / 4);

    await supabaseAdmin
      .from("exports")
      .update({
        status: "done",
        progress: 100,
        artifact,
        filename,
        row_count: rowCount,
        size_bytes: sizeBytes,
        completed_at: new Date().toISOString(),
      })
      .eq("id", exportId);

    await logAudit(supabaseAdmin, {
      org_id: claim.org_id,
      actor_user_id: claim.requested_by ?? null,
      action: "export.complete",
      target_type: "export",
      target_id: exportId,
      metadata: { kind: claim.kind, rows: rowCount, size_bytes: sizeBytes, filename },
    });

    await dispatchWebhooks(supabaseAdmin, claim.org_id, "export.complete", {
      export_id: exportId,
      kind: claim.kind,
      filename,
      rows: rowCount,
      size_bytes: sizeBytes,
      requested_by: claim.requested_by,
    });

    if (claim.requested_by) {
      await notify(supabaseAdmin, claim.requested_by, claim.org_id, {
        kind: "export.complete",
        title: `${claim.kind.toUpperCase()} export ready`,
        body: `${filename} · ${rowCount} row${rowCount === 1 ? "" : "s"}`,
        target_type: "export",
        target_id: exportId,
        metadata: { kind: claim.kind, filename, rows: rowCount, size_bytes: sizeBytes },
      });
      await sendExportEmail(
        supabaseAdmin,
        claim.requested_by,
        `[Spotnxt] Your ${claim.kind.toUpperCase()} export is ready`,
        `<h2>Export ready</h2>
         <p><strong>${filename}</strong></p>
         <p>${rowCount} row${rowCount === 1 ? "" : "s"} · ${(sizeBytes / 1024).toFixed(1)} KB</p>
         <p>Download it from the Export history panel in Spotnxt.</p>`,
      );
    }
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    const humanized = humanizeError(msg);
    await supabaseAdmin
      .from("exports")
      .update({ status: "failed", error: msg, completed_at: new Date().toISOString() })
      .eq("id", exportId);

    await logAudit(supabaseAdmin, {
      org_id: claim.org_id,
      actor_user_id: claim.requested_by ?? null,
      action: "export.failed",
      target_type: "export",
      target_id: exportId,
      metadata: { kind: claim.kind, error: msg },
    });

    await dispatchWebhooks(supabaseAdmin, claim.org_id, "export.failed", {
      export_id: exportId,
      kind: claim.kind,
      error: msg,
      hint: humanized.hint,
      requested_by: claim.requested_by,
    });

    if (claim.requested_by) {
      await notify(supabaseAdmin, claim.requested_by, claim.org_id, {
        kind: "export.failed",
        title: `${claim.kind.toUpperCase()} export failed — ${humanized.title}`,
        body: humanized.hint,
        target_type: "export",
        target_id: exportId,
        metadata: { kind: claim.kind, error: msg, hint: humanized.hint },
      });
      await sendExportEmail(
        supabaseAdmin,
        claim.requested_by,
        `[Spotnxt] ${claim.kind.toUpperCase()} export failed`,
        `<h2>${humanized.title}</h2>
         <p>${humanized.hint}</p>
         <p style="color:#64748b;font-size:12px">Details: ${msg}</p>
         <p>Retry from the Export history panel in Spotnxt.</p>`,
      );
    }
  }
}

/* ================ Webhook dispatch, retries, DLQ ================ */

async function hmacHex(secret: string, payload: string): Promise<string> {
  const enc = new TextEncoder();
  const key = await crypto.subtle.importKey(
    "raw",
    enc.encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );
  const sig = await crypto.subtle.sign("HMAC", key, enc.encode(payload));
  return Array.from(new Uint8Array(sig))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

/** Exponential backoff with jitter; capped at 6 hours. */
function backoffMs(attempt: number): number {
  const base = Math.min(6 * 60 * 60_000, 30_000 * Math.pow(2, Math.max(0, attempt - 1)));
  const jitter = Math.random() * base * 0.2;
  return Math.floor(base + jitter);
}

type WebhookRow = {
  id: string;
  org_id: string;
  url: string;
  secret: string;
  events: string[];
  enabled: boolean;
  signing_version: string;
  require_timestamp: boolean;
  timestamp_tolerance_seconds: number;
  max_attempts: number;
};

function newDeliveryKey(): string {
  const bytes = new Uint8Array(16);
  crypto.getRandomValues(bytes);
  return Array.from(bytes).map((b) => b.toString(16).padStart(2, "0")).join("");
}

async function attemptDelivery(
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  supabaseAdmin: any,
  hook: WebhookRow,
  delivery: {
    id: string;
    attempts: number;
    payload: Record<string, unknown>;
    event: string;
    idempotency_key?: string | null;
    correlation_id?: string | null;
  },
): Promise<{ ok: boolean; status: number; body: string; error?: string }> {
  const timestamp = Math.floor(Date.now() / 1000);
  const bodyStr = JSON.stringify(delivery.payload);
  const version = hook.signing_version || "v1";
  const signingInput = version === "v2" ? `${timestamp}.${bodyStr}` : bodyStr;
  const signature = await hmacHex(hook.secret, signingInput);

  const headers: Record<string, string> = {
    "content-type": "application/json",
    "x-spotnxt-event": delivery.event,
    "x-spotnxt-signature": `sha256=${signature}`,
    "x-spotnxt-signing-version": version,
    "x-spotnxt-delivery-id": delivery.id,
    "x-spotnxt-attempt": String(delivery.attempts + 1),
  };
  if (delivery.idempotency_key) headers["x-spotnxt-idempotency-key"] = delivery.idempotency_key;
  if (delivery.correlation_id) headers["x-spotnxt-correlation-id"] = delivery.correlation_id;
  if (version === "v2" || hook.require_timestamp) {
    headers["x-spotnxt-timestamp"] = String(timestamp);
  }

  let status = 0;
  let responseText = "";
  let ok = false;
  let error: string | undefined;
  try {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 15_000);
    const res = await fetch(hook.url, { method: "POST", headers, body: bodyStr, signal: ctrl.signal });
    clearTimeout(timer);
    status = res.status;
    responseText = (await res.text()).slice(0, 2000);
    ok = res.ok;
    if (!ok) error = `HTTP ${status}`;
  } catch (err) {
    error = err instanceof Error ? err.message : String(err);
    responseText = error;
  }

  const attempts = delivery.attempts + 1;
  const maxAttempts = hook.max_attempts ?? 6;
  const dead = !ok && attempts >= maxAttempts;
  const nextRetryAt = ok || dead ? null : new Date(Date.now() + backoffMs(attempts)).toISOString();

  await supabaseAdmin
    .from("export_webhook_deliveries")
    .update({
      status: ok ? "delivered" : dead ? "dead_letter" : "retry",
      status_code: status,
      response_body: responseText,
      attempts,
      error: error ?? null,
      next_retry_at: nextRetryAt,
      dead_lettered: dead,
      delivered_at: ok ? new Date().toISOString() : null,
      signed_timestamp: timestamp,
    })
    .eq("id", delivery.id);

  if (ok) {
    await supabaseAdmin
      .from("export_webhooks")
      .update({ consecutive_failures: 0, last_failure_at: null, last_failure_reason: null })
      .eq("id", hook.id);
  } else {
    const { data: current } = await supabaseAdmin
      .from("export_webhooks")
      .select("consecutive_failures")
      .eq("id", hook.id)
      .maybeSingle();
    await supabaseAdmin
      .from("export_webhooks")
      .update({
        last_failure_at: new Date().toISOString(),
        last_failure_reason: (error ?? responseText).slice(0, 500),
        consecutive_failures: (current?.consecutive_failures ?? 0) + 1,
      })
      .eq("id", hook.id);
  }

  return { ok, status, body: responseText, error };
}

/* eslint-disable-next-line @typescript-eslint/no-explicit-any */
async function dispatchWebhooks(
  supabaseAdmin: any,
  orgId: string,
  event: "export.complete" | "export.failed",
  data: Record<string, unknown>,
): Promise<void> {
  try {
    const { data: hooks } = await supabaseAdmin
      .from("export_webhooks")
      .select(
        "id, org_id, url, secret, events, enabled, signing_version, require_timestamp, timestamp_tolerance_seconds, max_attempts",
      )
      .eq("org_id", orgId)
      .eq("enabled", true);
    if (!hooks?.length) return;
    const eligible = (hooks as WebhookRow[]).filter(
      (h) => !h.events?.length || h.events.includes(event),
    );
    for (const h of eligible) {
      const payload = { event, org_id: orgId, delivered_at: new Date().toISOString(), data };
      const exportIdVal = (data.export_id as string) ?? null;
      const idempotencyKey = newDeliveryKey();
      const correlationId = exportIdVal ?? newDeliveryKey();
      const { data: delivery } = await supabaseAdmin
        .from("export_webhook_deliveries")
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        .insert({
          webhook_id: h.id,
          org_id: orgId,
          export_id: exportIdVal,
          event,
          payload,
          status: "pending",
          attempts: 0,
          idempotency_key: idempotencyKey,
          correlation_id: correlationId,
        } as any)
        .select("id, attempts, payload, event, idempotency_key, correlation_id")
        .single();
      if (!delivery) continue;
      await attemptDelivery(supabaseAdmin, h, {
        id: delivery.id as string,
        attempts: delivery.attempts as number,
        payload: (delivery.payload ?? {}) as Record<string, unknown>,
        event: delivery.event as string,
        idempotency_key: (delivery as { idempotency_key?: string | null }).idempotency_key ?? idempotencyKey,
        correlation_id: (delivery as { correlation_id?: string | null }).correlation_id ?? correlationId,
      });
    }
  } catch {
    /* webhook dispatch is best-effort */
  }
}

/** Process due retries. Called by /api/public/hooks/run-webhook-retries. */
export async function processDueWebhookRetries(limit = 25): Promise<{ processed: number }> {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data: due } = await supabaseAdmin
    .from("export_webhook_deliveries")
    .select("id, webhook_id, attempts, payload, event, idempotency_key, correlation_id")
    .lte("next_retry_at", new Date().toISOString())
    .eq("dead_lettered", false)
    .eq("status", "retry")
    .order("next_retry_at", { ascending: true })
    .limit(limit);
  if (!due?.length) return { processed: 0 };

  const hookIds = [...new Set((due as { webhook_id: string }[]).map((d) => d.webhook_id))];
  const { data: hooks } = await supabaseAdmin
    .from("export_webhooks")
    .select(
      "id, org_id, url, secret, events, enabled, signing_version, require_timestamp, timestamp_tolerance_seconds, max_attempts",
    )
    .in("id", hookIds);
  const byId = new Map<string, WebhookRow>(((hooks ?? []) as WebhookRow[]).map((h) => [h.id, h]));

  let processed = 0;
  for (const d of due as Array<{
    id: string;
    webhook_id: string;
    attempts: number;
    payload: Record<string, unknown>;
    event: string;
    idempotency_key: string | null;
    correlation_id: string | null;
  }>) {
    const h = byId.get(d.webhook_id);
    if (!h || !h.enabled) continue;
    await attemptDelivery(supabaseAdmin, h, d);
    processed++;
  }
  return { processed };
}

/** Manual replay of a delivery (including dead-lettered) — creates a fresh attempt. */
export const replayWebhookDelivery = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const { data: delivery } = await context.supabase
      .from("export_webhook_deliveries")
      .select("id, org_id, webhook_id, payload, event, correlation_id")
      .eq("id", data.id)
      .maybeSingle();
    if (!delivery) throw new Error("Delivery not found");
    const mem = await getMembership(context.supabase, delivery.org_id, context.userId);
    if (!mem || (mem.role !== "owner" && mem.role !== "admin")) {
      throw new Error("Only admins can replay webhook deliveries");
    }
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: hook } = await supabaseAdmin
      .from("export_webhooks")
      .select(
        "id, org_id, url, secret, events, enabled, signing_version, require_timestamp, timestamp_tolerance_seconds, max_attempts",
      )
      .eq("id", delivery.webhook_id)
      .maybeSingle();
    if (!hook) throw new Error("Webhook was deleted");
    if (!hook.enabled) throw new Error("Webhook is disabled — enable it before replaying");

    const payloadObj = (delivery.payload ?? {}) as Record<string, unknown>;
    const exportIdVal =
      (payloadObj.data as { export_id?: string } | undefined)?.export_id ?? null;
    // Replays get a NEW idempotency key (a new logical delivery attempt) but
    // preserve the original correlation_id so both rows trace to the same event.
    const idempotencyKey = newDeliveryKey();
    const correlationId =
      (delivery as { correlation_id?: string | null }).correlation_id ?? exportIdVal ?? data.id;
    const { data: fresh } = await supabaseAdmin
      .from("export_webhook_deliveries")
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      .insert({
        webhook_id: hook.id,
        org_id: hook.org_id,
        export_id: exportIdVal,
        event: delivery.event,
        payload: payloadObj,
        status: "pending",
        attempts: 0,
        idempotency_key: idempotencyKey,
        correlation_id: correlationId,
      } as any)
      .select("id, attempts, payload, event, idempotency_key, correlation_id")
      .single();
    if (!fresh) throw new Error("Failed to enqueue replay");

    await logAudit(context.supabase, {
      org_id: hook.org_id,
      actor_user_id: context.userId,
      action: "export.webhook.replay",
      target_type: "export_webhook",
      target_id: hook.id,
      metadata: {
        source_delivery_id: data.id,
        new_delivery_id: fresh.id,
        idempotency_key: idempotencyKey,
        correlation_id: correlationId,
      },
    });

    const result = await attemptDelivery(supabaseAdmin, hook as WebhookRow, {
      id: fresh.id as string,
      attempts: fresh.attempts as number,
      payload: (fresh.payload ?? {}) as Record<string, unknown>,
      event: fresh.event as string,
      idempotency_key: idempotencyKey,
      correlation_id: correlationId,
    });
    return { ok: result.ok, status: result.status, deliveryId: fresh.id };
  });

export const listWebhookDeliveries = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z
      .object({
        orgId: z.string().uuid(),
        webhookId: z.string().uuid().optional(),
        status: z.enum(["pending", "retry", "delivered", "dead_letter"]).optional(),
        deadOnly: z.boolean().optional(),
        limit: z.number().int().min(1).max(200).optional().default(50),
      })
      .parse(d),
  )
  .handler(async ({ data, context }) => {
    const mem = await getMembership(context.supabase, data.orgId, context.userId);
    if (!mem || (mem.role !== "owner" && mem.role !== "admin")) {
      throw new Error("Only admins can view webhook deliveries");
    }
    let q = context.supabase
      .from("export_webhook_deliveries")
      .select(
        "id, webhook_id, org_id, export_id, event, status, attempts, status_code, response_body, error, next_retry_at, delivered_at, dead_lettered, idempotency_key, correlation_id, created_at, updated_at",
      )
      .eq("org_id", data.orgId)
      .order("created_at", { ascending: false })
      .limit(data.limit);
    if (data.webhookId) q = q.eq("webhook_id", data.webhookId);
    if (data.status) q = q.eq("status", data.status);
    if (data.deadOnly) q = q.eq("dead_lettered", true);
    const { data: rows } = await q;
    return rows ?? [];
  });

/* ================ Share links ================ */

function randomToken(len = 32): string {
  const bytes = new Uint8Array(len);
  crypto.getRandomValues(bytes);
  return Array.from(bytes)
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

const createShareLinkSchema = z.object({
  exportId: z.string().uuid(),
  ttlHours: z.number().int().min(1).max(24 * 30).default(24),
  maxDownloads: z.number().int().min(1).max(1000).optional(),
});

export const createExportShareLink = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => createShareLinkSchema.parse(data))
  .handler(async ({ data, context }) => {
    const { data: exp } = await context.supabase
      .from("exports")
      .select("id, org_id, status, requested_by, kind")
      .eq("id", data.exportId)
      .maybeSingle();
    if (!exp) throw new Error("Export not found");
    if (exp.status !== "done") throw new Error("Only completed exports can be shared");
    const mem = await getMembership(context.supabase, exp.org_id, context.userId);
    const isRequester = exp.requested_by === context.userId;
    const isAdmin = mem?.role === "owner" || mem?.role === "admin";
    if (!isRequester && !isAdmin) throw new Error("Only the requester or an admin can share this export");

    const token = randomToken(24);
    const expiresAt = new Date(Date.now() + data.ttlHours * 3600 * 1000).toISOString();

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: row, error } = await supabaseAdmin
      .from("export_share_links")
      .insert({
        export_id: exp.id,
        org_id: exp.org_id,
        token,
        created_by: context.userId,
        expires_at: expiresAt,
        max_downloads: data.maxDownloads ?? 0,
      })
      .select("id, token, expires_at, max_downloads")
      .single();
    if (error || !row) throw error ?? new Error("Failed to create share link");

    await logAudit(context.supabase, {
      org_id: exp.org_id,
      actor_user_id: context.userId,
      action: "export.share.create",
      target_type: "export",
      target_id: exp.id,
      metadata: { token_id: row.id, expires_at: expiresAt, max_downloads: data.maxDownloads ?? null },
    });

    return { id: row.id as string, token: row.token as string, expiresAt: row.expires_at as string };
  });

export const listExportShareLinks = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ exportId: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const { data: exp } = await context.supabase
      .from("exports")
      .select("id, org_id")
      .eq("id", data.exportId)
      .maybeSingle();
    if (!exp) throw new Error("Export not found");
    const mem = await getMembership(context.supabase, exp.org_id, context.userId);
    if (!mem) throw new Error("Forbidden");
    const { data: links } = await context.supabase
      .from("export_share_links")
      .select("id, token, expires_at, max_downloads, download_count, revoked_at, created_at, created_by")
      .eq("export_id", exp.id)
      .order("created_at", { ascending: false });
    return links ?? [];
  });

export const revokeExportShareLink = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const { data: link } = await context.supabase
      .from("export_share_links")
      .select("id, org_id, export_id, created_by")
      .eq("id", data.id)
      .maybeSingle();
    if (!link) throw new Error("Share link not found");
    const mem = await getMembership(context.supabase, link.org_id, context.userId);
    const isCreator = link.created_by === context.userId;
    const isAdmin = mem?.role === "owner" || mem?.role === "admin";
    if (!isCreator && !isAdmin) throw new Error("Only the creator or an admin can revoke this link");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    await supabaseAdmin
      .from("export_share_links")
      .update({ revoked_at: new Date().toISOString() })
      .eq("id", data.id);
    await logAudit(context.supabase, {
      org_id: link.org_id,
      actor_user_id: context.userId,
      action: "export.share.revoke",
      target_type: "export",
      target_id: link.export_id,
      metadata: { token_id: data.id },
    });
    return { ok: true };
  });

/* ================ Export templates ================ */

const templateKindSchema = z.enum(["csv", "pdf"]);
const upsertTemplateSchema = z.object({
  id: z.string().uuid().optional(),
  orgId: z.string().uuid(),
  name: z.string().min(1).max(120),
  kind: templateKindSchema,
  isDefault: z.boolean().optional().default(false),
  config: z.object({ csv: csvTemplateSchema.optional(), pdf: pdfTemplateSchema.optional() }),
});

export const listExportTemplates = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ orgId: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const mem = await getMembership(context.supabase, data.orgId, context.userId);
    if (!mem) throw new Error("Forbidden");
    const { data: rows } = await context.supabase
      .from("export_templates")
      .select("id, org_id, name, kind, config, is_default, created_at, updated_at, created_by")
      .eq("org_id", data.orgId)
      .order("kind", { ascending: true })
      .order("name", { ascending: true });
    return rows ?? [];
  });

function diffTemplate(
  prev: { name?: string; kind?: string; is_default?: boolean; config?: unknown } | null,
  next: { name: string; kind: string; is_default: boolean; config: unknown },
): Record<string, { from: unknown; to: unknown }> {
  const out: Record<string, { from: unknown; to: unknown }> = {};
  if (!prev) return { created: { from: null, to: next } };
  for (const k of ["name", "kind", "is_default", "config"] as const) {
    const a = JSON.stringify(prev[k] ?? null);
    const b = JSON.stringify(next[k] ?? null);
    if (a !== b) out[k] = { from: prev[k] ?? null, to: next[k] };
  }
  return out;
}

export const upsertExportTemplate = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => upsertTemplateSchema.parse(d))
  .handler(async ({ data, context }) => {
    const mem = await getMembership(context.supabase, data.orgId, context.userId);
    if (!mem || (mem.role !== "owner" && mem.role !== "admin" && mem.role !== "analyst")) {
      throw new Error("Insufficient permissions to manage templates");
    }
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    /* eslint-disable @typescript-eslint/no-explicit-any */
    let prev: any = null;
    if (data.id) {
      const { data: cur } = await (supabaseAdmin as any)
        .from("export_templates")
        .select("name, kind, is_default, config, current_version")
        .eq("id", data.id)
        .maybeSingle();
      prev = cur ?? null;
    }

    if (data.isDefault) {
      await supabaseAdmin
        .from("export_templates")
        .update({ is_default: false })
        .eq("org_id", data.orgId)
        .eq("kind", data.kind);
    }
    const nextVersion = (Number(prev?.current_version) || 0) + 1;
    const payload = {
      org_id: data.orgId,
      name: data.name,
      kind: data.kind,
      config: data.config,
      is_default: !!data.isDefault,
      created_by: context.userId,
      current_version: nextVersion,
    };
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const res = data.id
      ? await supabaseAdmin.from("export_templates").update(payload as any).eq("id", data.id).select("id").single()
      : await supabaseAdmin.from("export_templates").insert(payload as any).select("id").single();
    if (res.error) throw res.error;
    const templateId = res.data!.id as string;

    const diff = diffTemplate(prev, {
      name: data.name,
      kind: data.kind,
      is_default: !!data.isDefault,
      config: data.config,
    });

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    await (supabaseAdmin.from("export_template_versions") as any).insert({
      template_id: templateId,
      org_id: data.orgId,
      version: nextVersion,
      name: data.name,
      kind: data.kind,
      config: data.config,
      is_default: !!data.isDefault,
      change_type: data.id ? "update" : "create",
      changed_by: context.userId,
      diff,
    });


    await logAudit(context.supabase, {
      org_id: data.orgId,
      actor_user_id: context.userId,
      action: data.id ? "export.template.update" : "export.template.create",
      target_type: "export_template",
      target_id: templateId,
      metadata: { name: data.name, kind: data.kind, is_default: !!data.isDefault, version: nextVersion, diff: diff as unknown as Record<string, unknown> },
    });
    return { id: templateId, version: nextVersion };
  });

export const deleteExportTemplate = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const { data: t } = await context.supabase
      .from("export_templates")
      .select("id, org_id, kind, name")
      .eq("id", data.id)
      .maybeSingle();
    if (!t) throw new Error("Template not found");
    const mem = await getMembership(context.supabase, t.org_id, context.userId);
    if (!mem || (mem.role !== "owner" && mem.role !== "admin")) {
      throw new Error("Only admins can delete templates");
    }
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    await supabaseAdmin.from("export_templates").delete().eq("id", data.id);
    await logAudit(context.supabase, {
      org_id: t.org_id,
      actor_user_id: context.userId,
      action: "export.template.delete",
      target_type: "export_template",
      target_id: data.id,
      metadata: { name: t.name, kind: t.kind },
    });
    return { ok: true };
  });

/* -------- Template versions: list + rollback -------- */

export const listExportTemplateVersions = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ templateId: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const { data: t } = await context.supabase
      .from("export_templates")
      .select("id, org_id")
      .eq("id", data.templateId)
      .maybeSingle();
    if (!t) throw new Error("Template not found");
    const mem = await getMembership(context.supabase, t.org_id, context.userId);
    if (!mem) throw new Error("Forbidden");
    const { data: rows } = await (context.supabase as any)
      .from("export_template_versions")
      .select("id, template_id, version, name, kind, config, is_default, change_type, changed_by, diff, created_at")
      .eq("template_id", data.templateId)
      .order("version", { ascending: false });
    const list = (rows ?? []) as Array<{ changed_by: string | null } & Record<string, unknown>>;
    const actorIds = [...new Set(list.map((r) => r.changed_by).filter((x): x is string => !!x))];
    let actorMap: Record<string, string> = {};
    if (actorIds.length) {
      const { data: profs } = await context.supabase
        .from("profiles")
        .select("id, display_name")
        .in("id", actorIds);
      actorMap = Object.fromEntries(
        (profs ?? []).map((p: { id: string; display_name: string | null }) => [
          p.id,
          p.display_name ?? p.id.slice(0, 8),
        ]),
      );
    }
    return list.map((r) => ({
      ...r,
      changed_by_name: r.changed_by ? actorMap[r.changed_by] ?? r.changed_by.slice(0, 8) : null,
    }));
  });

export const rollbackExportTemplate = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z.object({ templateId: z.string().uuid(), version: z.number().int().min(1) }).parse(d),
  )
  .handler(async ({ data, context }) => {
    const { data: tRaw } = await (context.supabase as any)
      .from("export_templates")
      .select("id, org_id, current_version")
      .eq("id", data.templateId)
      .maybeSingle();
    const t = tRaw as { id: string; org_id: string; current_version: number } | null;
    if (!t) throw new Error("Template not found");
    const mem = await getMembership(context.supabase, t.org_id, context.userId);
    if (!mem || (mem.role !== "owner" && mem.role !== "admin" && mem.role !== "analyst")) {
      throw new Error("Insufficient permissions");
    }
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: vRaw } = await (supabaseAdmin as any)
      .from("export_template_versions")
      .select("name, kind, config, is_default")
      .eq("template_id", data.templateId)
      .eq("version", data.version)
      .maybeSingle();
    const v = vRaw as { name: string; kind: string; config: unknown; is_default: boolean } | null;
    if (!v) throw new Error("Version not found");

    if (v.is_default) {
      await supabaseAdmin
        .from("export_templates")
        .update({ is_default: false })
        .eq("org_id", t.org_id)
        .eq("kind", v.kind);
    }
    const nextVersion = (Number(t.current_version) || 0) + 1;
    await (supabaseAdmin as any)
      .from("export_templates")
      .update({
        name: v.name,
        kind: v.kind,
        config: v.config,
        is_default: v.is_default,
        current_version: nextVersion,
      })
      .eq("id", data.templateId);
    await (supabaseAdmin as any).from("export_template_versions").insert({
      template_id: data.templateId,
      org_id: t.org_id,
      version: nextVersion,
      name: v.name,
      kind: v.kind,
      config: v.config,
      is_default: v.is_default,
      change_type: "rollback",
      changed_by: context.userId,
      diff: { rolled_back_to: data.version },
    });
    await logAudit(context.supabase, {
      org_id: t.org_id,
      actor_user_id: context.userId,
      action: "export.template.rollback",
      target_type: "export_template",
      target_id: data.templateId,
      metadata: { restored_from_version: data.version, new_version: nextVersion },
    });
    return { ok: true, version: nextVersion };
  });

/* ================ Export webhooks ================ */

const webhookEventSchema = z.enum(["export.complete", "export.failed"]);
const upsertWebhookSchema = z.object({
  id: z.string().uuid().optional(),
  orgId: z.string().uuid(),
  url: z.string().url(),
  events: z.array(webhookEventSchema).min(1),
  isActive: z.boolean().optional().default(true),
  secret: z.string().min(16).max(200).optional(),
  signingVersion: z.enum(["v1", "v2"]).optional().default("v1"),
  requireTimestamp: z.boolean().optional().default(false),
  timestampToleranceSeconds: z.number().int().min(30).max(3600).optional().default(300),
  maxAttempts: z.number().int().min(1).max(20).optional().default(6),
});

export const listExportWebhooks = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ orgId: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const mem = await getMembership(context.supabase, data.orgId, context.userId);
    if (!mem || (mem.role !== "owner" && mem.role !== "admin")) {
      throw new Error("Only admins can view webhooks");
    }
    const { data: rows } = await context.supabase
      .from("export_webhooks")
      .select(
        "id, url, events, enabled, created_at, updated_at, created_by, signing_version, require_timestamp, timestamp_tolerance_seconds, max_attempts, consecutive_failures, last_failure_at, last_failure_reason",
      )
      .eq("org_id", data.orgId)
      .order("created_at", { ascending: false });
    return rows ?? [];
  });

export const upsertExportWebhook = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => upsertWebhookSchema.parse(d))
  .handler(async ({ data, context }) => {
    const mem = await getMembership(context.supabase, data.orgId, context.userId);
    if (!mem || (mem.role !== "owner" && mem.role !== "admin")) {
      throw new Error("Only admins can manage webhooks");
    }
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const secret = data.secret ?? randomToken(32);
    const payload = {
      org_id: data.orgId,
      url: data.url,
      events: data.events,
      enabled: data.isActive ?? true,
      secret,
      created_by: context.userId,
      signing_version: data.signingVersion ?? "v1",
      require_timestamp: data.requireTimestamp ?? false,
      timestamp_tolerance_seconds: data.timestampToleranceSeconds ?? 300,
      max_attempts: data.maxAttempts ?? 6,
    };
    const res = data.id
      ? await supabaseAdmin
          .from("export_webhooks")
          .update(payload)
          .eq("id", data.id)
          .select("id, secret")
          .single()
      : await supabaseAdmin
          .from("export_webhooks")
          .insert(payload)
          .select("id, secret")
          .single();
    if (res.error) throw res.error;
    await logAudit(context.supabase, {
      org_id: data.orgId,
      actor_user_id: context.userId,
      action: data.id ? "export.webhook.update" : "export.webhook.create",
      target_type: "export_webhook",
      target_id: res.data!.id as string,
      metadata: { url: data.url, events: data.events, enabled: data.isActive ?? true },
    });
    return { id: res.data!.id as string, secret: res.data!.secret as string };
  });

export const deleteExportWebhook = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const { data: hook } = await context.supabase
      .from("export_webhooks")
      .select("id, org_id, url")
      .eq("id", data.id)
      .maybeSingle();
    if (!hook) throw new Error("Webhook not found");
    const mem = await getMembership(context.supabase, hook.org_id, context.userId);
    if (!mem || (mem.role !== "owner" && mem.role !== "admin")) {
      throw new Error("Only admins can delete webhooks");
    }
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    await supabaseAdmin.from("export_webhooks").delete().eq("id", data.id);
    await logAudit(context.supabase, {
      org_id: hook.org_id,
      actor_user_id: context.userId,
      action: "export.webhook.delete",
      target_type: "export_webhook",
      target_id: data.id,
      metadata: { url: hook.url },
    });
    return { ok: true };
  });

/* ================ Bulk retry ================ */

export const bulkRetryExports = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z.object({ ids: z.array(z.string().uuid()).min(1).max(50) }).parse(d),
  )
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const results: Array<{ id: string; ok: boolean; error?: string }> = [];
    for (const id of data.ids) {
      try {
        const { data: exp } = await context.supabase
          .from("exports")
          .select("id, org_id, status, kind, requested_by")
          .eq("id", id)
          .maybeSingle();
        if (!exp) throw new Error("Not found");
        if (!(await canManageExport(context.supabase, context.userId, exp))) {
          throw new Error("Forbidden");
        }
        await supabaseAdmin
          .from("exports")
          .update({
            status: "pending",
            error: null,
            progress: 0,
            artifact: null,
            completed_at: null,
          })
          .eq("id", id);
        await logAudit(context.supabase, {
          org_id: exp.org_id,
          actor_user_id: context.userId,
          action: "export.retry",
          target_type: "export",
          target_id: id,
          metadata: { kind: exp.kind, bulk: true },
        });
        void processExportInternal(id).catch(() => {});
        results.push({ id, ok: true });
      } catch (err) {
        results.push({ id, ok: false, error: err instanceof Error ? err.message : String(err) });
      }
    }
    return { results };
  });


/* ================ Regenerate share link ================ */

export const regenerateExportShareLink = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z
      .object({
        id: z.string().uuid(),
        ttlHours: z.number().int().min(1).max(24 * 30).default(24),
        revokeExisting: z.boolean().optional().default(true),
      })
      .parse(d),
  )
  .handler(async ({ data, context }) => {
    const { data: existing } = await context.supabase
      .from("export_share_links")
      .select("id, org_id, export_id, created_by, max_downloads, download_limit_per_min")
      .eq("id", data.id)
      .maybeSingle();
    if (!existing) throw new Error("Share link not found");
    const mem = await getMembership(context.supabase, existing.org_id, context.userId);
    const isCreator = existing.created_by === context.userId;
    const isAdmin = mem?.role === "owner" || mem?.role === "admin";
    if (!isCreator && !isAdmin) {
      throw new Error("Only the creator or an admin can regenerate this link");
    }
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    if (data.revokeExisting) {
      await supabaseAdmin
        .from("export_share_links")
        .update({ revoked_at: new Date().toISOString() })
        .eq("id", data.id)
        .is("revoked_at", null);
    }
    const token = randomToken(24);
    const expiresAt = new Date(Date.now() + data.ttlHours * 3600 * 1000).toISOString();
    const { data: row, error } = await supabaseAdmin
      .from("export_share_links")
      .insert({
        export_id: existing.export_id,
        org_id: existing.org_id,
        token,
        created_by: context.userId,
        expires_at: expiresAt,
        max_downloads: existing.max_downloads ?? 0,
        download_limit_per_min: existing.download_limit_per_min ?? 30,
      })
      .select("id, token, expires_at")
      .single();
    if (error || !row) throw error ?? new Error("Failed to regenerate share link");
    await logAudit(context.supabase, {
      org_id: existing.org_id,
      actor_user_id: context.userId,
      action: "export.share.regenerate",
      target_type: "export",
      target_id: existing.export_id,
      metadata: {
        old_token_id: existing.id,
        new_token_id: row.id,
        revoked_previous: !!data.revokeExisting,
        expires_at: expiresAt,
      },
    });
    return { id: row.id as string, token: row.token as string, expiresAt: row.expires_at as string };
  });

/* ================ Template preview ================ */

/** Renders a CSV preview from a config against a synthetic evidence row set,
 *  so the builder can render a live table without touching the DB. */
export const previewExportTemplate = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z
      .object({
        kind: z.enum(["csv", "pdf"]),
        config: z.object({ csv: csvTemplateSchema.optional(), pdf: pdfTemplateSchema.optional() }),
      })
      .parse(d),
  )
  .handler(async ({ data }) => {
    const sampleRows = Array.from({ length: 3 }).map((_, i) => ({
      recommendation_id: `00000000-0000-0000-0000-00000000000${i}`,
      recommendation_title: `Sample recommendation ${i + 1}`,
      priority: i === 0 ? "high" : i === 1 ? "medium" : "low",
      evidence_id: `ev-${i}`,
      evidence_kind: "post",
      post_id: `post-${i}`,
      platform: ["instagram", "tiktok", "x"][i],
      posted_at: new Date(Date.now() - i * 86_400_000).toISOString(),
      engagement_rate: 0.032 + i * 0.011,
      likes: 1200 + i * 320,
      comments: 48 + i * 9,
      shares: 12 + i * 4,
      views: 40_000 + i * 8200,
      caption: `Caption preview #${i + 1} — demo copy for template preview.`,
      media_url: null,
      url: `https://example.com/post/${i}`,
      snippet: `Evidence snippet #${i + 1}`,
    }));
    if (data.kind === "csv") {
      const csv = buildCsv(sampleRows, data.config.csv);
      return { kind: "csv" as const, csv, sampleRows, columns: data.config.csv?.columns ?? null };
    }
    // For PDF, we return the section plan so the builder can preview visually.
    const sections = data.config.pdf?.sections ?? {
      summary: true,
      metrics: true,
      thumbnails: true,
      evidenceTable: true,
      snippets: true,
    };
    return {
      kind: "pdf" as const,
      sections,
      orientation: data.config.pdf?.orientation ?? "portrait",
      sampleRows,
    };
  });

/* ================ Webhook test (dry-run delivery) ================ */

const testWebhookSchema = z.object({
  id: z.string().uuid(),
  event: z.enum(["export.complete", "export.failed"]).optional().default("export.complete"),
});

export const testExportWebhook = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => testWebhookSchema.parse(d))
  .handler(async ({ data, context }) => {
    const { data: hook } = await context.supabase
      .from("export_webhooks")
      .select("id, org_id, url, events, enabled")
      .eq("id", data.id)
      .maybeSingle();
    if (!hook) throw new Error("Webhook not found");
    const mem = await getMembership(context.supabase, hook.org_id, context.userId);
    if (!mem || (mem.role !== "owner" && mem.role !== "admin")) {
      throw new Error("Only admins can send test webhooks");
    }
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: full } = await supabaseAdmin
      .from("export_webhooks")
      .select(
        "id, org_id, url, secret, events, enabled, signing_version, require_timestamp, timestamp_tolerance_seconds, max_attempts",
      )
      .eq("id", data.id)
      .maybeSingle();
    if (!full) throw new Error("Webhook not found");

    const idempotencyKey = newDeliveryKey();
    const correlationId = `test-${newDeliveryKey()}`;
    const payload = {
      event: data.event,
      org_id: hook.org_id,
      delivered_at: new Date().toISOString(),
      test: true,
      idempotency_key: idempotencyKey,
      correlation_id: correlationId,
      data: {
        export_id: "00000000-0000-0000-0000-000000000000",
        kind: "pdf",
        filename: `test-${data.event}.pdf`,
        rows: 3,
        size_bytes: 1024,
        requested_by: context.userId,
      },
    };

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { data: delivery } = await (supabaseAdmin as any)
      .from("export_webhook_deliveries")
      .insert({
        webhook_id: full.id,
        org_id: full.org_id,
        export_id: null,
        event: data.event,
        payload,
        status: "pending",
        attempts: 0,
        idempotency_key: idempotencyKey,
        correlation_id: correlationId,
      })
      .select("id, attempts, payload, event, idempotency_key, correlation_id")
      .single();
    if (!delivery) throw new Error("Failed to enqueue test delivery");

    await logAudit(context.supabase, {
      org_id: hook.org_id,
      actor_user_id: context.userId,
      action: "export.webhook.test",
      target_type: "export_webhook",
      target_id: full.id,
      metadata: {
        event: data.event,
        delivery_id: delivery.id,
        idempotency_key: idempotencyKey,
        correlation_id: correlationId,
      },
    });

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const res = await attemptDelivery(supabaseAdmin, full as WebhookRow, {
      id: delivery.id as string,
      attempts: delivery.attempts as number,
      payload: (delivery.payload ?? {}) as Record<string, unknown>,
      event: delivery.event as string,
      idempotency_key: idempotencyKey,
      correlation_id: correlationId,
    });
    return {
      ok: res.ok,
      status: res.status,
      body: res.body,
      error: res.error ?? null,
      deliveryId: delivery.id,
      idempotencyKey,
      correlationId,
      payload,
    };
  });
