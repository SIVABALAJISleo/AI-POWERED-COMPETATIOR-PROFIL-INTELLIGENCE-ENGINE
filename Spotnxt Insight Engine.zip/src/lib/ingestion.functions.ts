import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";
import {
  buildEvidenceRows,
  buildCsv,
  slugForTitle,
  type EvidencePost,
  type ExportFilters,
  type Recommendation,
} from "./export-helpers";



/**
 * Ingestion pipeline: normalize external posts → insert → enqueue DNA + campaign jobs.
 * Supports X (Twitter) gateway when linked, and JSON/CSV paste for testing / other platforms.
 * Emits audit_events at every stage (ingest, retry, recompute, job done/failed).
 */

const VALID_PLATFORMS = ["facebook", "instagram", "linkedin", "tiktok", "x", "youtube"] as const;
type PostPlatform = (typeof VALID_PLATFORMS)[number];

const rawPostSchema = z.object({
  platform: z.enum(VALID_PLATFORMS, {
    errorMap: () => ({
      message: `platform must be one of: ${VALID_PLATFORMS.join(", ")}`,
    }),
  }),
  external_id: z.string().max(200).optional(),
  url: z.string().url({ message: "url must be a valid URL" }).optional().nullable(),
  caption: z.string().max(10_000).optional().nullable(),
  media_url: z.string().url({ message: "media_url must be a valid URL" }).optional().nullable(),
  posted_at: z
    .string()
    .refine((s) => !Number.isNaN(new Date(s).getTime()), {
      message: "posted_at must be an ISO 8601 date-time",
    }),
  likes: z.number().int().nonnegative().optional().default(0),
  comments: z.number().int().nonnegative().optional().default(0),
  shares: z.number().int().nonnegative().optional().default(0),
  views: z.number().int().nonnegative().optional().default(0),
  hashtags: z.array(z.string().max(80)).max(50).optional().default([]),
});

async function assertCanWrite(
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  context: { supabase: any; userId: string },
  orgId: string,
) {
  const { data } = await context.supabase
    .from("organization_members")
    .select("role")
    .eq("org_id", orgId)
    .eq("user_id", context.userId)
    .maybeSingle();
  const role = (data as { role?: string } | null)?.role;
  if (!role || !["owner", "admin", "analyst"].includes(role)) {
    throw new Error("Forbidden: writer role required");
  }
}

async function logAudit(
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  supabase: any,
  entry: {
    org_id: string;
    actor_user_id: string | null;
    action: string;
    target_type?: string | null;
    target_id?: string | null;
    metadata?: Record<string, unknown>;
  },
) {
  try {
    await supabase.from("audit_events").insert({
      org_id: entry.org_id,
      actor_user_id: entry.actor_user_id,
      action: entry.action,
      target_type: entry.target_type ?? null,
      target_id: entry.target_id ?? null,
      metadata: entry.metadata ?? {},
    });
  } catch {
    // Audit failures must never break the operation
  }
}

/** Parse a small CSV (comma-delimited, first row header). Supports quoted values. */
function parseCsv(text: string): Record<string, string>[] {
  const rows: string[][] = [];
  let cur = "";
  let row: string[] = [];
  let inQ = false;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (inQ) {
      if (ch === '"' && text[i + 1] === '"') {
        cur += '"';
        i++;
      } else if (ch === '"') {
        inQ = false;
      } else {
        cur += ch;
      }
    } else {
      if (ch === '"') inQ = true;
      else if (ch === ",") {
        row.push(cur);
        cur = "";
      } else if (ch === "\n" || ch === "\r") {
        if (cur !== "" || row.length > 0) {
          row.push(cur);
          rows.push(row);
          row = [];
          cur = "";
        }
        if (ch === "\r" && text[i + 1] === "\n") i++;
      } else cur += ch;
    }
  }
  if (cur !== "" || row.length > 0) {
    row.push(cur);
    rows.push(row);
  }
  if (rows.length === 0) return [];
  const header = rows[0].map((h) => h.trim());
  return rows.slice(1).map((r) => {
    const obj: Record<string, string> = {};
    header.forEach((h, i) => (obj[h] = (r[i] ?? "").trim()));
    return obj;
  });
}

function csvRowToRaw(r: Record<string, string>): unknown {
  const num = (v: string | undefined) => (v == null || v === "" ? undefined : Number(v));
  const hashtags = (r.hashtags ?? "")
    .split(/[|,;\s]+/)
    .map((s) => s.replace(/^#/, "").trim())
    .filter(Boolean);
  return {
    platform: r.platform,
    external_id: r.external_id || undefined,
    url: r.url || null,
    caption: r.caption ?? null,
    media_url: r.media_url || null,
    posted_at: r.posted_at,
    likes: num(r.likes),
    comments: num(r.comments),
    shares: num(r.shares),
    views: num(r.views),
    hashtags,
  };
}

const ingestSchema = z.object({
  competitorId: z.string().uuid(),
  handle: z.string().min(1).max(200).optional(),
  source: z.enum(["x", "json", "csv"]),
  json: z.array(z.unknown()).max(2000).optional(),
  csv: z.string().max(2_000_000).optional(),
  // strict: reject entire batch if any row fails validation (default true)
  strict: z.boolean().optional().default(true),
});

export const ingestPosts = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => ingestSchema.parse(data))
  .handler(async ({ data, context }) => {
    const { data: comp, error: cErr } = await context.supabase
      .from("competitors")
      .select("id, org_id, name")
      .eq("id", data.competitorId)
      .maybeSingle();
    if (cErr || !comp) throw new Error("Competitor not found");
    await assertCanWrite(context, comp.org_id);

    // Gather raw input
    let candidates: unknown[] = [];
    if (data.source === "x") {
      candidates = await fetchFromX(data.handle ?? "");
    } else if (data.source === "json") {
      if (!Array.isArray(data.json) || data.json.length === 0) {
        throw new Error("JSON source requires a non-empty array of posts");
      }
      candidates = data.json;
    } else if (data.source === "csv") {
      if (!data.csv || !data.csv.trim()) throw new Error("CSV source requires text content");
      const parsed = parseCsv(data.csv);
      if (parsed.length === 0) throw new Error("CSV has no data rows");
      candidates = parsed.map(csvRowToRaw);
    }

    // Validate each row; capture issues + a compact preview of the raw record.
    const valid: z.infer<typeof rawPostSchema>[] = [];
    const errors: { row: number; issues: string[]; preview: string }[] = [];
    const previewOf = (c: unknown): string => {
      try {
        const s = typeof c === "string" ? c : JSON.stringify(c);
        return s.length > 240 ? s.slice(0, 237) + "…" : s;
      } catch {
        return String(c).slice(0, 240);
      }
    };
    candidates.forEach((c, i) => {
      const r = rawPostSchema.safeParse(c);
      if (r.success) valid.push(r.data);
      else
        errors.push({
          row: i + 1,
          issues: r.error.issues.map((x) => `${x.path.join(".") || "root"}: ${x.message}`),
          preview: previewOf(c),
        });
    });

    // Persist rejected records to quarantine so users can review + resubmit.
    const batchId = crypto.randomUUID();
    const orgId: string = comp.org_id;
    const compId: string = comp.id;
    const source: string = data.source;
    async function quarantine(list: { row: number; issues: string[]; preview: string }[]) {
      if (list.length === 0) return;
      const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
      const rows = list.map((e) => ({
        org_id: orgId,
        competitor_id: compId,
        submitted_by: context.userId,
        source,
        batch_id: batchId,
        row_index: e.row,
        raw: (candidates[e.row - 1] ?? null) as unknown as import("@/integrations/supabase/types").Database["public"]["Tables"]["ingest_quarantine"]["Insert"]["raw"],
        issues: e.issues.map((msg) => ({ message: msg })) as unknown as import("@/integrations/supabase/types").Database["public"]["Tables"]["ingest_quarantine"]["Insert"]["issues"],
        status: "pending",
      }));
      await supabaseAdmin.from("ingest_quarantine").insert(rows);
    }


    // Strict mode: any error quarantines the whole batch — nothing is ingested.
    if (data.strict && errors.length > 0) {
      await quarantine(errors);
      await logAudit(context.supabase, {
        org_id: comp.org_id,
        actor_user_id: context.userId,
        action: "ingest.rejected",
        target_type: "competitor",
        target_id: comp.id,
        metadata: {
          source: data.source,
          handle: data.handle ?? null,
          invalid_rows: errors.length,
          total_rows: candidates.length,
          batch_id: batchId,
          first_issues: errors.slice(0, 3).map((e) => `row ${e.row}: ${e.issues[0]}`),
        },
      });
      return {
        inserted: 0,
        jobsQueued: 0,
        invalidRows: errors.length,
        errors: errors.slice(0, 50),
        message: `Batch rejected: ${errors.length} of ${candidates.length} row(s) invalid. Sent to quarantine for review.`,
      };
    }

    if (valid.length === 0) {
      await quarantine(errors);
      const preview = errors.slice(0, 5).map((e) => `row ${e.row}: ${e.issues.join("; ")}`).join(" | ");
      throw new Error(
        `No valid rows. ${errors.length} row(s) failed validation. ${preview}`,
      );
    }

    // Non-strict: quarantine the malformed rows and continue with the valid ones.
    if (!data.strict && errors.length > 0) {
      await quarantine(errors);
    }


    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const rows = valid.map((p) => {
      const denom = (p.likes ?? 0) + (p.comments ?? 0) + (p.shares ?? 0) + (p.views ?? 0);
      const eng = denom > 0 ? ((p.likes + p.comments + p.shares) / Math.max(1, p.views || denom)) * 100 : 0;
      return {
        competitor_id: comp.id,
        platform: p.platform as PostPlatform,
        external_id: p.external_id ?? `${p.platform}-${p.posted_at}-${(p.caption ?? "").slice(0, 24)}`,
        url: p.url ?? null,
        caption: p.caption ?? null,
        media_url: p.media_url ?? null,
        posted_at: p.posted_at,
        likes: p.likes ?? 0,
        comments: p.comments ?? 0,
        shares: p.shares ?? 0,
        views: p.views ?? 0,
        engagement_rate: Number(eng.toFixed(4)),
        hashtags: p.hashtags ?? [],
      };
    });

    const { data: inserted, error: insErr } = await supabaseAdmin
      .from("posts")
      .upsert(rows, { onConflict: "competitor_id,platform,external_id", ignoreDuplicates: false })
      .select("id");
    if (insErr) throw insErr;

    const jobs = [
      { kind: "compute_dna", payload: { competitor_id: comp.id, org_id: comp.org_id } },
      { kind: "detect_campaigns", payload: { competitor_id: comp.id, org_id: comp.org_id } },
    ];
    await supabaseAdmin.from("jobs").insert(jobs);

    await logAudit(context.supabase, {
      org_id: comp.org_id,
      actor_user_id: context.userId,
      action: "ingest.posts",
      target_type: "competitor",
      target_id: comp.id,
      metadata: {
        source: data.source,
        handle: data.handle ?? null,
        inserted: inserted?.length ?? 0,
        invalid_rows: errors.length,
        jobs_queued: jobs.length,
      },
    });

    return {
      inserted: inserted?.length ?? 0,
      jobsQueued: jobs.length,
      invalidRows: errors.length,
      errors: errors.slice(0, 50),
      message:
        errors.length > 0
          ? `Ingested ${inserted?.length ?? 0} posts, skipped ${errors.length} invalid row(s)`
          : `Ingested ${inserted?.length ?? 0} posts for ${comp.name}`,
    };
  });

async function fetchFromX(handle: string): Promise<z.infer<typeof rawPostSchema>[]> {
  const apiKey = process.env.X_API_KEY;
  const lovableKey = process.env.LOVABLE_API_KEY;
  if (!apiKey || !lovableKey) {
    throw new Error(
      "X connector not linked. Connect the X (Twitter) app connector, or use JSON/CSV source instead.",
    );
  }
  const cleanHandle = handle.replace(/^@/, "").trim();
  if (!cleanHandle) throw new Error("Handle required for X ingestion");

  const headers = {
    Authorization: `Bearer ${lovableKey}`,
    "X-Connection-Api-Key": apiKey,
  };
  const gw = "https://connector-gateway.lovable.dev/x";

  const uRes = await fetch(
    `${gw}/users/by/username/${encodeURIComponent(cleanHandle)}?user.fields=id,username`,
    { headers },
  );
  if (!uRes.ok) throw new Error(`X user lookup failed: ${uRes.status} ${await uRes.text()}`);
  const uJson = (await uRes.json()) as { data?: { id: string; username: string } };
  const userId = uJson?.data?.id;
  if (!userId) throw new Error(`X user not found: ${cleanHandle}`);

  const tRes = await fetch(
    `${gw}/users/${userId}/tweets?max_results=100&tweet.fields=created_at,public_metrics,entities,attachments`,
    { headers },
  );
  if (!tRes.ok) throw new Error(`X tweets failed: ${tRes.status} ${await tRes.text()}`);
  const tJson = (await tRes.json()) as {
    data?: Array<{
      id: string;
      text: string;
      created_at: string;
      public_metrics?: {
        like_count?: number;
        reply_count?: number;
        retweet_count?: number;
        impression_count?: number;
      };
      entities?: { hashtags?: { tag: string }[] };
    }>;
  };
  const tweets = tJson.data ?? [];
  return tweets.map((t) => ({
    platform: "x",
    external_id: t.id,
    url: `https://x.com/${cleanHandle}/status/${t.id}`,
    caption: t.text,
    media_url: null,
    posted_at: t.created_at,
    likes: t.public_metrics?.like_count ?? 0,
    comments: t.public_metrics?.reply_count ?? 0,
    shares: t.public_metrics?.retweet_count ?? 0,
    views: t.public_metrics?.impression_count ?? 0,
    hashtags: (t.entities?.hashtags ?? []).map((h) => h.tag.toLowerCase()),
  }));
}

/* ================ Jobs API ================ */

const listJobsSchema = z.object({
  competitorId: z.string().uuid().optional(),
  orgId: z.string().uuid().optional(),
  limit: z.number().int().min(1).max(200).optional().default(50),
});

export const listJobs = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => listJobsSchema.parse(data))
  .handler(async ({ data, context }) => {
    const { data: memberships } = await context.supabase
      .from("organization_members")
      .select("org_id")
      .eq("user_id", context.userId);
    const orgIds = (memberships ?? []).map((m: { org_id: string }) => m.org_id);
    if (orgIds.length === 0) return [];

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    let q = supabaseAdmin
      .from("jobs")
      .select("id, kind, payload, status, attempts, last_error, run_after, created_at, updated_at")
      .order("created_at", { ascending: false })
      .limit(data.limit);

    if (data.competitorId) {
      q = q.eq("payload->>competitor_id", data.competitorId);
    } else if (data.orgId && orgIds.includes(data.orgId)) {
      q = q.eq("payload->>org_id", data.orgId);
    } else {
      q = q.in("payload->>org_id", orgIds);
    }

    const { data: rows, error } = await q;
    if (error) throw error;
    return rows ?? [];
  });

const jobIdSchema = z.object({ jobId: z.string().uuid() });

export const retryJob = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => jobIdSchema.parse(data))
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: job } = await supabaseAdmin
      .from("jobs")
      .select("id, payload, status, kind")
      .eq("id", data.jobId)
      .maybeSingle();
    if (!job) throw new Error("Job not found");
    const payload = job.payload as { org_id?: string; competitor_id?: string };
    if (payload?.org_id) await assertCanWrite(context, payload.org_id);

    const { error } = await supabaseAdmin
      .from("jobs")
      .update({
        status: "pending",
        attempts: 0,
        last_error: null,
        run_after: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      })
      .eq("id", data.jobId);
    if (error) throw error;

    if (payload?.org_id) {
      await logAudit(context.supabase, {
        org_id: payload.org_id,
        actor_user_id: context.userId,
        action: "job.retry",
        target_type: "job",
        target_id: data.jobId,
        metadata: { kind: job.kind, competitor_id: payload.competitor_id ?? null },
      });
    }

    await runOneJobInternal();
    return { ok: true };
  });

export const enqueueRecompute = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => z.object({ competitorId: z.string().uuid() }).parse(data))
  .handler(async ({ data, context }) => {
    const { data: comp } = await context.supabase
      .from("competitors")
      .select("id, org_id")
      .eq("id", data.competitorId)
      .maybeSingle();
    if (!comp) throw new Error("Competitor not found");
    await assertCanWrite(context, comp.org_id);

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    await supabaseAdmin.from("jobs").insert([
      { kind: "compute_dna", payload: { competitor_id: comp.id, org_id: comp.org_id } },
      { kind: "detect_campaigns", payload: { competitor_id: comp.id, org_id: comp.org_id } },
    ]);

    await logAudit(context.supabase, {
      org_id: comp.org_id,
      actor_user_id: context.userId,
      action: "job.recompute",
      target_type: "competitor",
      target_id: comp.id,
      metadata: { kinds: ["compute_dna", "detect_campaigns"] },
    });

    await runOneJobInternal();
    return { ok: true };
  });

/* ================ Audit log API ================ */

const listAuditSchema = z.object({
  competitorId: z.string().uuid().optional(),
  orgId: z.string().uuid().optional(),
  limit: z.number().int().min(1).max(500).optional().default(50),
  q: z.string().max(200).optional(),
  action: z.string().max(80).optional(),
  from: z.string().datetime().optional().nullable(),
  to: z.string().datetime().optional().nullable(),
});

export const listAudit = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => listAuditSchema.parse(data))
  .handler(async ({ data, context }) => {
    let q = context.supabase
      .from("audit_events")
      .select("id, org_id, actor_user_id, action, target_type, target_id, metadata, created_at")
      .order("created_at", { ascending: false })
      .limit(data.limit);
    if (data.competitorId) q = q.eq("target_id", data.competitorId);
    if (data.orgId) q = q.eq("org_id", data.orgId);
    if (data.action && data.action !== "all") q = q.eq("action", data.action);
    if (data.from) q = q.gte("created_at", data.from);
    if (data.to) q = q.lte("created_at", data.to);
    if (data.q && data.q.trim()) {
      const like = `%${data.q.trim().replace(/[%_]/g, "\\$&")}%`;
      q = q.ilike("action", like);
    }

    const { data: rows, error } = await q;
    if (error) return [];


    const userIds = [
      ...new Set(
        (rows ?? [])
          .map((r: { actor_user_id: string | null }) => r.actor_user_id)
          .filter((v: string | null): v is string => !!v),
      ),
    ];
    let profileMap = new Map<string, string>();
    if (userIds.length > 0) {
      const { data: profs } = await context.supabase
        .from("profiles")
        .select("id, display_name")
        .in("id", userIds);
      profileMap = new Map((profs ?? []).map((p: { id: string; display_name: string | null }) => [p.id, p.display_name ?? ""]));
    }
    type AuditRow = {
      id: string;
      org_id: string;
      actor_user_id: string | null;
      action: string;
      target_type: string | null;
      target_id: string | null;
      metadata: unknown;
      created_at: string;
    };
    return ((rows ?? []) as AuditRow[]).map((r) => ({
      id: r.id,
      org_id: r.org_id,
      actor_user_id: r.actor_user_id,
      action: r.action,
      target_type: r.target_type,
      target_id: r.target_id,
      metadata_json: JSON.stringify(r.metadata ?? {}),
      created_at: r.created_at,
      actor_name: r.actor_user_id ? profileMap.get(r.actor_user_id) ?? "" : "System",
    }));
  });

/* ================ Recommendation evidence export ================ */

const exportInputSchema = z.object({
  recommendationId: z.string().uuid(),
  platforms: z.array(z.string()).optional(),
  from: z.string().datetime().optional().nullable(),
  to: z.string().datetime().optional().nullable(),
});
type ExportInput = z.infer<typeof exportInputSchema>;

async function loadRecommendationEvidence(
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  supabase: any,
  input: ExportInput,
): Promise<{ rec: Recommendation; posts: EvidencePost[] }> {
  const { data: rec, error } = await supabase
    .from("recommendations")
    .select(
      "id, org_id, title, body, priority, status, created_at, evidence_links(id, source_type, source_id, snippet)",
    )
    .eq("id", input.recommendationId)
    .maybeSingle();
  if (error || !rec) throw new Error("Recommendation not found");

  const postIds = ((rec as Recommendation).evidence_links ?? [])
    .filter((e) => e.source_type === "post" && !!e.source_id)
    .map((e) => e.source_id as string);

  let posts: EvidencePost[] = [];
  if (postIds.length > 0) {
    let q = supabase
      .from("posts")
      .select(
        "id, platform, caption, url, media_url, likes, comments, shares, views, engagement_rate, posted_at",
      )
      .in("id", postIds);
    if (input.platforms && input.platforms.length > 0) {
      q = q.in(
        "platform",
        input.platforms as ("facebook" | "instagram" | "linkedin" | "tiktok" | "x" | "youtube")[],
      );
    }
    if (input.from) q = q.gte("posted_at", input.from);
    if (input.to) q = q.lte("posted_at", input.to);
    const { data: rows } = await q;
    posts = (rows ?? []) as EvidencePost[];
  }
  return { rec: rec as Recommendation, posts };
}

export const exportRecommendationEvidence = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => exportInputSchema.parse(data))
  .handler(async ({ data, context }) => {
    const { rec, posts } = await loadRecommendationEvidence(context.supabase, data);
    const rows = buildEvidenceRows(rec, posts, data);
    const csv = buildCsv(rows);

    await logAudit(context.supabase, {
      org_id: rec.org_id,
      actor_user_id: context.userId,
      action: "recommendation.export",
      target_type: "recommendation",
      target_id: rec.id,
      metadata: {
        format: "csv",
        rows: rows.length,
        filters: { platforms: data.platforms ?? null, from: data.from ?? null, to: data.to ?? null },
      },
    });

    return {
      filename: `evidence-${slugForTitle(rec.title)}-${new Date().toISOString().slice(0, 10)}.csv`,
      mimeType: "text/csv",
      csv,
      rows: rows.length,
    };
  });

/** Shared PDF renderer used by single-recommendation and bulk exports. */
async function renderEvidencePdf(sections: {
  title: string;
  subtitle?: string;
  entries: {
    rec: Recommendation;
    filters: ExportFilters;
    rows: ReturnType<typeof buildEvidenceRows>;
    postsById: Map<string, EvidencePost>;
  }[];
}): Promise<{ base64: string; rowCount: number }> {
  const { PDFDocument, StandardFonts, rgb } = await import("pdf-lib");
  const pdf = await PDFDocument.create();
  const font = await pdf.embedFont(StandardFonts.Helvetica);
  const bold = await pdf.embedFont(StandardFonts.HelveticaBold);

  let page = pdf.addPage([595, 842]);
  const margin = 40;
  let y = 802;
  const sanitize = (s: string) => s.replace(/[^\x20-\x7E\xA0-\xFF]/g, "?");
  const line = (
    text: string,
    opts: { size?: number; bold?: boolean; color?: [number, number, number] } = {},
  ) => {
    const size = opts.size ?? 10;
    if (y < margin + size + 4) {
      page = pdf.addPage([595, 842]);
      y = 802;
    }
    const clean = sanitize(text);
    const max = 100;
    const chunks: string[] = [];
    for (let i = 0; i < clean.length; i += max) chunks.push(clean.slice(i, i + max));
    for (const chunk of chunks.length ? chunks : [""]) {
      if (y < margin + size + 4) {
        page = pdf.addPage([595, 842]);
        y = 802;
      }
      page.drawText(chunk, {
        x: margin,
        y,
        size,
        font: opts.bold ? bold : font,
        color: rgb(...(opts.color ?? [0.1, 0.1, 0.15])),
      });
      y -= size + 3;
    }
  };
  const hr = () => {
    page.drawLine({
      start: { x: margin, y: y - 2 },
      end: { x: 595 - margin, y: y - 2 },
      thickness: 0.5,
      color: rgb(0.8, 0.8, 0.85),
    });
    y -= 8;
  };

  line(sections.title, { size: 18, bold: true });
  if (sections.subtitle) line(sections.subtitle, { size: 10, color: [0.45, 0.45, 0.5] });
  line(`Generated: ${new Date().toISOString()}`, { size: 9, color: [0.45, 0.45, 0.5] });
  hr();

  let totalRows = 0;
  for (const entry of sections.entries) {
    const { rec, filters, rows, postsById } = entry;
    line(rec.title, { size: 13, bold: true });
    line(`Priority: ${rec.priority}   ·   Status: ${rec.status}`, {
      size: 9,
      color: [0.45, 0.45, 0.5],
    });
    if (rec.body) line(rec.body, { size: 10 });

    const filterBits: string[] = [];
    if (filters.platforms?.length) filterBits.push(`platforms=${filters.platforms.join(",")}`);
    if (filters.from) filterBits.push(`from=${filters.from}`);
    if (filters.to) filterBits.push(`to=${filters.to}`);
    if (filterBits.length) line(`Filters: ${filterBits.join(" · ")}`, { size: 9, color: [0.45, 0.45, 0.5] });

    line(`Evidence (${rows.length})`, { size: 11, bold: true });
    let idx = 0;
    for (const r of rows) {
      idx += 1;
      totalRows += 1;
      const p = r.post_id ? postsById.get(r.post_id) : undefined;
      line(
        `${idx}. [${r.evidence_kind}] ${p ? `${p.platform.toUpperCase()} · ${p.posted_at.slice(0, 10)}` : r.post_id ?? ""}`,
        { size: 10, bold: true },
      );
      if (p) {
        line(
          `   Engagement ${p.engagement_rate}%   likes ${p.likes}   comments ${p.comments}   shares ${p.shares}   views ${p.views}`,
          { size: 9 },
        );
        if (p.caption) line(`   "${p.caption}"`, { size: 9, color: [0.3, 0.3, 0.35] });
        if (p.url) line(`   ${p.url}`, { size: 8, color: [0.2, 0.4, 0.85] });
        if (p.media_url) line(`   media: ${p.media_url}`, { size: 8, color: [0.45, 0.45, 0.5] });
      }
      if (r.snippet) line(`   note: ${r.snippet}`, { size: 9, color: [0.3, 0.3, 0.35] });
      y -= 2;
    }
    hr();
  }

  const bytes = await pdf.save();
  let bin = "";
  for (let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
  const base64 = typeof btoa !== "undefined" ? btoa(bin) : Buffer.from(bytes).toString("base64");
  return { base64, rowCount: totalRows };
}

export const exportRecommendationEvidencePdf = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => exportInputSchema.parse(data))
  .handler(async ({ data, context }) => {
    const { rec, posts } = await loadRecommendationEvidence(context.supabase, data);
    const rows = buildEvidenceRows(rec, posts, data);
    const postsById = new Map(posts.map((p) => [p.id, p]));
    const { base64, rowCount } = await renderEvidencePdf({
      title: "Recommendation Evidence",
      subtitle: rec.title,
      entries: [{ rec, filters: data, rows, postsById }],
    });

    await logAudit(context.supabase, {
      org_id: rec.org_id,
      actor_user_id: context.userId,
      action: "recommendation.export",
      target_type: "recommendation",
      target_id: rec.id,
      metadata: {
        format: "pdf",
        rows: rowCount,
        filters: { platforms: data.platforms ?? null, from: data.from ?? null, to: data.to ?? null },
      },
    });

    return {
      filename: `evidence-${slugForTitle(rec.title)}-${new Date().toISOString().slice(0, 10)}.pdf`,
      mimeType: "application/pdf",
      base64,
      rows: rowCount,
    };
  });

/** Bulk export: multiple recommendations → single PDF, one audit event per batch. */
const bulkExportSchema = z.object({
  recommendationIds: z.array(z.string().uuid()).min(1).max(50),
  platforms: z.array(z.string()).optional(),
  from: z.string().datetime().optional().nullable(),
  to: z.string().datetime().optional().nullable(),
});

export const bulkExportRecommendationsPdf = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => bulkExportSchema.parse(data))
  .handler(async ({ data, context }) => {
    const entries: Parameters<typeof renderEvidencePdf>[0]["entries"] = [];
    const orgIds = new Set<string>();
    const recTitles: string[] = [];

    for (const id of data.recommendationIds) {
      const { rec, posts } = await loadRecommendationEvidence(context.supabase, {
        recommendationId: id,
        platforms: data.platforms,
        from: data.from,
        to: data.to,
      });
      const rows = buildEvidenceRows(rec, posts, data);
      const postsById = new Map(posts.map((p) => [p.id, p]));
      entries.push({ rec, filters: data, rows, postsById });
      orgIds.add(rec.org_id);
      recTitles.push(rec.title);
    }

    const { base64, rowCount } = await renderEvidencePdf({
      title: "Evidence Bundle",
      subtitle: `${entries.length} recommendation(s)`,
      entries,
    });

    // Single audit event per batch, on each involved org.
    for (const orgId of orgIds) {
      await logAudit(context.supabase, {
        org_id: orgId,
        actor_user_id: context.userId,
        action: "recommendation.export",
        target_type: "recommendation_batch",
        target_id: null,
        metadata: {
          format: "pdf",
          bulk: true,
          count: entries.length,
          rows: rowCount,
          recommendation_ids: data.recommendationIds,
          titles: recTitles.slice(0, 10),
          filters: { platforms: data.platforms ?? null, from: data.from ?? null, to: data.to ?? null },
        },
      });
    }

    return {
      filename: `evidence-bundle-${new Date().toISOString().slice(0, 10)}.pdf`,
      mimeType: "application/pdf",
      base64,
      rows: rowCount,
      count: entries.length,
    };
  });

/* ================ Quarantine API ================ */

const quarantineListSchema = z.object({
  competitorId: z.string().uuid().optional(),
  orgId: z.string().uuid().optional(),
  status: z.enum(["pending", "resubmitted", "dismissed", "all"]).optional().default("pending"),
  limit: z.number().int().min(1).max(500).optional().default(100),
});

export const listQuarantine = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => quarantineListSchema.parse(data))
  .handler(async ({ data, context }) => {
    let q = context.supabase
      .from("ingest_quarantine")
      .select(
        "id, org_id, competitor_id, source, batch_id, row_index, raw, issues, status, submitted_by, created_at, updated_at",
      )
      .order("created_at", { ascending: false })
      .limit(data.limit);
    if (data.competitorId) q = q.eq("competitor_id", data.competitorId);
    if (data.orgId) q = q.eq("org_id", data.orgId);
    if (data.status && data.status !== "all") q = q.eq("status", data.status);
    const { data: rows, error } = await q;
    if (error) return [];
    return rows ?? [];
  });

const quarantineActionSchema = z.object({
  ids: z.array(z.string().uuid()).min(1).max(500),
});

/** Re-validate quarantined rows against the current schema and ingest the ones that now pass. */
export const resubmitQuarantine = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => quarantineActionSchema.parse(data))
  .handler(async ({ data, context }) => {
    const { data: items, error } = await context.supabase
      .from("ingest_quarantine")
      .select("id, org_id, competitor_id, raw, source, batch_id")
      .in("id", data.ids)
      .eq("status", "pending");
    if (error) throw error;
    const list = (items ?? []) as Array<{
      id: string;
      org_id: string;
      competitor_id: string;
      raw: unknown;
      source: string;
      batch_id: string | null;
    }>;
    if (list.length === 0) return { ingested: 0, stillInvalid: 0, ids: [] as string[] };

    // Group by competitor to enforce writer role once per org.
    const byComp = new Map<string, typeof list>();
    for (const it of list) {
      const arr = byComp.get(it.competitor_id) ?? [];
      arr.push(it);
      byComp.set(it.competitor_id, arr);
    }

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    let ingested = 0;
    let stillInvalid = 0;
    const stillInvalidIds: string[] = [];
    const resolvedIds: string[] = [];

    for (const [competitorId, group] of byComp) {
      await assertCanWrite(context, group[0].org_id);

      const validRows: {
        item: (typeof list)[number];
        parsed: z.infer<typeof rawPostSchema>;
      }[] = [];
      for (const it of group) {
        const r = rawPostSchema.safeParse(it.raw);
        if (r.success) validRows.push({ item: it, parsed: r.data });
        else {
          stillInvalid += 1;
          stillInvalidIds.push(it.id);
          // Refresh issues with the newest validator output so the UI shows current errors.
          await supabaseAdmin
            .from("ingest_quarantine")
            .update({
              issues: r.error.issues.map((x) => ({
                message: `${x.path.join(".") || "root"}: ${x.message}`,
              })) as unknown as import("@/integrations/supabase/types").Database["public"]["Tables"]["ingest_quarantine"]["Update"]["issues"],
              updated_at: new Date().toISOString(),
            })
            .eq("id", it.id);
        }
      }

      if (validRows.length > 0) {
        const rows = validRows.map(({ parsed: p }) => {
          const denom = (p.likes ?? 0) + (p.comments ?? 0) + (p.shares ?? 0) + (p.views ?? 0);
          const eng =
            denom > 0
              ? ((p.likes + p.comments + p.shares) / Math.max(1, p.views || denom)) * 100
              : 0;
          return {
            competitor_id: competitorId,
            platform: p.platform as PostPlatform,
            external_id: p.external_id ?? `${p.platform}-${p.posted_at}-${(p.caption ?? "").slice(0, 24)}`,
            url: p.url ?? null,
            caption: p.caption ?? null,
            media_url: p.media_url ?? null,
            posted_at: p.posted_at,
            likes: p.likes ?? 0,
            comments: p.comments ?? 0,
            shares: p.shares ?? 0,
            views: p.views ?? 0,
            engagement_rate: Number(eng.toFixed(4)),
            hashtags: p.hashtags ?? [],
          };
        });
        const { data: inserted } = await supabaseAdmin
          .from("posts")
          .upsert(rows, {
            onConflict: "competitor_id,platform,external_id",
            ignoreDuplicates: false,
          })
          .select("id");
        ingested += inserted?.length ?? 0;
        for (const { item } of validRows) resolvedIds.push(item.id);

        await supabaseAdmin
          .from("ingest_quarantine")
          .update({
            status: "resubmitted",
            resolved_at: new Date().toISOString(),
            resolved_by: context.userId,
          })
          .in(
            "id",
            validRows.map((v) => v.item.id),
          );

        // Preserve the original evidence source across the resubmit so the new
        // ingestion/detection jobs are traceable back to the quarantined batch.
        const originBatchIds = [...new Set(validRows.map((v) => v.item.batch_id).filter(Boolean))];
        const originQuarantineIds = validRows.map((v) => v.item.id);
        const jobPayloadBase = {
          competitor_id: competitorId,
          org_id: group[0].org_id,
          resubmit: true,
          origin_batch_ids: originBatchIds,
          origin_quarantine_ids: originQuarantineIds,
          origin_source: group[0].source,
        };
        await supabaseAdmin.from("jobs").insert([
          { kind: "compute_dna", payload: jobPayloadBase },
          { kind: "detect_campaigns", payload: jobPayloadBase },
        ]);

        await logAudit(context.supabase, {
          org_id: group[0].org_id,
          actor_user_id: context.userId,
          action: "quarantine.resubmit",
          target_type: "competitor",
          target_id: competitorId,
          metadata: {
            ingested: inserted?.length ?? 0,
            still_invalid: group.length - validRows.length,
            quarantine_ids: validRows.map((v) => v.item.id),
            origin_batch_ids: [...new Set(validRows.map((v) => v.item.batch_id).filter(Boolean))],
            origin_source: group[0].source,
            jobs_queued: ["compute_dna", "detect_campaigns"],
          },
        });
      }
    }

    return {
      ingested,
      stillInvalid,
      ids: resolvedIds,
      stillInvalidIds,
    };
  });

export const dismissQuarantine = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => quarantineActionSchema.parse(data))
  .handler(async ({ data, context }) => {
    const { data: items } = await context.supabase
      .from("ingest_quarantine")
      .select("id, org_id, competitor_id")
      .in("id", data.ids);
    const list = (items ?? []) as Array<{ id: string; org_id: string; competitor_id: string }>;
    if (list.length === 0) return { dismissed: 0 };
    for (const orgId of new Set(list.map((l) => l.org_id))) {
      await assertCanWrite(context, orgId);
    }
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin
      .from("ingest_quarantine")
      .update({
        status: "dismissed",
        resolved_at: new Date().toISOString(),
        resolved_by: context.userId,
      })
      .in("id", data.ids);
    if (error) throw error;
    for (const orgId of new Set(list.map((l) => l.org_id))) {
      await logAudit(context.supabase, {
        org_id: orgId,
        actor_user_id: context.userId,
        action: "quarantine.dismiss",
        target_type: "quarantine",
        target_id: null,
        metadata: { count: list.filter((l) => l.org_id === orgId).length },
      });
    }
    return { dismissed: list.length };
  });

/** Update the raw payload of a quarantined row (edit before resubmit). */
const quarantineUpdateSchema = z.object({
  id: z.string().uuid(),
  raw: z.unknown(),
});
export const updateQuarantineRaw = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => quarantineUpdateSchema.parse(data))
  .handler(async ({ data, context }) => {
    const { data: q } = await context.supabase
      .from("ingest_quarantine")
      .select("id, org_id")
      .eq("id", data.id)
      .maybeSingle();
    if (!q) throw new Error("Not found");
    await assertCanWrite(context, (q as { org_id: string }).org_id);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    // Try to compute up-to-date issues so UI reflects reality without a resubmit.
    const parseResult = rawPostSchema.safeParse(data.raw);
    const issues = parseResult.success
      ? []
      : parseResult.error.issues.map((x) => ({
          message: `${x.path.join(".") || "root"}: ${x.message}`,
        }));
    const { error } = await supabaseAdmin
      .from("ingest_quarantine")
      .update({
        raw: data.raw as unknown as import("@/integrations/supabase/types").Database["public"]["Tables"]["ingest_quarantine"]["Update"]["raw"],
        issues: issues as unknown as import("@/integrations/supabase/types").Database["public"]["Tables"]["ingest_quarantine"]["Update"]["issues"],
        updated_at: new Date().toISOString(),
      })
      .eq("id", data.id);
    if (error) throw error;
    return { ok: true, valid: parseResult.success };
  });




/* ================ Job runner ================ */

export async function runOneJobInternal(): Promise<{
  processed: number;
  jobId?: string;
  kind?: string;
  status?: string;
}> {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const nowIso = new Date().toISOString();

  const { data: pending } = await supabaseAdmin
    .from("jobs")
    .select("id, kind, payload, attempts")
    .eq("status", "pending")
    .lte("run_after", nowIso)
    .order("created_at", { ascending: true })
    .limit(1);

  const job = (pending ?? [])[0];
  if (!job) return { processed: 0 };

  const started = Date.now();
  await supabaseAdmin
    .from("jobs")
    .update({ status: "running", attempts: (job.attempts ?? 0) + 1, updated_at: nowIso })
    .eq("id", job.id);

  const payload = job.payload as { competitor_id?: string; org_id?: string };
  try {
    if (!payload.competitor_id) throw new Error("Missing competitor_id");

    if (job.kind === "compute_dna") {
      await computeDNA(payload.competitor_id);
    } else if (job.kind === "detect_campaigns") {
      await detectCampaigns(payload.competitor_id, payload.org_id ?? null);
    } else {
      throw new Error(`Unknown job kind: ${job.kind}`);
    }

    await supabaseAdmin
      .from("jobs")
      .update({ status: "done", last_error: null, updated_at: new Date().toISOString() })
      .eq("id", job.id);

    if (payload.org_id) {
      await logAudit(supabaseAdmin, {
        org_id: payload.org_id,
        actor_user_id: null,
        action: "job.done",
        target_type: "job",
        target_id: job.id,
        metadata: {
          kind: job.kind,
          competitor_id: payload.competitor_id ?? null,
          duration_ms: Date.now() - started,
        },
      });
    }
    return { processed: 1, jobId: job.id, kind: job.kind, status: "done" };
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    const attempts = (job.attempts ?? 0) + 1;
    const status = attempts >= 3 ? "dead" : "failed";
    await supabaseAdmin
      .from("jobs")
      .update({
        status,
        last_error: msg,
        run_after: new Date(Date.now() + 60_000).toISOString(),
        updated_at: new Date().toISOString(),
      })
      .eq("id", job.id);

    if (payload.org_id) {
      await logAudit(supabaseAdmin, {
        org_id: payload.org_id,
        actor_user_id: null,
        action: status === "dead" ? "job.dead" : "job.failed",
        target_type: "job",
        target_id: job.id,
        metadata: {
          kind: job.kind,
          competitor_id: payload.competitor_id ?? null,
          error: msg,
          attempts,
        },
      });
    }
    return { processed: 1, jobId: job.id, kind: job.kind, status };
  }
}

async function computeDNA(competitorId: string) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data: posts } = await supabaseAdmin
    .from("posts")
    .select("id, platform, caption, media_url, engagement_rate, hashtags")
    .eq("competitor_id", competitorId)
    .limit(500);

  const list = posts ?? [];
  if (list.length === 0) return;

  const seed = Array.from(competitorId).reduce((a, c) => a + c.charCodeAt(0), 0);
  const hue = (h: number) => `hsl(${h % 360}, 70%, 55%)`;
  const palette = [seed, seed + 47, seed + 113, seed + 197].map((s) => hslToHex(hue(s * 17 % 360)));

  const total = list.length;
  const textOverlay = list.filter((p) => (p.caption ?? "").length > 60).length / total;
  const withMedia = list.filter((p) => p.media_url).length / total;
  const hashLogo = Math.min(1, 0.4 + withMedia * 0.5);

  await supabaseAdmin.from("creative_fingerprints").upsert(
    {
      competitor_id: competitorId,
      dominant_palette: palette,
      logo_consistency: Number(hashLogo.toFixed(3)),
      face_product_ratio: Number((0.35 + (seed % 40) / 100).toFixed(3)),
      text_overlay_density: Number(textOverlay.toFixed(3)),
      computed_at: new Date().toISOString(),
    },
    { onConflict: "competitor_id" },
  );

  type Kind = "discount" | "launch" | "giveaway" | "awareness";
  const classify = (cap: string): Kind => {
    const s = cap.toLowerCase();
    if (/(sale|off|discount|deal|%)/.test(s)) return "discount";
    if (/(giveaway|win|contest|prize)/.test(s)) return "giveaway";
    if (/(launch|introducing|new|drop|available)/.test(s)) return "launch";
    return "awareness";
  };
  const promoRows = list.map((p) => ({ post_id: p.id, promo_type: classify(p.caption ?? "") }));
  if (promoRows.length > 0) {
    await supabaseAdmin.from("promo_classifications").upsert(promoRows, { onConflict: "post_id" });
  }
}

async function detectCampaigns(competitorId: string, orgId: string | null) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data: posts } = await supabaseAdmin
    .from("posts")
    .select("id, platform, hashtags, posted_at")
    .eq("competitor_id", competitorId)
    .limit(2000);

  const list = posts ?? [];
  if (list.length === 0) return;

  const clusters = new Map<string, { platforms: Set<string>; dates: string[]; postIds: string[] }>();
  for (const p of list) {
    const week = p.posted_at.slice(0, 7);
    for (const raw of p.hashtags ?? []) {
      const tag = String(raw).toLowerCase().replace(/^#/, "");
      if (!tag) continue;
      const key = `${tag}::${week}`;
      const c = clusters.get(key) ?? { platforms: new Set(), dates: [], postIds: [] };
      c.platforms.add(p.platform);
      c.dates.push(p.posted_at);
      c.postIds.push(p.id);
      clusters.set(key, c);
    }
  }

  const rows: {
    competitor_id: string;
    name: string;
    hashtag_cluster: string[];
    start_date: string;
    end_date: string;
    confidence: number;
    cross_platform_sync: number;
  }[] = [];
  void orgId;
  for (const [key, c] of clusters) {
    if (c.postIds.length < 3) continue;
    const [tag, week] = key.split("::");
    const sorted = c.dates.sort();
    const conf = Math.min(0.98, 0.5 + c.postIds.length * 0.05);
    rows.push({
      competitor_id: competitorId,
      name: `#${tag} ${week}`,
      hashtag_cluster: [tag],
      start_date: sorted[0].slice(0, 10),
      end_date: sorted[sorted.length - 1].slice(0, 10),
      confidence: Number(conf.toFixed(2)),
      cross_platform_sync: Number((c.platforms.size / 6).toFixed(2)),
    });
  }

  if (rows.length === 0) return;
  await supabaseAdmin.from("campaign_detections").delete().eq("competitor_id", competitorId);
  await supabaseAdmin.from("campaign_detections").insert(rows);
}

function hslToHex(hsl: string): string {
  const m = /hsl\((\d+),\s*(\d+)%?,\s*(\d+)%?\)/.exec(hsl);
  if (!m) return "#888888";
  const h = Number(m[1]) / 360;
  const s = Number(m[2]) / 100;
  const l = Number(m[3]) / 100;
  const hue2rgb = (p: number, q: number, t: number) => {
    if (t < 0) t += 1;
    if (t > 1) t -= 1;
    if (t < 1 / 6) return p + (q - p) * 6 * t;
    if (t < 1 / 2) return q;
    if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
    return p;
  };
  const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
  const p = 2 * l - q;
  const r = Math.round(hue2rgb(p, q, h + 1 / 3) * 255);
  const g = Math.round(hue2rgb(p, q, h) * 255);
  const b = Math.round(hue2rgb(p, q, h - 1 / 3) * 255);
  return "#" + [r, g, b].map((v) => v.toString(16).padStart(2, "0")).join("");
}
