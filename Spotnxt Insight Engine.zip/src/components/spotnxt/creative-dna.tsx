import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { PLATFORM_LABEL } from "@/lib/platforms";
import { RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar as ReRadar, ResponsiveContainer, Tooltip as ReTooltip } from "recharts";

type Fingerprint = {
  dominant_palette: unknown;
  logo_consistency: number | string | null;
  face_product_ratio: number | string | null;
  text_overlay_density: number | string | null;
  computed_at: string | null;
};

type GalleryItem = {
  id: string;
  platform: string;
  media_url: string | null;
  caption: string | null;
  engagement_rate: number | string | null;
  posted_at: string;
};

type PromoMix = { type: string; count: number; pct: number };

const PROMO_COLORS: Record<string, string> = {
  discount: "bg-rose-500",
  launch: "bg-blue-500",
  giveaway: "bg-amber-500",
  awareness: "bg-emerald-500",
  none: "bg-muted-foreground/40",
};

export function CreativeDNA({
  fingerprint,
  gallery,
  promoMix,
}: {
  fingerprint: Fingerprint | null;
  gallery: GalleryItem[];
  promoMix: PromoMix[];
}) {
  const palette = Array.isArray(fingerprint?.dominant_palette)
    ? (fingerprint!.dominant_palette as string[])
    : [];

  const logo = Number(fingerprint?.logo_consistency ?? 0);
  const face = Number(fingerprint?.face_product_ratio ?? 0);
  const text = Number(fingerprint?.text_overlay_density ?? 0);
  const promoDiversity = Math.min(1, promoMix.filter((p) => p.type !== "none").length / 4);
  const gallerySpread =
    gallery.length > 0
      ? Math.min(1, new Set(gallery.map((g) => g.platform)).size / 6)
      : 0;

  const radarData = [
    { axis: "Logo consistency", value: Math.round(logo * 100) },
    { axis: "Face / product mix", value: Math.round(face * 100) },
    { axis: "Text overlay", value: Math.round(text * 100) },
    { axis: "Promo diversity", value: Math.round(promoDiversity * 100) },
    { axis: "Platform spread", value: Math.round(gallerySpread * 100) },
  ];

  return (
    <div className="space-y-4">
      <div className="grid gap-4 lg:grid-cols-[1fr_1.2fr]">
        <Card>
          <CardHeader>
            <CardTitle>Dominant palette</CardTitle>
            <CardDescription>Aggregated across every tracked post.</CardDescription>
          </CardHeader>
          <CardContent>
            {palette.length > 0 ? (
              <div className="space-y-4">
                <div className="grid grid-cols-4 gap-3">
                  {palette.map((hex) => (
                    <div key={hex} className="space-y-1">
                      <div
                        className="h-16 w-full rounded-md ring-1 ring-border"
                        style={{ backgroundColor: hex }}
                      />
                      <div className="text-center font-mono text-[10px] uppercase text-muted-foreground">
                        {hex}
                      </div>
                    </div>
                  ))}
                </div>
                <StatRow label="Logo consistency" pct={logo} />
                <StatRow label="Face / product framing ratio" pct={face} />
                <StatRow label="Text-overlay density" pct={text} />
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">No fingerprint yet.</p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Style signature</CardTitle>
            <CardDescription>Radar profile of this competitor&apos;s creative DNA.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <RadarChart data={radarData} outerRadius="72%">
                  <PolarGrid stroke="var(--border)" />
                  <PolarAngleAxis dataKey="axis" tick={{ fontSize: 11, fill: "var(--muted-foreground)" }} />
                  <PolarRadiusAxis angle={90} domain={[0, 100]} tick={false} axisLine={false} />
                  <ReRadar
                    dataKey="value"
                    stroke="var(--primary)"
                    fill="var(--primary)"
                    fillOpacity={0.25}
                  />
                  <ReTooltip
                    contentStyle={{
                      backgroundColor: "var(--popover)",
                      borderColor: "var(--border)",
                      color: "var(--popover-foreground)",
                      fontSize: "12px",
                    }}
                    formatter={(v: number) => [`${v}%`, "score"]}
                  />
                </RadarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Promo-type mix</CardTitle>
          <CardDescription>Share of posts by detected promotional intent.</CardDescription>
        </CardHeader>
        <CardContent>
          {promoMix.length === 0 ? (
            <p className="text-sm text-muted-foreground">No promo classifications yet.</p>
          ) : (
            <div className="space-y-3">
              <div className="flex h-3 w-full overflow-hidden rounded-full">
                {promoMix
                  .sort((a, b) => b.pct - a.pct)
                  .map((p) => (
                    <div
                      key={p.type}
                      className={PROMO_COLORS[p.type] ?? "bg-muted"}
                      style={{ width: `${p.pct * 100}%` }}
                      title={`${p.type}: ${(p.pct * 100).toFixed(0)}%`}
                    />
                  ))}
              </div>
              <div className="flex flex-wrap gap-3 text-xs">
                {promoMix.map((p) => (
                  <span key={p.type} className="inline-flex items-center gap-1.5">
                    <span className={`size-2.5 rounded-full ${PROMO_COLORS[p.type] ?? "bg-muted"}`} />
                    <span className="capitalize">{p.type}</span>
                    <span className="tabular-nums text-muted-foreground">{(p.pct * 100).toFixed(0)}%</span>
                  </span>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Visual gallery</CardTitle>
          <CardDescription>Highest-engagement creative from every platform.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
            {gallery.map((g) => (
              <div key={g.id} className="group overflow-hidden rounded-md border">
                {g.media_url && (
                  <img
                    src={g.media_url}
                    alt=""
                    className="h-32 w-full object-cover transition-transform group-hover:scale-105"
                    loading="lazy"
                  />
                )}
                <div className="flex items-center justify-between p-2 text-[10px]">
                  <Badge variant="outline" className="text-[9px]">
                    {PLATFORM_LABEL[g.platform] ?? g.platform}
                  </Badge>
                  <span className="font-semibold text-primary">
                    {Number(g.engagement_rate ?? 0).toFixed(1)}%
                  </span>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function StatRow({ label, pct }: { label: string; pct: number }) {
  const value = Math.max(0, Math.min(1, pct));
  return (
    <div className="space-y-1">
      <div className="flex items-center justify-between text-xs">
        <span className="text-muted-foreground">{label}</span>
        <span className="font-semibold tabular-nums">{Math.round(value * 100)}%</span>
      </div>
      <div className="h-1.5 w-full overflow-hidden rounded-full bg-muted">
        <div
          className="h-full bg-primary"
          style={{ width: `${value * 100}%` }}
        />
      </div>
    </div>
  );
}
