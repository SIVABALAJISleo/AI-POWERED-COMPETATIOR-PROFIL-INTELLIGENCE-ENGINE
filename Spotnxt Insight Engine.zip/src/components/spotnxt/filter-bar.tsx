import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { PLATFORM_LABEL } from "@/lib/platforms";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { CalendarIcon, X } from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";

export type FilterState = {
  platforms: string[];
  from: Date | null;
  to: Date | null;
};

const PRESETS: { label: string; days: number | null }[] = [
  { label: "All time", days: null },
  { label: "Last 30d", days: 30 },
  { label: "Last 90d", days: 90 },
  { label: "Last 12mo", days: 365 },
];

export function FilterBar({
  availablePlatforms,
  value,
  onChange,
}: {
  availablePlatforms: string[];
  value: FilterState;
  onChange: (v: FilterState) => void;
}) {
  const togglePlatform = (p: string) => {
    const set = new Set(value.platforms);
    if (set.has(p)) set.delete(p);
    else set.add(p);
    onChange({ ...value, platforms: [...set] });
  };

  const preset = (days: number | null) => {
    if (days === null) return onChange({ ...value, from: null, to: null });
    const to = new Date();
    const from = new Date();
    from.setDate(to.getDate() - days);
    onChange({ ...value, from, to });
  };

  const cleared = value.platforms.length === 0 && !value.from && !value.to;

  return (
    <div className="flex flex-wrap items-center gap-2 rounded-lg border bg-card p-2">
      <span className="pl-1 text-xs font-medium text-muted-foreground">Filters:</span>

      <div className="flex flex-wrap gap-1">
        {availablePlatforms.map((p) => {
          const active = value.platforms.includes(p);
          return (
            <button
              key={p}
              type="button"
              onClick={() => togglePlatform(p)}
              className={cn(
                "rounded-md border px-2 py-0.5 text-xs transition-colors",
                active
                  ? "border-primary bg-primary/10 text-primary"
                  : "border-border text-muted-foreground hover:bg-accent",
              )}
            >
              {PLATFORM_LABEL[p] ?? p}
            </button>
          );
        })}
      </div>

      <div className="h-5 w-px bg-border" />

      <div className="flex gap-1">
        {PRESETS.map((p) => (
          <button
            key={p.label}
            type="button"
            onClick={() => preset(p.days)}
            className="rounded-md px-2 py-0.5 text-xs text-muted-foreground hover:bg-accent"
          >
            {p.label}
          </button>
        ))}
      </div>

      <Popover>
        <PopoverTrigger asChild>
          <Button variant="outline" size="sm" className="h-7 gap-1 text-xs">
            <CalendarIcon className="size-3" />
            {value.from ? format(value.from, "MMM d") : "From"}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-0" align="start">
          <Calendar
            mode="single"
            selected={value.from ?? undefined}
            onSelect={(d) => onChange({ ...value, from: d ?? null })}
            className={cn("p-3 pointer-events-auto")}
          />
        </PopoverContent>
      </Popover>
      <span className="text-xs text-muted-foreground">→</span>
      <Popover>
        <PopoverTrigger asChild>
          <Button variant="outline" size="sm" className="h-7 gap-1 text-xs">
            <CalendarIcon className="size-3" />
            {value.to ? format(value.to, "MMM d") : "To"}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-0" align="start">
          <Calendar
            mode="single"
            selected={value.to ?? undefined}
            onSelect={(d) => onChange({ ...value, to: d ?? null })}
            className={cn("p-3 pointer-events-auto")}
          />
        </PopoverContent>
      </Popover>

      {!cleared && (
        <Button
          variant="ghost"
          size="sm"
          className="ml-auto h-7 gap-1 text-xs"
          onClick={() => onChange({ platforms: [], from: null, to: null })}
        >
          <X className="size-3" /> Clear
        </Button>
      )}

      <div className="w-full basis-full pl-1 pt-1 text-[10px] text-muted-foreground">
        {value.platforms.length > 0 && (
          <Badge variant="secondary" className="mr-2 text-[10px]">
            {value.platforms.length} platform{value.platforms.length > 1 ? "s" : ""}
          </Badge>
        )}
        {value.from && value.to && (
          <span>
            {format(value.from, "MMM d, yyyy")} – {format(value.to, "MMM d, yyyy")}
          </span>
        )}
      </div>
    </div>
  );
}
