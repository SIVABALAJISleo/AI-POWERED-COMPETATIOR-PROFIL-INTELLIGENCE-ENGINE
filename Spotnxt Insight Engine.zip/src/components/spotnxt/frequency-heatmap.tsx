import { cn } from "@/lib/utils";

const DAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

export function FrequencyHeatmap({ data }: { data: number[][] }) {
  const max = Math.max(1, ...data.flat());
  return (
    <div className="w-full overflow-x-auto">
      <div className="min-w-[640px]">
        <div className="grid grid-cols-[auto_repeat(24,minmax(0,1fr))] gap-1 text-xs text-muted-foreground">
          <div />
          {Array.from({ length: 24 }, (_, h) => (
            <div key={h} className="text-center tabular-nums">
              {h % 3 === 0 ? h : ""}
            </div>
          ))}
          {DAYS.map((day, di) => (
            <>
              <div key={`d-${di}`} className="pr-2 text-right leading-6">
                {day}
              </div>
              {Array.from({ length: 24 }, (_, h) => {
                const v = data[di]?.[h] ?? 0;
                const intensity = v / max;
                return (
                  <div
                    key={`c-${di}-${h}`}
                    className={cn(
                      "h-6 rounded-sm border border-border/50",
                      v === 0 ? "bg-muted/50" : "",
                    )}
                    style={
                      v > 0
                        ? { backgroundColor: `oklch(from var(--primary) l c h / ${0.15 + intensity * 0.75})` }
                        : undefined
                    }
                    title={`${DAYS[di]} ${h}:00 — ${v} post${v === 1 ? "" : "s"}`}
                  />
                );
              })}
            </>
          ))}
        </div>
        <div className="mt-3 flex items-center justify-end gap-2 text-xs text-muted-foreground">
          <span>Less</span>
          {[0.1, 0.3, 0.5, 0.75, 1].map((v) => (
            <div
              key={v}
              className="h-3 w-4 rounded-sm border border-border/50"
              style={{ backgroundColor: `oklch(from var(--primary) l c h / ${v})` }}
            />
          ))}
          <span>More</span>
        </div>
      </div>
    </div>
  );
}
