import { useEffect, useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { listAudit } from "@/lib/ingestion.functions";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  ScrollText,
  AlertTriangle,
  CheckCircle2,
  Upload,
  Play,
  RefreshCw,
  Download,
  Search,
  X,
  Ban,
  Radio,
  WifiOff,
} from "lucide-react";

import { formatDistanceToNow } from "date-fns";

const ACTION_META: Record<string, { icon: React.ReactNode; label: string; tone: string }> = {
  "ingest.posts": { icon: <Upload className="size-3" />, label: "Ingest", tone: "bg-blue-500/15 text-blue-700 dark:text-blue-300" },
  "ingest.rejected": { icon: <Ban className="size-3" />, label: "Ingest rejected", tone: "bg-rose-500/15 text-rose-700 dark:text-rose-400" },
  "job.retry": { icon: <RefreshCw className="size-3" />, label: "Retry", tone: "bg-amber-500/15 text-amber-700 dark:text-amber-400" },
  "job.recompute": { icon: <Play className="size-3" />, label: "Recompute", tone: "bg-violet-500/15 text-violet-700 dark:text-violet-300" },
  "job.done": { icon: <CheckCircle2 className="size-3" />, label: "Job done", tone: "bg-emerald-500/15 text-emerald-700 dark:text-emerald-400" },
  "job.failed": { icon: <AlertTriangle className="size-3" />, label: "Job failed", tone: "bg-amber-500/15 text-amber-700 dark:text-amber-400" },
  "job.dead": { icon: <AlertTriangle className="size-3" />, label: "Job dead", tone: "bg-rose-500/15 text-rose-700 dark:text-rose-400" },
  "recommendation.export": { icon: <Download className="size-3" />, label: "Export", tone: "bg-slate-500/15 text-slate-700 dark:text-slate-300" },
};

const ACTION_OPTIONS = [
  { value: "all", label: "All actions" },
  { value: "ingest.posts", label: "Ingest" },
  { value: "ingest.rejected", label: "Ingest rejected" },
  { value: "job.retry", label: "Retry" },
  { value: "job.recompute", label: "Recompute" },
  { value: "job.done", label: "Job done" },
  { value: "job.failed", label: "Job failed" },
  { value: "job.dead", label: "Job dead" },
  { value: "recommendation.export", label: "Export" },
];

export function AuditLogPanel({
  competitorId,
  orgId,
  title = "Audit log",
}: {
  competitorId?: string;
  orgId?: string;
  title?: string;
}) {
  const qc = useQueryClient();
  const listFn = useServerFn(listAudit);
  const [q, setQ] = useState("");
  const [action, setAction] = useState("all");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");

  const filters = useMemo(
    () => ({
      competitorId,
      orgId,
      limit: 100,
      q: q.trim() || undefined,
      action: action === "all" ? undefined : action,
      from: from ? new Date(from).toISOString() : undefined,
      to: to ? new Date(to).toISOString() : undefined,
    }),
    [competitorId, orgId, q, action, from, to],
  );

  const [connected, setConnected] = useState(true);
  const { data: rows } = useQuery({
    queryKey: ["audit", competitorId ?? orgId ?? "all", filters],
    queryFn: () => listFn({ data: filters }),
    // Realtime drives updates; fall back to fast poll if the channel drops.
    refetchInterval: connected ? 30_000 : 5_000,
    refetchOnWindowFocus: true,
    refetchOnReconnect: true,
  });

  const scope = competitorId ?? orgId ?? "all";
  useEffect(() => {
    const invalidate = () => qc.invalidateQueries({ queryKey: ["audit", scope] });
    const channel = supabase
      .channel(`audit:${scope}`)
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "audit_events" },
        invalidate,
      )
      .subscribe((status) => {
        setConnected(status === "SUBSCRIBED");
        // Reconcile on (re)subscribe so nothing missed while disconnected slips by.
        if (status === "SUBSCRIBED") invalidate();
      });
    const onVisible = () => {
      if (document.visibilityState === "visible") invalidate();
    };
    document.addEventListener("visibilitychange", onVisible);
    window.addEventListener("online", invalidate);
    return () => {
      supabase.removeChannel(channel);
      document.removeEventListener("visibilitychange", onVisible);
      window.removeEventListener("online", invalidate);
    };
  }, [scope, qc]);


  const items = rows ?? [];
  const anyFilter = q || action !== "all" || from || to;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-base">
          <ScrollText className="size-4" /> {title}
          {connected ? (
            <Radio className="size-3.5 text-emerald-500" aria-label="Live" />
          ) : (
            <WifiOff className="size-3.5 text-amber-500" aria-label="Reconnecting (polling)" />
          )}
        </CardTitle>
        <CardDescription>
          Who triggered ingestion & detection, source, timing, failures.
          {!connected && " · Realtime dropped — reconciling via polling."}
        </CardDescription>

        <div className="mt-3 grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
          <div className="relative">
            <Search className="pointer-events-none absolute left-2 top-1/2 size-3.5 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search actions…"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              className="h-8 pl-7 text-xs"
            />
          </div>
          <Select value={action} onValueChange={setAction}>
            <SelectTrigger className="h-8 text-xs">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {ACTION_OPTIONS.map((o) => (
                <SelectItem key={o.value} value={o.value} className="text-xs">
                  {o.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Input
            type="date"
            value={from}
            onChange={(e) => setFrom(e.target.value)}
            className="h-8 text-xs"
            aria-label="From date"
          />
          <div className="flex gap-1">
            <Input
              type="date"
              value={to}
              onChange={(e) => setTo(e.target.value)}
              className="h-8 text-xs"
              aria-label="To date"
            />
            {anyFilter && (
              <Button
                size="sm"
                variant="ghost"
                className="h-8 px-2"
                onClick={() => {
                  setQ("");
                  setAction("all");
                  setFrom("");
                  setTo("");
                }}
                title="Clear filters"
              >
                <X className="size-3.5" />
              </Button>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {items.length === 0 && (
          <p className="rounded-md border border-dashed p-4 text-center text-sm text-muted-foreground">
            {anyFilter ? "No events match those filters." : "No audit events yet."}
          </p>
        )}
        <ul className="space-y-1.5">
          {items.map((r) => {
            const meta = ACTION_META[r.action] ?? {
              icon: <ScrollText className="size-3" />,
              label: r.action,
              tone: "bg-muted text-foreground",
            };
            let parsed: Record<string, unknown> = {};
            try {
              parsed = JSON.parse(r.metadata_json) as Record<string, unknown>;
            } catch {
              /* ignore */
            }
            return (
              <li key={r.id} className="rounded-md border p-2 text-xs">
                <div className="flex flex-wrap items-center gap-2">
                  <Badge className={`gap-1 ${meta.tone}`} variant="outline">
                    {meta.icon}
                    {meta.label}
                  </Badge>
                  <span className="text-foreground">{r.actor_name || "System"}</span>
                  <span className="text-muted-foreground">·</span>
                  <span className="text-muted-foreground">
                    {formatDistanceToNow(new Date(r.created_at), { addSuffix: true })}
                  </span>
                </div>
                <MetadataSummary action={r.action} data={parsed} />
              </li>
            );
          })}
        </ul>
      </CardContent>
    </Card>
  );
}

function MetadataSummary({ action, data }: { action: string; data: Record<string, unknown> }) {
  const chips: string[] = [];
  const get = (k: string) => data[k];
  if (action === "ingest.posts") {
    if (get("source")) chips.push(`source: ${String(get("source"))}`);
    if (get("handle")) chips.push(`@${String(get("handle"))}`);
    if (get("inserted") != null) chips.push(`${get("inserted")} inserted`);
    if (Number(get("invalid_rows") ?? 0) > 0) chips.push(`${get("invalid_rows")} invalid`);
  } else if (action === "ingest.rejected") {
    if (get("invalid_rows") != null) chips.push(`${get("invalid_rows")} invalid`);
    if (get("total_rows") != null) chips.push(`of ${get("total_rows")}`);
    const first = get("first_issues");
    if (Array.isArray(first) && first.length > 0) chips.push(String(first[0]).slice(0, 100));
  } else if (action.startsWith("job.")) {
    if (get("kind")) chips.push(String(get("kind")));
    if (get("duration_ms") != null) chips.push(`${get("duration_ms")}ms`);
    if (get("attempts") != null) chips.push(`try ${get("attempts")}`);
    if (get("error")) chips.push(String(get("error")).slice(0, 80));
  } else if (action === "recommendation.export") {
    if (get("format")) chips.push(String(get("format")).toUpperCase());
    if (get("rows") != null) chips.push(`${get("rows")} rows`);
  }
  if (chips.length === 0) return null;
  return (
    <p className="mt-1 text-[11px] text-muted-foreground">{chips.join(" · ")}</p>
  );
}
