/**
 * WebhooksPanel — admin config UI for outbound export webhooks.
 * Shows each webhook's signing version, failure state, and recent deliveries.
 * Admins can create/edit/delete webhooks and replay deliveries (including DLQ).
 */
import { useEffect, useMemo, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import {
  listExportWebhooks,
  upsertExportWebhook,
  deleteExportWebhook,
  listWebhookDeliveries,
  replayWebhookDelivery,
  testExportWebhook,
} from "@/lib/exports.functions";
import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectTrigger,
  SelectContent,
  SelectItem,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogDescription,
} from "@/components/ui/dialog";
import { Webhook, Trash2, Plus, RefreshCcw, AlertTriangle, Radio, Clock, Send, ChevronDown, ChevronRight, Search, X } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { toast } from "sonner";

type Hook = {
  id: string;
  url: string;
  events: string[];
  enabled: boolean;
  created_at: string;
  signing_version: string;
  require_timestamp: boolean;
  timestamp_tolerance_seconds: number;
  max_attempts: number;
  consecutive_failures: number;
  last_failure_at: string | null;
  last_failure_reason: string | null;
};

type Delivery = {
  id: string;
  event: string;
  status: string;
  status_code: number | null;
  attempts: number;
  error: string | null;
  next_retry_at: string | null;
  dead_lettered: boolean;
  delivered_at: string | null;
  created_at: string;
  response_body: string | null;
  idempotency_key: string | null;
  correlation_id: string | null;
};

const EVENTS: Array<"export.complete" | "export.failed"> = ["export.complete", "export.failed"];

export function WebhooksPanel({ orgId }: { orgId: string }) {
  const qc = useQueryClient();
  const listFn = useServerFn(listExportWebhooks);
  const upsertFn = useServerFn(upsertExportWebhook);
  const deleteFn = useServerFn(deleteExportWebhook);
  const deliveriesFn = useServerFn(listWebhookDeliveries);
  const replayFn = useServerFn(replayWebhookDelivery);
  const testFn = useServerFn(testExportWebhook);

  const { data: hooks } = useQuery({
    queryKey: ["export-webhooks", orgId],
    queryFn: () => listFn({ data: { orgId } }) as Promise<Hook[]>,
  });

  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [traceFilter, setTraceFilter] = useState("");

  // Deep-link support: #hook=<id>&correlation=<val> (or ?correlation=…) opens
  // that webhook's delivery log with the filter pre-applied so links from the
  // exports panel or an incident thread land on the right context.
  useEffect(() => {
    const apply = () => {
      const raw = window.location.hash.startsWith("#")
        ? window.location.hash.slice(1)
        : window.location.hash;
      const params = new URLSearchParams(raw);
      const hookId = params.get("hook");
      const corr = params.get("correlation") ?? params.get("correlation_id");
      if (hookId) setSelectedId(hookId);
      if (corr) setTraceFilter(corr);
    };
    apply();
    window.addEventListener("hashchange", apply);
    return () => window.removeEventListener("hashchange", apply);
  }, []);

  const { data: deliveries } = useQuery({
    queryKey: ["webhook-deliveries", orgId, selectedId],
    queryFn: () =>
      deliveriesFn({ data: { orgId, webhookId: selectedId!, limit: 20 } }) as Promise<Delivery[]>,
    enabled: !!selectedId,
    refetchInterval: 5000,
  });

  const filteredDeliveries = useMemo(() => {
    const q = traceFilter.trim().toLowerCase();
    if (!q) return deliveries ?? [];
    return (deliveries ?? []).filter(
      (d) =>
        d.correlation_id?.toLowerCase().includes(q) ||
        d.idempotency_key?.toLowerCase().includes(q),
    );
  }, [deliveries, traceFilter]);

  const del = useMutation({
    mutationFn: (id: string) => deleteFn({ data: { id } }),
    onSuccess: () => {
      toast.success("Webhook deleted");
      setSelectedId(null);
      qc.invalidateQueries({ queryKey: ["export-webhooks", orgId] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const replay = useMutation({
    mutationFn: (id: string) => replayFn({ data: { id } }),
    onSuccess: () => {
      toast.success("Replay queued");
      qc.invalidateQueries({ queryKey: ["webhook-deliveries", orgId, selectedId] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const [openDelivery, setOpenDelivery] = useState<string | null>(null);
  const [testPreview, setTestPreview] = useState<{
    hookId: string;
    payload: unknown;
    ok?: boolean;
    status?: number;
    body?: string;
    error?: string | null;
    idempotencyKey?: string;
    correlationId?: string;
    sending: boolean;
  } | null>(null);

  const runTest = async (hookId: string, event: "export.complete" | "export.failed") => {
    const payloadShape = {
      event,
      org_id: orgId,
      delivered_at: new Date().toISOString(),
      test: true,
      data: {
        export_id: "00000000-0000-0000-0000-000000000000",
        kind: "pdf",
        filename: `test-${event}.pdf`,
        rows: 3,
        size_bytes: 1024,
      },
    };
    setTestPreview({ hookId, payload: payloadShape, sending: true });
    try {
      const res = (await testFn({ data: { id: hookId, event } })) as {
        ok: boolean;
        status: number;
        body: string;
        error: string | null;
        payload: unknown;
        idempotencyKey: string;
        correlationId: string;
      };
      setTestPreview({
        hookId,
        payload: res.payload,
        ok: res.ok,
        status: res.status,
        body: res.body,
        error: res.error,
        idempotencyKey: res.idempotencyKey,
        correlationId: res.correlationId,
        sending: false,
      });
      qc.invalidateQueries({ queryKey: ["webhook-deliveries", orgId, hookId] });
      if (res.ok) toast.success(`Test delivered · HTTP ${res.status}`);
      else toast.error(`Test failed · ${res.status || res.error}`);
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      setTestPreview((p) => (p ? { ...p, sending: false, error: msg } : p));
      toast.error(msg);
    }
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-start justify-between gap-2">
        <div>
          <CardTitle className="flex items-center gap-2 text-base">
            <Webhook className="size-4" /> Export webhooks
          </CardTitle>
          <CardDescription>
            Outbound HTTP callbacks for export lifecycle events. Signed with HMAC-SHA256; v2 signs
            <code className="mx-1 rounded bg-muted px-1 text-xs">timestamp.body</code>. Failed
            deliveries retry with exponential backoff and dead-letter after max attempts.
          </CardDescription>
        </div>
        <WebhookEditor orgId={orgId} onSaved={() => qc.invalidateQueries({ queryKey: ["export-webhooks", orgId] })} />
      </CardHeader>
      <CardContent className="grid gap-3">
        {(hooks ?? []).length === 0 && (
          <p className="rounded-md border border-dashed p-4 text-center text-sm text-muted-foreground">
            No webhooks configured yet.
          </p>
        )}
        {(hooks ?? []).map((h) => (
          <div key={h.id} className="grid gap-2 rounded-md border p-3">
            <div className="flex flex-wrap items-center gap-2 text-sm">
              <Badge variant={h.enabled ? "default" : "outline"}>{h.enabled ? "on" : "off"}</Badge>
              <code className="truncate font-mono text-xs">{h.url}</code>
              <div className="ml-auto flex items-center gap-1">
                <Badge variant="secondary" className="text-[10px]">sig {h.signing_version}</Badge>
                {h.require_timestamp && (
                  <Badge variant="secondary" className="text-[10px]"><Clock className="size-3" /> ts</Badge>
                )}
                <Badge variant="outline" className="text-[10px]">max {h.max_attempts}</Badge>
              </div>
            </div>
            <div className="flex flex-wrap gap-1">
              {h.events.map((e) => (
                <Badge key={e} variant="outline" className="text-[10px]">{e}</Badge>
              ))}
            </div>
            {h.consecutive_failures > 0 && (
              <div className="rounded-md border border-destructive/40 bg-destructive/5 p-2 text-xs">
                <div className="flex items-center gap-1 font-medium text-destructive">
                  <AlertTriangle className="size-3.5" /> {h.consecutive_failures} consecutive failures
                </div>
                {h.last_failure_reason && (
                  <div className="mt-0.5 truncate font-mono text-[10px] text-muted-foreground">
                    {h.last_failure_reason}
                  </div>
                )}
              </div>
            )}
            <div className="flex items-center justify-between border-t pt-2">
              <Button
                size="sm"
                variant="ghost"
                onClick={() => setSelectedId(selectedId === h.id ? null : h.id)}
              >
                <Radio className="size-3.5" /> {selectedId === h.id ? "Hide" : "Show"} deliveries
              </Button>
              <div className="flex gap-1">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => runTest(h.id, "export.complete")}
                  disabled={!h.enabled || (testPreview?.hookId === h.id && !!testPreview?.sending)}
                  title="Send a synthetic delivery to preview the exact payload and verify your endpoint"
                >
                  <Send className="size-3.5" /> Send test
                </Button>
                <WebhookEditor
                  orgId={orgId}
                  hook={h}
                  onSaved={() => qc.invalidateQueries({ queryKey: ["export-webhooks", orgId] })}
                />
                <Button size="sm" variant="ghost" className="text-destructive" onClick={() => del.mutate(h.id)}>
                  <Trash2 className="size-3.5" />
                </Button>
              </div>
            </div>
            {testPreview?.hookId === h.id && (
              <div className="grid gap-1 rounded-md border bg-muted/30 p-2 text-xs">
                <div className="flex items-center gap-2 font-medium">
                  <Send className="size-3.5" /> Test delivery
                  {testPreview.sending ? (
                    <Badge variant="secondary">sending…</Badge>
                  ) : testPreview.ok ? (
                    <Badge>HTTP {testPreview.status}</Badge>
                  ) : (
                    <Badge variant="outline" className="border-destructive text-destructive">
                      {testPreview.status ? `HTTP ${testPreview.status}` : "failed"}
                    </Badge>
                  )}
                  <button
                    className="ml-auto text-muted-foreground hover:text-foreground"
                    onClick={() => setTestPreview(null)}
                  >
                    close
                  </button>
                </div>
                <div>
                  <div className="mb-1 text-[10px] uppercase text-muted-foreground">Payload sent</div>
                  <pre className="max-h-40 overflow-auto rounded bg-background p-2 font-mono text-[10px]">
                    {JSON.stringify(testPreview.payload, null, 2)}
                  </pre>
                </div>
                {(testPreview.idempotencyKey || testPreview.correlationId) && (
                  <div className="grid grid-cols-1 gap-1 rounded bg-background p-2 text-[10px] sm:grid-cols-2">
                    <div className="flex items-center gap-2">
                      <span className="text-muted-foreground">Idempotency-Key</span>
                      <code
                        className="cursor-pointer font-mono"
                        title="Click to copy"
                        onClick={() =>
                          testPreview.idempotencyKey && navigator.clipboard.writeText(testPreview.idempotencyKey)
                        }
                      >
                        {testPreview.idempotencyKey}
                      </code>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-muted-foreground">Correlation-ID</span>
                      <code
                        className="cursor-pointer font-mono"
                        title="Click to copy"
                        onClick={() =>
                          testPreview.correlationId && navigator.clipboard.writeText(testPreview.correlationId)
                        }
                      >
                        {testPreview.correlationId}
                      </code>
                    </div>
                  </div>
                )}
                {(testPreview.body || testPreview.error) && (
                  <div>
                    <div className="mb-1 text-[10px] uppercase text-muted-foreground">Response</div>
                    <pre className="max-h-32 overflow-auto rounded bg-background p-2 font-mono text-[10px]">
                      {testPreview.error || testPreview.body || "(empty)"}
                    </pre>
                  </div>
                )}
              </div>
            )}
            {selectedId === h.id && (
              <div className="grid gap-1.5 border-t pt-2 text-xs">
                <div className="flex items-center gap-1.5">
                  <div className="relative flex-1">
                    <Search className="pointer-events-none absolute left-2 top-1/2 size-3 -translate-y-1/2 text-muted-foreground" />
                    <Input
                      className="h-7 pl-7 font-mono text-[11px]"
                      placeholder="Filter by correlation ID or idempotency key…"
                      value={traceFilter}
                      onChange={(e) => setTraceFilter(e.target.value)}
                    />
                  </div>
                  {traceFilter && (
                    <Button size="sm" variant="ghost" onClick={() => setTraceFilter("")} title="Clear filter">
                      <X className="size-3.5" />
                    </Button>
                  )}
                  {traceFilter && (
                    <span className="text-[10px] text-muted-foreground">
                      {filteredDeliveries.length}/{deliveries?.length ?? 0}
                    </span>
                  )}
                </div>
                {(deliveries ?? []).length === 0 && (
                  <p className="text-muted-foreground">No deliveries yet.</p>
                )}
                {deliveries && deliveries.length > 0 && filteredDeliveries.length === 0 && (
                  <p className="text-muted-foreground">No deliveries match that trace ID.</p>
                )}
                {filteredDeliveries.map((d) => {
                  const expanded = openDelivery === d.id;
                  return (
                    <div key={d.id} className="rounded-md border">
                      <div className="grid grid-cols-[auto_1fr_auto_auto] items-center gap-2 p-2">
                        <Badge
                          variant={
                            d.status === "delivered"
                              ? "default"
                              : d.dead_lettered
                                ? "outline"
                                : d.status === "retry"
                                  ? "secondary"
                                  : "outline"
                          }
                          className={d.dead_lettered ? "border-destructive text-destructive" : ""}
                        >
                          {d.dead_lettered ? "DLQ" : d.status}
                        </Badge>
                        <div className="min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="font-mono">{d.event}</span>
                            <span className="text-muted-foreground">
                              attempt {d.attempts}
                              {d.status_code ? ` · HTTP ${d.status_code}` : ""}
                            </span>
                          </div>
                          {d.error && (
                            <div className="truncate font-mono text-[10px] text-destructive">{d.error}</div>
                          )}
                          <div className="text-[10px] text-muted-foreground">
                            {d.delivered_at
                              ? `delivered ${formatDistanceToNow(new Date(d.delivered_at), { addSuffix: true })}`
                              : d.next_retry_at
                                ? `retry ${formatDistanceToNow(new Date(d.next_retry_at), { addSuffix: true })}`
                                : formatDistanceToNow(new Date(d.created_at), { addSuffix: true })}
                          </div>
                        </div>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => setOpenDelivery(expanded ? null : d.id)}
                          title="Show response body"
                        >
                          {expanded ? <ChevronDown className="size-3.5" /> : <ChevronRight className="size-3.5" />}
                        </Button>
                        {(d.status !== "delivered" || d.dead_lettered) ? (
                          <Button size="sm" variant="ghost" onClick={() => replay.mutate(d.id)}>
                            <RefreshCcw className="size-3.5" /> Replay
                          </Button>
                        ) : (
                          <span />
                        )}
                      </div>
                      {expanded && (
                        <div className="border-t bg-muted/30 p-2">
                          <div className="mb-1 text-[10px] uppercase text-muted-foreground">
                            Response body {d.status_code ? `(HTTP ${d.status_code})` : ""}
                          </div>
                          <pre className="max-h-40 overflow-auto rounded bg-background p-2 font-mono text-[10px] leading-relaxed">
                            {d.response_body || d.error || "(empty response)"}
                          </pre>
                          <div className="mt-1 grid grid-cols-2 gap-2 text-[10px] text-muted-foreground">
                            <div>Created: {new Date(d.created_at).toLocaleString()}</div>
                            {d.delivered_at && <div>Delivered: {new Date(d.delivered_at).toLocaleString()}</div>}
                            {d.next_retry_at && <div>Next retry: {new Date(d.next_retry_at).toLocaleString()}</div>}
                            <div>Attempts: {d.attempts}</div>
                          </div>
                          <div className="mt-2 space-y-1 border-t pt-2 text-[10px]">
                            <div className="uppercase text-muted-foreground">Tracing</div>
                            <div className="flex items-center gap-2">
                              <span className="text-muted-foreground">Idempotency-Key</span>
                              <code
                                className="cursor-pointer rounded bg-background px-1 py-0.5 font-mono"
                                title="Click to copy — send this back with retries to dedupe"
                                onClick={() => d.idempotency_key && navigator.clipboard.writeText(d.idempotency_key)}
                              >
                                {d.idempotency_key ?? "—"}
                              </code>
                            </div>
                            <div className="flex items-center gap-2">
                              <span className="text-muted-foreground">Correlation-ID</span>
                              <code
                                className="cursor-pointer rounded bg-background px-1 py-0.5 font-mono"
                                title="Click to copy — shared by all deliveries for this event"
                                onClick={() => d.correlation_id && navigator.clipboard.writeText(d.correlation_id)}
                              >
                                {d.correlation_id ?? "—"}
                              </code>
                              {d.correlation_id && (
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  className="h-6 px-1.5 text-[10px]"
                                  onClick={() => setTraceFilter(d.correlation_id!)}
                                  title="Filter this delivery log to related attempts"
                                >
                                  <Search className="size-3" /> Trace
                                </Button>
                              )}
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        ))}
      </CardContent>
    </Card>
  );
}

function WebhookEditor({
  orgId,
  hook,
  onSaved,
}: {
  orgId: string;
  hook?: Hook;
  onSaved: () => void;
}) {
  const [open, setOpen] = useState(false);
  const [url, setUrl] = useState(hook?.url ?? "");
  const [events, setEvents] = useState<string[]>(hook?.events ?? [...EVENTS]);
  const [enabled, setEnabled] = useState(hook?.enabled ?? true);
  const [signingVersion, setSigningVersion] = useState<string>(hook?.signing_version ?? "v1");
  const [requireTimestamp, setRequireTimestamp] = useState(hook?.require_timestamp ?? false);
  const [tolerance, setTolerance] = useState(hook?.timestamp_tolerance_seconds ?? 300);
  const [maxAttempts, setMaxAttempts] = useState(hook?.max_attempts ?? 6);
  const [secret, setSecret] = useState("");

  const upsertFn = useServerFn(upsertExportWebhook);
  const save = useMutation({
    mutationFn: () =>
      upsertFn({
        data: {
          id: hook?.id,
          orgId,
          url,
          events: events as ("export.complete" | "export.failed")[],
          isActive: enabled,
          signingVersion: signingVersion as "v1" | "v2",
          requireTimestamp,
          timestampToleranceSeconds: tolerance,
          maxAttempts,
          ...(secret ? { secret } : {}),
        },
      }) as Promise<{ id: string; secret: string }>,
    onSuccess: (res) => {
      if (!hook) {
        toast.success("Webhook created", {
          description: `Copy the signing secret now — it won't be shown again: ${res.secret}`,
          duration: 20000,
        });
      } else {
        toast.success("Webhook updated");
      }
      onSaved();
      setOpen(false);
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="sm" variant={hook ? "ghost" : "default"}>
          {hook ? "Edit" : (<><Plus className="size-3.5" /> Add</>)}
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>{hook ? "Edit webhook" : "New webhook"}</DialogTitle>
          <DialogDescription>
            v2 signing includes a timestamp header your receiver should verify to reject replayed
            requests. Tolerance controls how old a valid timestamp can be.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-3">
          <div className="grid gap-1">
            <Label className="text-xs">Endpoint URL</Label>
            <Input value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://example.com/hooks/spotnxt" />
          </div>
          <div className="grid gap-1">
            <Label className="text-xs">Events</Label>
            <div className="flex flex-wrap gap-3 rounded-md border p-2">
              {EVENTS.map((e) => (
                <label key={e} className="flex items-center gap-1.5 text-xs">
                  <Checkbox
                    checked={events.includes(e)}
                    onCheckedChange={(v) =>
                      setEvents((prev) => (v ? [...new Set([...prev, e])] : prev.filter((x) => x !== e)))
                    }
                  />
                  <span className="font-mono">{e}</span>
                </label>
              ))}
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="grid gap-1">
              <Label className="text-xs">Signing version</Label>
              <Select value={signingVersion} onValueChange={setSigningVersion}>
                <SelectTrigger className="h-8"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="v1">v1 (body only)</SelectItem>
                  <SelectItem value="v2">v2 (timestamp.body)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-1">
              <Label className="text-xs">Max attempts</Label>
              <Input
                type="number"
                min={1}
                max={20}
                value={maxAttempts}
                onChange={(e) => setMaxAttempts(Math.max(1, Math.min(20, Number(e.target.value) || 6)))}
              />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="grid gap-1">
              <Label className="text-xs">Require timestamp header</Label>
              <div className="flex h-8 items-center">
                <Switch checked={requireTimestamp} onCheckedChange={setRequireTimestamp} />
              </div>
            </div>
            <div className="grid gap-1">
              <Label className="text-xs">Timestamp tolerance (s)</Label>
              <Input
                type="number"
                min={30}
                max={3600}
                value={tolerance}
                onChange={(e) => setTolerance(Math.max(30, Math.min(3600, Number(e.target.value) || 300)))}
              />
            </div>
          </div>
          <div className="grid gap-1">
            <Label className="text-xs">
              Enabled
            </Label>
            <div className="flex h-8 items-center">
              <Switch checked={enabled} onCheckedChange={setEnabled} />
            </div>
          </div>
          {!hook && (
            <div className="grid gap-1">
              <Label className="text-xs">Signing secret (optional — auto-generated if blank)</Label>
              <Input value={secret} onChange={(e) => setSecret(e.target.value)} placeholder="Leave empty to generate a strong secret" />
            </div>
          )}
          <Button onClick={() => save.mutate()} disabled={save.isPending || !url}>
            {hook ? "Save changes" : "Create webhook"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
