/**
 * Share links dialog: manage every share link tied to a given export.
 * Actions: revoke, regenerate with new expiry, copy public URL.
 * Uses listExportShareLinks / revokeExportShareLink / regenerateExportShareLink.
 */
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import {
  listExportShareLinks,
  revokeExportShareLink,
  regenerateExportShareLink,
} from "@/lib/exports.functions";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Link2, RefreshCcw, Copy, XCircle, Check } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { toast } from "sonner";

type Link = {
  id: string;
  token: string;
  expires_at: string;
  max_downloads: number | null;
  download_count: number;
  revoked_at: string | null;
  created_at: string;
};

export function ShareLinksDialog({
  exportId,
  trigger,
}: {
  exportId: string;
  trigger: React.ReactNode;
}) {
  const [open, setOpen] = useState(false);
  const [ttl, setTtl] = useState(24);
  const qc = useQueryClient();
  const listFn = useServerFn(listExportShareLinks);
  const revokeFn = useServerFn(revokeExportShareLink);
  const regenFn = useServerFn(regenerateExportShareLink);

  const key = ["share-links", exportId];
  const { data: links, isLoading } = useQuery({
    queryKey: key,
    queryFn: () => listFn({ data: { exportId } }) as Promise<Link[]>,
    enabled: open,
    refetchInterval: open ? 5000 : false,
  });

  const revoke = useMutation({
    mutationFn: (id: string) => revokeFn({ data: { id } }),
    onSuccess: () => {
      toast.success("Link revoked");
      qc.invalidateQueries({ queryKey: key });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const regenerate = useMutation({
    mutationFn: (id: string) =>
      regenFn({ data: { id, ttlHours: ttl, revokeExisting: true } }) as Promise<{
        token: string;
        expiresAt: string;
      }>,
    onSuccess: async (res) => {
      const url = `${window.location.origin}/api/public/share/exports/${res.token}`;
      try {
        await navigator.clipboard.writeText(url);
        toast.success(`New link copied · expires in ${ttl}h`, { description: url });
      } catch {
        toast.success("New link created", { description: url });
      }
      qc.invalidateQueries({ queryKey: key });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const copy = async (token: string) => {
    const url = `${window.location.origin}/api/public/share/exports/${token}`;
    try {
      await navigator.clipboard.writeText(url);
      toast.success("URL copied");
    } catch {
      toast.error("Copy failed");
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{trigger}</DialogTrigger>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Link2 className="size-4" /> Share links
          </DialogTitle>
          <DialogDescription>
            Regenerate produces a fresh token and expiry without touching the underlying export
            artifact. Existing token becomes invalid.
          </DialogDescription>
        </DialogHeader>
        <div className="flex items-end gap-2 border-b pb-3">
          <div className="grid gap-1">
            <Label className="text-xs">New expiry (hours)</Label>
            <Input
              type="number"
              min={1}
              max={720}
              value={ttl}
              onChange={(e) => setTtl(Math.max(1, Math.min(720, Number(e.target.value) || 24)))}
              className="w-28"
            />
          </div>
          <p className="pb-2 text-xs text-muted-foreground">
            Applies to the "Regenerate" action per row.
          </p>
        </div>
        <div className="max-h-[420px] overflow-auto">
          {isLoading && <p className="p-3 text-sm text-muted-foreground">Loading…</p>}
          {!isLoading && (!links || links.length === 0) && (
            <p className="rounded-md border border-dashed p-4 text-center text-sm text-muted-foreground">
              No share links yet. Use the Share button on the export row to create one.
            </p>
          )}
          <div className="grid gap-2">
            {(links ?? []).map((l) => {
              const revoked = !!l.revoked_at;
              const expired = new Date(l.expires_at).getTime() < Date.now();
              const state = revoked ? "revoked" : expired ? "expired" : "active";
              return (
                <div
                  key={l.id}
                  className="grid gap-2 rounded-md border p-3 text-xs md:grid-cols-[1fr_auto]"
                >
                  <div className="grid gap-1">
                    <div className="flex items-center gap-2">
                      <Badge
                        variant={state === "active" ? "default" : "outline"}
                        className={
                          state === "revoked"
                            ? "border-destructive text-destructive"
                            : state === "expired"
                              ? "border-muted-foreground text-muted-foreground"
                              : ""
                        }
                      >
                        {state}
                      </Badge>
                      <span className="font-mono">
                        …{l.token.slice(-10)}
                      </span>
                      <span className="text-muted-foreground">
                        · {l.download_count} download{l.download_count === 1 ? "" : "s"}
                        {l.max_downloads && l.max_downloads > 0 ? ` / ${l.max_downloads}` : ""}
                      </span>
                    </div>
                    <div className="text-muted-foreground">
                      created {formatDistanceToNow(new Date(l.created_at), { addSuffix: true })} ·
                      {revoked
                        ? " revoked"
                        : expired
                          ? " expired"
                          : ` expires ${formatDistanceToNow(new Date(l.expires_at), { addSuffix: true })}`}
                    </div>
                  </div>
                  <div className="flex items-center gap-1">
                    {state === "active" && (
                      <Button size="sm" variant="ghost" onClick={() => copy(l.token)}>
                        <Copy className="size-3.5" />
                      </Button>
                    )}
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => regenerate.mutate(l.id)}
                      disabled={regenerate.isPending}
                      title="Revoke this link and create a new one with the given expiry"
                    >
                      <RefreshCcw className="size-3.5" /> Regenerate
                    </Button>
                    {state === "active" && (
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => revoke.mutate(l.id)}
                        disabled={revoke.isPending}
                        className="text-destructive"
                      >
                        <XCircle className="size-3.5" />
                      </Button>
                    )}
                    {state === "revoked" && <Check className="size-3.5 text-muted-foreground" />}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
