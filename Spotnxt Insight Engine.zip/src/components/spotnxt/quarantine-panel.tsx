import { useEffect, useMemo, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import {
  listQuarantine,
  resubmitQuarantine,
  dismissQuarantine,
  updateQuarantineRaw,
} from "@/lib/ingestion.functions";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { AlertTriangle, RefreshCw, Trash2, CheckCircle2, Pencil, Radio, WifiOff } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { toast } from "sonner";

type Row = {
  id: string;
  org_id: string;
  competitor_id: string;
  source: string;
  batch_id: string | null;
  row_index: number | null;
  raw: unknown;
  issues: unknown;
  status: string;
  submitted_by: string | null;
  created_at: string;
  updated_at: string;
};

export function QuarantinePanel({
  competitorId,
  orgId,
}: {
  competitorId?: string;
  orgId?: string;
}) {
  const qc = useQueryClient();
  const listFn = useServerFn(listQuarantine);
  const resubmitFn = useServerFn(resubmitQuarantine);
  const dismissFn = useServerFn(dismissQuarantine);
  const updateFn = useServerFn(updateQuarantineRaw);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [editing, setEditing] = useState<Record<string, string>>({});
  const [connected, setConnected] = useState(true);

  const queryKey = ["quarantine", competitorId ?? orgId ?? "all"];
  const { data: rows, refetch } = useQuery({
    queryKey,
    queryFn: () =>
      listFn({ data: { competitorId, orgId, status: "pending", limit: 200 } }) as Promise<Row[]>,
    refetchInterval: connected ? 30_000 : 5_000, // fall back to fast polling if realtime drops
    refetchOnWindowFocus: true,
    refetchOnReconnect: true,
  });

  const scope = competitorId ?? orgId ?? "all";
  useEffect(() => {
    const channel = supabase
      .channel(`quarantine:${scope}`)
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "ingest_quarantine" },
        () => qc.invalidateQueries({ queryKey }),
      )
      .subscribe((status) => {
        setConnected(status === "SUBSCRIBED");
        if (status === "SUBSCRIBED") qc.invalidateQueries({ queryKey });
      });
    // Reconcile on tab focus / reconnect in case realtime dropped events.
    const onFocus = () => {
      if (document.visibilityState === "visible") qc.invalidateQueries({ queryKey });
    };
    const onOnline = () => qc.invalidateQueries({ queryKey });
    document.addEventListener("visibilitychange", onFocus);
    window.addEventListener("online", onOnline);
    return () => {
      supabase.removeChannel(channel);
      document.removeEventListener("visibilitychange", onFocus);
      window.removeEventListener("online", onOnline);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [scope]);

  const items = rows ?? [];
  const allSelected = items.length > 0 && items.every((r) => selected.has(r.id));

  const resubmit = useMutation({
    mutationFn: (ids: string[]) => resubmitFn({ data: { ids } }),
    onSuccess: (res) => {
      toast.success(
        `${res.ingested} row(s) ingested${res.stillInvalid > 0 ? `, ${res.stillInvalid} still invalid` : ""}`,
      );
      setSelected(new Set());
      qc.invalidateQueries({ queryKey });
      qc.invalidateQueries({ queryKey: ["jobs"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const dismiss = useMutation({
    mutationFn: (ids: string[]) => dismissFn({ data: { ids } }),
    onSuccess: (res) => {
      toast.success(`${res.dismissed} dismissed`);
      setSelected(new Set());
      qc.invalidateQueries({ queryKey });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const saveEdit = useMutation({
    mutationFn: async (id: string) => {
      const text = editing[id];
      let raw: unknown;
      try {
        raw = JSON.parse(text);
      } catch {
        throw new Error("Edit is not valid JSON");
      }
      return updateFn({ data: { id, raw } });
    },
    onSuccess: (_res, id) => {
      toast.success("Saved");
      setEditing((e) => {
        const n = { ...e };
        delete n[id];
        return n;
      });
      qc.invalidateQueries({ queryKey });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <Card>
      <CardHeader>
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <CardTitle className="flex items-center gap-2 text-base">
              <AlertTriangle className="size-4 text-amber-500" />
              Quarantine
              {connected ? (
                <Radio className="size-3.5 text-emerald-500" aria-label="Live" />
              ) : (
                <WifiOff className="size-3.5 text-amber-500" aria-label="Reconnecting" />
              )}
              <Badge variant="secondary">{items.length}</Badge>
            </CardTitle>
            <CardDescription>
              Rejected rows waiting for review. Fix the source, edit inline, then resubmit.
            </CardDescription>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button size="sm" variant="outline" onClick={() => refetch()}>
              <RefreshCw className="size-3.5" /> Refresh
            </Button>
            <Button
              size="sm"
              disabled={selected.size === 0 || resubmit.isPending}
              onClick={() => resubmit.mutate([...selected])}
            >
              <CheckCircle2 className="size-3.5" />
              Resubmit ({selected.size})
            </Button>
            <Button
              size="sm"
              variant="outline"
              disabled={selected.size === 0 || dismiss.isPending}
              onClick={() => dismiss.mutate([...selected])}
            >
              <Trash2 className="size-3.5" />
              Dismiss
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-2">
        {items.length === 0 && (
          <p className="rounded-md border border-dashed p-4 text-center text-sm text-muted-foreground">
            Nothing quarantined. Every ingested row passed validation.
          </p>
        )}
        {items.length > 0 && (
          <label className="flex items-center gap-2 text-xs text-muted-foreground">
            <input
              type="checkbox"
              checked={allSelected}
              onChange={(e) => {
                if (e.target.checked) setSelected(new Set(items.map((r) => r.id)));
                else setSelected(new Set());
              }}
              className="accent-primary"
            />
            Select all
          </label>
        )}
        {items.map((r) => (
          <QuarantineRow
            key={r.id}
            row={r}
            selected={selected.has(r.id)}
            editing={editing[r.id]}
            savingEdit={saveEdit.isPending}
            onToggle={() =>
              setSelected((s) => {
                const n = new Set(s);
                if (n.has(r.id)) n.delete(r.id);
                else n.add(r.id);
                return n;
              })
            }
            onStartEdit={() =>
              setEditing((e) => ({ ...e, [r.id]: JSON.stringify(r.raw, null, 2) }))
            }
            onChangeEdit={(v) => setEditing((e) => ({ ...e, [r.id]: v }))}
            onCancelEdit={() =>
              setEditing((e) => {
                const n = { ...e };
                delete n[r.id];
                return n;
              })
            }
            onSaveEdit={() => saveEdit.mutate(r.id)}
          />
        ))}
      </CardContent>
    </Card>
  );
}

function QuarantineRow({
  row,
  selected,
  editing,
  savingEdit,
  onToggle,
  onStartEdit,
  onChangeEdit,
  onCancelEdit,
  onSaveEdit,
}: {
  row: Row;
  selected: boolean;
  editing: string | undefined;
  savingEdit: boolean;
  onToggle: () => void;
  onStartEdit: () => void;
  onChangeEdit: (v: string) => void;
  onCancelEdit: () => void;
  onSaveEdit: () => void;
}) {
  const issues = useMemo(() => {
    const raw = row.issues;
    if (Array.isArray(raw)) {
      return raw
        .map((i) => (typeof i === "object" && i && "message" in i ? String((i as { message: unknown }).message) : String(i)))
        .filter(Boolean);
    }
    return [];
  }, [row.issues]);

  const preview = useMemo(() => {
    try {
      return JSON.stringify(row.raw, null, 2);
    } catch {
      return String(row.raw);
    }
  }, [row.raw]);

  return (
    <div className="rounded-md border p-2.5 text-xs">
      <div className="flex flex-wrap items-center gap-2">
        <input
          type="checkbox"
          checked={selected}
          onChange={onToggle}
          className="accent-primary"
          aria-label="Select row"
        />
        <Badge variant="outline" className="text-[10px]">
          {row.source}
        </Badge>
        {row.row_index != null && (
          <span className="text-muted-foreground">row {row.row_index}</span>
        )}
        <span className="text-muted-foreground">
          {formatDistanceToNow(new Date(row.created_at), { addSuffix: true })}
        </span>
        <div className="ml-auto flex gap-1">
          {editing === undefined ? (
            <Button size="sm" variant="ghost" className="h-6 px-2" onClick={onStartEdit}>
              <Pencil className="size-3" /> Edit
            </Button>
          ) : (
            <>
              <Button size="sm" variant="outline" className="h-6 px-2" onClick={onCancelEdit}>
                Cancel
              </Button>
              <Button size="sm" className="h-6 px-2" onClick={onSaveEdit} disabled={savingEdit}>
                Save
              </Button>
            </>
          )}
        </div>
      </div>
      {issues.length > 0 && (
        <ul className="mt-1.5 ml-6 list-disc text-rose-600 dark:text-rose-400">
          {issues.map((i, idx) => (
            <li key={idx}>{i}</li>
          ))}
        </ul>
      )}
      {editing === undefined ? (
        <pre className="mt-1.5 max-h-40 overflow-auto rounded bg-muted/40 p-1.5 font-mono text-[11px] text-muted-foreground">
          {preview}
        </pre>
      ) : (
        <Textarea
          value={editing}
          onChange={(e) => onChangeEdit(e.target.value)}
          rows={8}
          className="mt-1.5 font-mono text-[11px]"
        />
      )}
    </div>
  );
}
