import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { PLATFORM_LABEL } from "@/lib/platforms";

type Campaign = {
  id: string;
  name: string | null;
  hashtag_cluster: unknown;
  start_date: string | null;
  end_date: string | null;
  confidence: number | string | null;
  cross_platform_sync: number | string | null;
};

type Cluster = {
  hashtags?: string[];
  post_count?: number;
  platforms?: string[];
  avg_engagement?: number;
};

export function CampaignTimeline({ campaigns: rawCampaigns }: { campaigns: Campaign[] }) {
  const campaigns = rawCampaigns.filter(
    (c): c is Campaign & { name: string; start_date: string; end_date: string } =>
      !!c.name && !!c.start_date && !!c.end_date,
  );
  if (campaigns.length === 0) {
    return (
      <Card>
        <CardContent className="py-10 text-center text-sm text-muted-foreground">
          No campaigns detected yet.
        </CardContent>
      </Card>
    );
  }

  const starts = campaigns.map((c) => new Date(c.start_date).getTime());
  const ends = campaigns.map((c) => new Date(c.end_date).getTime());
  const min = Math.min(...starts);
  const max = Math.max(...ends);
  const span = Math.max(1, max - min);

  // Group by lane (kind of campaign) so the timeline reads
  const lanes = new Map<string, Campaign[]>();
  for (const c of campaigns) {
    const kind = c.name.split(" — ")[0];
    if (!lanes.has(kind)) lanes.set(kind, []);
    lanes.get(kind)!.push(c);
  }

  const monthTicks: { label: string; pct: number }[] = [];
  const cursor = new Date(min);
  cursor.setUTCDate(1);
  while (cursor.getTime() <= max) {
    monthTicks.push({
      label: cursor.toLocaleString("en", { month: "short" }),
      pct: ((cursor.getTime() - min) / span) * 100,
    });
    cursor.setUTCMonth(cursor.getUTCMonth() + 1);
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Campaign timeline</CardTitle>
        <CardDescription>
          {campaigns.length} campaigns detected across{" "}
          {new Set(campaigns.flatMap((c) => (c.hashtag_cluster as Cluster)?.platforms ?? [])).size}{" "}
          platforms. Bar width = campaign window, opacity = confidence.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="relative h-6 border-b border-border">
          {monthTicks.map((t) => (
            <div
              key={t.label + t.pct}
              className="absolute top-0 h-full border-l border-border/60 pl-1 text-[10px] text-muted-foreground"
              style={{ left: `${t.pct}%` }}
            >
              {t.label}
            </div>
          ))}
        </div>

        <div className="space-y-4">
          {[...lanes.entries()].map(([kind, items]) => (
            <div key={kind}>
              <div className="mb-1.5 text-xs font-medium text-muted-foreground">{kind}</div>
              <div className="relative h-8 rounded-md bg-muted/30">
                {items.map((c) => {
                  const s = new Date(c.start_date as string).getTime();
                  const e = new Date(c.end_date as string).getTime();
                  const left = ((s - min) / span) * 100;
                  const width = Math.max(1.5, ((e - s) / span) * 100);
                  const conf = Number(c.confidence);
                  const cluster = c.hashtag_cluster as Cluster;
                  return (
                    <div
                      key={c.id}
                      className="group absolute top-1 flex h-6 items-center overflow-hidden rounded-md bg-primary px-1.5 text-[10px] font-medium text-primary-foreground"
                      style={{ left: `${left}%`, width: `${width}%`, opacity: 0.35 + conf * 0.6 }}
                      title={`${c.name} · conf ${(conf * 100).toFixed(0)}% · sync ${(Number(c.cross_platform_sync) * 100).toFixed(0)}%`}
                    >
                      <span className="truncate">
                        {(cluster?.post_count ?? 0)} posts
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>

        <div className="grid gap-2 pt-2 md:grid-cols-2">
          {campaigns.slice(0, 6).map((c) => {
            const cluster = c.hashtag_cluster as Cluster;
            return (
              <div key={c.id} className="rounded-md border p-3 text-sm">
                <div className="mb-1 flex items-center justify-between">
                  <span className="font-medium">{c.name}</span>
                  <span className="text-xs text-muted-foreground">
                    {new Date(c.start_date).toLocaleDateString()} →{" "}
                    {new Date(c.end_date).toLocaleDateString()}
                  </span>
                </div>
                <div className="mb-2 flex flex-wrap gap-1">
                  {(cluster?.hashtags ?? []).map((h) => (
                    <Badge key={h} variant="secondary" className="text-[10px]">{h}</Badge>
                  ))}
                </div>
                <div className="flex flex-wrap gap-3 text-xs text-muted-foreground">
                  <span>{cluster?.post_count ?? 0} posts</span>
                  <span>·</span>
                  <span>{(Number(c.confidence) * 100).toFixed(0)}% confidence</span>
                  <span>·</span>
                  <span>{(Number(c.cross_platform_sync) * 100).toFixed(0)}% cross-platform sync</span>
                </div>
                <div className="mt-1.5 flex flex-wrap gap-1">
                  {(cluster?.platforms ?? []).map((p) => (
                    <Badge key={p} variant="outline" className="text-[9px]">
                      {PLATFORM_LABEL[p] ?? p}
                    </Badge>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
