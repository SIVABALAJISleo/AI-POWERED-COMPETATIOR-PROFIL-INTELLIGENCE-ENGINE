import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { ingestPosts } from "@/lib/ingestion.functions";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Download, FileJson, FileSpreadsheet, AlertTriangle, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";

type IngestResult = {
  inserted: number;
  jobsQueued: number;
  invalidRows: number;
  errors: { row: number; issues: string[]; preview?: string }[];
  message: string;
};

export function IngestPanel({ competitorId }: { competitorId: string }) {
  const [handle, setHandle] = useState("");
  const [json, setJson] = useState("");
  const [csv, setCsv] = useState("");
  const [strict, setStrict] = useState(true);
  const [result, setResult] = useState<IngestResult | null>(null);
  const [clientError, setClientError] = useState<string | null>(null);
  const qc = useQueryClient();
  const ingestFn = useServerFn(ingestPosts);

  type IngestPayload = {
    competitorId: string;
    source: "x" | "json" | "csv";
    handle?: string;
    json?: unknown[];
    csv?: string;
    strict?: boolean;
  };
  const mutate = useMutation({
    mutationFn: (payload: IngestPayload) => ingestFn({ data: payload }) as Promise<IngestResult>,
    onSuccess: (res) => {
      setResult(res);
      setClientError(null);
      if (res.inserted > 0) toast.success(res.message);
      else toast.error(res.message);
      qc.invalidateQueries({ queryKey: ["jobs", competitorId] });
      qc.invalidateQueries({ queryKey: ["audit", competitorId] });
      qc.invalidateQueries({ queryKey: ["frequency", competitorId] });
      qc.invalidateQueries({ queryKey: ["top-posts", competitorId] });
      qc.invalidateQueries({ queryKey: ["creative-dna", competitorId] });
      qc.invalidateQueries({ queryKey: ["campaigns", competitorId] });
    },
    onError: (e: Error) => {
      setResult(null);
      setClientError(e.message);
      toast.error(e.message);
    },
  });

  const runX = () => {
    setClientError(null);
    if (!handle.trim()) {
      setClientError("Enter an X handle (e.g. @nike)");
      return;
    }
    mutate.mutate({ competitorId, source: "x", handle: handle.trim(), strict });
  };

  const runJson = () => {
    setClientError(null);
    if (!json.trim()) {
      setClientError("Paste a JSON array of posts");
      return;
    }
    let parsed: unknown;
    try {
      parsed = JSON.parse(json);
    } catch (e) {
      setClientError(`Invalid JSON: ${e instanceof Error ? e.message : "parse error"}`);
      return;
    }
    if (!Array.isArray(parsed)) {
      setClientError("JSON must be an array of post objects");
      return;
    }
    if (parsed.length === 0) {
      setClientError("Array is empty");
      return;
    }
    mutate.mutate({ competitorId, source: "json", json: parsed, strict });
  };

  const runCsv = () => {
    setClientError(null);
    if (!csv.trim()) {
      setClientError("Paste CSV content (or upload a file below)");
      return;
    }
    const firstLine = csv.split(/\r?\n/, 1)[0] ?? "";
    const headers = firstLine.split(",").map((h) => h.trim().toLowerCase());
    const required = ["platform", "posted_at"];
    const missing = required.filter((h) => !headers.includes(h));
    if (missing.length > 0) {
      setClientError(`CSV header missing required column(s): ${missing.join(", ")}`);
      return;
    }
    mutate.mutate({ competitorId, source: "csv", csv, strict });
  };

  const onCsvFile = async (file: File) => {
    if (file.size > 2_000_000) {
      setClientError("CSV file too large (max 2 MB)");
      return;
    }
    setCsv(await file.text());
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base">Ingest posts</CardTitle>
        <CardDescription>
          Fetch from X, or paste JSON/CSV. Rows validated per-field; DNA + campaign jobs auto-run.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        <Tabs defaultValue="x">
          <TabsList>
            <TabsTrigger value="x"><Download className="size-3.5" /> X</TabsTrigger>
            <TabsTrigger value="json"><FileJson className="size-3.5" /> JSON</TabsTrigger>
            <TabsTrigger value="csv"><FileSpreadsheet className="size-3.5" /> CSV</TabsTrigger>
          </TabsList>
          <TabsContent value="x" className="space-y-3">
            <div className="flex gap-2">
              <Input
                placeholder="@handle"
                value={handle}
                onChange={(e) => setHandle(e.target.value)}
                className="max-w-xs"
              />
              <Button onClick={runX} disabled={mutate.isPending}>
                {mutate.isPending ? "Fetching…" : "Fetch recent posts"}
              </Button>
            </div>
            <p className="text-xs text-muted-foreground">
              Requires the X connector to be linked. Pulls up to 100 recent tweets.
            </p>
          </TabsContent>
          <TabsContent value="json" className="space-y-3">
            <Textarea
              placeholder='[{"platform":"instagram","caption":"...","posted_at":"2026-06-01T12:00:00Z","likes":120,"comments":8,"shares":2,"views":3400,"hashtags":["launch"]}]'
              value={json}
              onChange={(e) => setJson(e.target.value)}
              rows={6}
              className="font-mono text-xs"
            />
            <Button onClick={runJson} disabled={mutate.isPending}>
              {mutate.isPending ? "Ingesting…" : "Ingest JSON"}
            </Button>
          </TabsContent>
          <TabsContent value="csv" className="space-y-3">
            <p className="text-xs text-muted-foreground">
              Header row required. Columns:{" "}
              <code className="rounded bg-muted px-1">platform,posted_at,caption,url,media_url,likes,comments,shares,views,hashtags,external_id</code>
              . Hashtags separated by <code className="rounded bg-muted px-1">|</code>.
            </p>
            <Textarea
              placeholder={`platform,posted_at,caption,likes,comments,shares,views,hashtags
instagram,2026-06-01T12:00:00Z,Launch day!,120,8,2,3400,launch|new`}
              value={csv}
              onChange={(e) => setCsv(e.target.value)}
              rows={6}
              className="font-mono text-xs"
            />
            <div className="flex items-center gap-2">
              <Input
                type="file"
                accept=".csv,text/csv"
                className="max-w-xs"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) void onCsvFile(f);
                }}
              />
              <Button onClick={runCsv} disabled={mutate.isPending}>
                {mutate.isPending ? "Ingesting…" : "Ingest CSV"}
              </Button>
            </div>
          </TabsContent>
        </Tabs>

        <label className="flex items-start gap-2 rounded-md border p-2.5 text-xs">
          <input
            type="checkbox"
            checked={strict}
            onChange={(e) => setStrict(e.target.checked)}
            className="mt-0.5 size-3.5 accent-primary"
          />
          <span>
            <span className="font-medium">Strict mode</span>
            <span className="text-muted-foreground">
              {" "}— reject the entire batch if any row fails validation. Turn off to ingest valid rows and skip malformed ones (audit-logged either way).
            </span>
          </span>
        </label>

        {clientError && (
          <div className="flex items-start gap-2 rounded-md border border-rose-500/30 bg-rose-500/5 p-2.5 text-xs">
            <AlertTriangle className="mt-0.5 size-3.5 shrink-0 text-rose-500" />
            <span className="text-rose-700 dark:text-rose-300">{clientError}</span>
          </div>
        )}

        {result && (
          <div className="rounded-md border p-2.5 text-xs">
            <div className="flex items-center gap-2 font-medium">
              {result.inserted > 0 ? (
                <CheckCircle2 className="size-3.5 text-emerald-500" />
              ) : (
                <AlertTriangle className="size-3.5 text-amber-500" />
              )}
              {result.message}
            </div>
            {result.invalidRows > 0 && (
              <details className="mt-2" open={result.inserted === 0}>
                <summary className="cursor-pointer text-muted-foreground">
                  {result.invalidRows} row(s) rejected — show line-level details
                </summary>
                <ul className="mt-1.5 max-h-60 space-y-2 overflow-auto pl-1">
                  {result.errors.map((e) => (
                    <li key={e.row} className="rounded border border-rose-500/20 bg-rose-500/5 p-1.5">
                      <div className="font-medium text-rose-700 dark:text-rose-300">
                        Row {e.row}
                      </div>
                      <ul className="ml-3 list-disc text-rose-600 dark:text-rose-400">
                        {e.issues.map((iss, idx) => (
                          <li key={idx}>{iss}</li>
                        ))}
                      </ul>
                      {e.preview && (
                        <pre className="mt-1 max-h-16 overflow-auto rounded bg-background/60 p-1 font-mono text-[10px] text-muted-foreground">
                          {e.preview}
                        </pre>
                      )}
                    </li>
                  ))}
                </ul>
              </details>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
