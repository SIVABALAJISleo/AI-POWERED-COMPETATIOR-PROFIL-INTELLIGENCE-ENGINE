import { useEffect, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import {
  listNotifications,
  markNotificationRead,
  markAllNotificationsRead,
} from "@/lib/notifications.functions";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Badge } from "@/components/ui/badge";
import { Bell, CheckCircle2, AlertTriangle, Circle } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { toast } from "sonner";

type Notification = {
  id: string;
  kind: string;
  title: string;
  body: string | null;
  target_type: string | null;
  target_id: string | null;
  metadata: Record<string, unknown>;
  read_at: string | null;
  created_at: string;
  org_id: string | null;
};

export function NotificationsBell() {
  const qc = useQueryClient();
  const listFn = useServerFn(listNotifications);
  const markFn = useServerFn(markNotificationRead);
  const markAllFn = useServerFn(markAllNotificationsRead);
  const [open, setOpen] = useState(false);

  const { data } = useQuery({
    queryKey: ["notifications"],
    queryFn: () => listFn({ data: { limit: 30, unreadOnly: false } }) as Promise<Notification[]>,
    refetchInterval: 30_000,
    refetchOnWindowFocus: true,
  });

  useEffect(() => {
    const invalidate = () => qc.invalidateQueries({ queryKey: ["notifications"] });
    const ch = supabase
      .channel("notifications-bell")
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "notifications" },
        (payload) => {
          const n = payload.new as Notification;
          if (n.kind === "export.complete") {
            toast.success(n.title, { description: n.body ?? undefined });
          } else if (n.kind === "export.failed") {
            toast.error(n.title, { description: n.body ?? undefined });
          } else {
            toast(n.title, { description: n.body ?? undefined });
          }
          invalidate();
        },
      )
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "notifications" },
        invalidate,
      )
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [qc]);

  const markMut = useMutation({
    mutationFn: (id: string) => markFn({ data: { id } }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["notifications"] }),
  });
  const markAllMut = useMutation({
    mutationFn: () => markAllFn({}),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["notifications"] }),
  });

  const rows = data ?? [];
  const unread = rows.filter((r) => !r.read_at).length;

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="icon" className="relative" aria-label="Notifications">
          <Bell className="size-4" />
          {unread > 0 && (
            <span className="absolute -right-0.5 -top-0.5 flex size-4 items-center justify-center rounded-full bg-rose-500 text-[10px] font-medium text-white">
              {unread > 9 ? "9+" : unread}
            </span>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent align="end" className="w-96 p-0">
        <div className="flex items-center justify-between border-b p-3">
          <div className="flex items-center gap-2">
            <span className="text-sm font-medium">Notifications</span>
            {unread > 0 && <Badge variant="secondary">{unread} new</Badge>}
          </div>
          {unread > 0 && (
            <Button
              size="sm"
              variant="ghost"
              onClick={() => markAllMut.mutate()}
              disabled={markAllMut.isPending}
            >
              Mark all read
            </Button>
          )}
        </div>
        <div className="max-h-96 overflow-y-auto">
          {rows.length === 0 && (
            <p className="p-6 text-center text-sm text-muted-foreground">Nothing yet.</p>
          )}
          {rows.map((n) => {
            const isUnread = !n.read_at;
            const Icon =
              n.kind === "export.complete"
                ? CheckCircle2
                : n.kind === "export.failed"
                ? AlertTriangle
                : Circle;
            const color =
              n.kind === "export.complete"
                ? "text-emerald-500"
                : n.kind === "export.failed"
                ? "text-rose-500"
                : "text-muted-foreground";
            return (
              <button
                key={n.id}
                onClick={() => {
                  if (isUnread) markMut.mutate(n.id);
                }}
                className={`flex w-full items-start gap-3 border-b p-3 text-left last:border-b-0 hover:bg-muted/50 ${
                  isUnread ? "bg-blue-500/5" : ""
                }`}
              >
                <Icon className={`mt-0.5 size-4 shrink-0 ${color}`} />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium">{n.title}</p>
                  {n.body && (
                    <p className="mt-0.5 line-clamp-2 text-xs text-muted-foreground">{n.body}</p>
                  )}
                  <p className="mt-1 text-[11px] text-muted-foreground">
                    {formatDistanceToNow(new Date(n.created_at), { addSuffix: true })}
                  </p>
                </div>
                {isUnread && (
                  <span className="mt-1.5 size-1.5 shrink-0 rounded-full bg-blue-500" aria-label="Unread" />
                )}
              </button>
            );
          })}
        </div>
      </PopoverContent>
    </Popover>
  );
}
