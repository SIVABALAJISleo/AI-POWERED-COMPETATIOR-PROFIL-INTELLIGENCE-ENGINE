import { useEffect, useMemo, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Link } from "@tanstack/react-router";
import {
  listExports,
  retryExport,
  getExportArtifact,
  bulkRetryExports,
  createExportShareLink,
} from "@/lib/exports.functions";
import { supabase } from "@/integrations/supabase/client";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Download,
  RefreshCw,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Loader2,
  Radio,
  WifiOff,
  FileText,
  FileArchive,
  FileSpreadsheet,
  Package,
  Filter,
  X,
  Archive,
  Lightbulb,
  Share2,
  Link2,
  ExternalLink,
} from "lucide-react";
import { ShareLinksDialog } from "@/components/spotnxt/share-links-dialog";
import { formatDistanceToNow } from "date-fns";
import { toast } from "sonner";

type ExportRow = {
  id: string;
  org_id: string;
  competitor_id: string | null;
  kind: string;
  status: string;
  format: string;
  filename: string | null;
  mime_type: string | null;
  params: Record<string, unknown>;
  size_bytes: number | null;
  row_count: number | null;
  progress: number;
  error: string | null;
  requested_by: string | null;
  created_at: string;
  updated_at: string;
  completed_at: string | null;
};

const STATUS_STYLE: Record<string, { icon: React.ReactNode; className: string; label: string }> = {
  pending: {
    icon: <Clock className="size-3" />,
    className: "bg-muted text-foreground",
    label: "queued",
  },
  running: {
    icon: <Loader2 className="size-3 animate-spin" />,
    className: "bg-blue-500/15 text-blue-700 dark:text-blue-300",
    label: "running",
  },
  done: {
    icon: <CheckCircle2 className="size-3" />,
    className: "bg-emerald-500/15 text-emerald-700 dark:text-emerald-400",
    label: "ready",
  },
  failed: {
    icon: <AlertTriangle className="size-3" />,
    className: "bg-rose-500/15 text-rose-700 dark:text-rose-400",
    label: "failed",
  },
  expired: {
    icon: <Archive className="size-3" />,
    className: "bg-amber-500/15 text-amber-700 dark:text-amber-400",
    label: "expired",
  },
};

const KIND_ICON: Record<string, React.ReactNode> = {
  csv: <FileSpreadsheet className="size-3.5" />,
  pdf: <FileText className="size-3.5" />,
  bulk_pdf: <Package className="size-3.5" />,
  zip: <FileArchive className="size-3.5" />,
};

const KIND_LABEL: Record<string, string> = {
  csv: "CSV",
  pdf: "PDF",
  bulk_pdf: "Bundle PDF",
  zip: "ZIP",
};

function humanBytes(n: number | null): string {
  if (!n) return "—";
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / 1024 / 1024).toFixed(1)} MB`;
}

function downloadBase64(base64: string, mime: string, filename: string) {
  const bin = atob(base64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  const url = URL.createObjectURL(new Blob([bytes], { type: mime }));
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

/** Human-friendly hint derived from a raw error message. Server-side notifications
 *  use the same mapping so email + inline UI stay consistent. */
function errorHint(msg: string | null): { title: string; hint: string } {
  const m = (msg ?? "").toLowerCase();
  if (!m) return { title: "Failed", hint: "Retry to try again." };
  if (m.includes("not ready") || m.includes("running"))
    return { title: "Not ready", hint: "Still processing — wait for it to finish." };
  if (m.includes("not found") || m.includes("missing"))
    return {
      title: "Missing data",
      hint: "The underlying recommendation was deleted. Regenerate recommendations, then retry.",
    };
  if (m.includes("permission") || m.includes("forbidden") || m.includes("rls"))
    return {
      title: "Permission denied",
      hint: "You don't have access. Ask a workspace admin, or sign in with the correct account.",
    };
  if (m.includes("timeout") || m.includes("timed out"))
    return {
      title: "Timed out",
      hint: "Batch too large — narrow the date range or export fewer items, then retry.",
    };
  if (m.includes("network") || m.includes("fetch"))
    return { title: "Network error", hint: "Transient upstream failure. Retry usually resolves it." };
  if (m.includes("belong to the same workspace"))
    return {
      title: "Cross-workspace selection",
      hint: "Only recommendations from a single workspace can be exported together.",
    };
  if (m.includes("purged"))
    return {
      title: "Artifact expired",
      hint: "Retention policy purged the file. Retry to regenerate.",
    };
  return { title: "Export failed", hint: "Retry, or contact support if the error persists." };
}

type FilterState = {
  kind: "all" | "csv" | "pdf" | "bulk_pdf" | "zip";
  status: "all" | "pending" | "running" | "done" | "failed" | "expired";
  from: string;
  to: string;
  search: string;
};

export function ExportsPanel({
  orgId,
  competitorId,
}: {
  orgId?: string;
  competitorId?: string;
}) {
  const qc = useQueryClient();
  const listFn = useServerFn(listExports);
  const retryFn = useServerFn(retryExport);
  const artifactFn = useServerFn(getExportArtifact);
  const bulkRetryFn = useServerFn(bulkRetryExports);
  const shareFn = useServerFn(createExportShareLink);
  const [connected, setConnected] = useState(true);
  const [downloadingId, setDownloadingId] = useState<string | null>(null);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [showFilters, setShowFilters] = useState(false);
  const [filters, setFilters] = useState<FilterState>({
    kind: "all",
    status: "all",
    from: "",
    to: "",
    search: "",
  });

  const activeFilterCount = useMemo(() => {
    let n = 0;
    if (filters.kind !== "all") n++;
    if (filters.status !== "all") n++;
    if (filters.from) n++;
    if (filters.to) n++;
    if (filters.search.trim()) n++;
    return n;
  }, [filters]);

  const queryKey = ["exports", orgId ?? "any", competitorId ?? "any", filters];
  const { data, refetch, isLoading } = useQuery({
    queryKey,
    queryFn: () =>
      listFn({
        data: {
          orgId,
          competitorId,
          kinds: filters.kind === "all" ? undefined : [filters.kind],
          statuses: filters.status === "all" ? undefined : [filters.status],
          from: filters.from ? new Date(filters.from).toISOString() : undefined,
          to: filters.to ? new Date(filters.to + "T23:59:59").toISOString() : undefined,
          search: filters.search.trim() || undefined,
          limit: 100,
        },
      }) as Promise<ExportRow[]>,
    refetchInterval: connected ? 15_000 : 3_000,
    refetchOnWindowFocus: true,
    refetchOnReconnect: true,
  });

  useEffect(() => {
    const invalidate = () => qc.invalidateQueries({ queryKey: ["exports"] });
    const channel = supabase
      .channel(`exports:${orgId ?? competitorId ?? "all"}`)
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "exports" },
        invalidate,
      )
      .subscribe((status) => {
        setConnected(status === "SUBSCRIBED");
        if (status === "SUBSCRIBED") invalidate();
      });
    const onVisible = () => {
      if (document.visibilityState === "visible") invalidate();
    };
    document.addEventListener("visibilitychange", onVisible);
    window.addEventListener("online", invalidate);
    return () => {
      supabase.removeChannel(channel);
      document.removeEventListener("visibilitychange", onVisible);
      window.removeEventListener("online", invalidate);
    };
  }, [orgId, competitorId, qc]);

  const retry = useMutation({
    mutationFn: (id: string) => retryFn({ data: { id } }),
    onSuccess: () => {
      toast.success("Export requeued with original parameters");
      qc.invalidateQueries({ queryKey: ["exports"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const onDownload = async (row: ExportRow) => {
    setDownloadingId(row.id);
    try {
      const res = await artifactFn({ data: { id: row.id } });
      downloadBase64(res.base64, res.mimeType, res.filename);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Download failed");
    } finally {
      setDownloadingId(null);
    }
  };

  const clearFilters = () =>
    setFilters({ kind: "all", status: "all", from: "", to: "", search: "" });

  const rows = data ?? [];

  const toggleSelect = (id: string) => {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const retryableSelected = rows.filter(
    (r) => selected.has(r.id) && (r.status === "failed" || r.status === "expired"),
  );

  const onBulkRetry = async () => {
    if (!retryableSelected.length) return;
    try {
      const res = await bulkRetryFn({ data: { ids: retryableSelected.map((r) => r.id) } });
      const ok = res.results.filter((r) => r.ok).length;
      const fail = res.results.length - ok;
      toast.success(`Requeued ${ok} export${ok === 1 ? "" : "s"}${fail ? ` · ${fail} failed` : ""}`);
      setSelected(new Set());
      qc.invalidateQueries({ queryKey: ["exports"] });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Bulk retry failed");
    }
  };

  const onShare = async (row: ExportRow) => {
    try {
      const res = await shareFn({ data: { exportId: row.id, ttlHours: 24 } });
      const url = `${window.location.origin}/api/public/share/exports/${res.token}`;
      try {
        await navigator.clipboard.writeText(url);
        toast.success("Share link copied — expires in 24h", { description: url });
      } catch {
        toast.success("Share link created", { description: url });
      }
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to create share link");
    }
  };


  return (
    <Card>
      <CardHeader className="flex flex-row items-start justify-between space-y-0">
        <div>
          <CardTitle className="flex items-center gap-2 text-base">
            Export history
            {connected ? (
              <Radio className="size-3.5 text-emerald-500" aria-label="Live" />
            ) : (
              <WifiOff className="size-3.5 text-amber-500" aria-label="Reconnecting" />
            )}
            <Badge variant="secondary">{rows.length}</Badge>
          </CardTitle>
          <CardDescription>
            {connected
              ? "Streaming CSV/PDF/ZIP export progress. Downloads and retries are RBAC-scoped."
              : "Realtime dropped — polling for updates."}
          </CardDescription>
        </div>
        <div className="flex gap-2">
          {retryableSelected.length > 0 && (
            <Button size="sm" variant="outline" onClick={onBulkRetry}>
              <RefreshCw className="size-3.5" />
              Retry {retryableSelected.length}
            </Button>
          )}
          <Button
            size="sm"
            variant={activeFilterCount > 0 ? "default" : "outline"}
            onClick={() => setShowFilters((s) => !s)}
          >
            <Filter className="size-3.5" />
            Filters
            {activeFilterCount > 0 && (
              <Badge variant="secondary" className="ml-1 h-4 px-1 text-[10px]">
                {activeFilterCount}
              </Badge>
            )}
          </Button>
          <Button size="sm" variant="outline" onClick={() => refetch()} disabled={isLoading}>
            <RefreshCw className={`size-3.5 ${isLoading ? "animate-spin" : ""}`} />
          </Button>
        </div>
      </CardHeader>
      {showFilters && (
        <div className="mx-6 mb-3 grid grid-cols-1 gap-3 rounded-md border bg-muted/30 p-3 md:grid-cols-5">
          <div className="grid gap-1">
            <Label className="text-[11px] text-muted-foreground">Type</Label>
            <Select
              value={filters.kind}
              onValueChange={(v) => setFilters((f) => ({ ...f, kind: v as FilterState["kind"] }))}
            >
              <SelectTrigger className="h-8"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All types</SelectItem>
                <SelectItem value="csv">CSV</SelectItem>
                <SelectItem value="pdf">PDF</SelectItem>
                <SelectItem value="bulk_pdf">Bundle PDF</SelectItem>
                <SelectItem value="zip">ZIP</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="grid gap-1">
            <Label className="text-[11px] text-muted-foreground">Status</Label>
            <Select
              value={filters.status}
              onValueChange={(v) => setFilters((f) => ({ ...f, status: v as FilterState["status"] }))}
            >
              <SelectTrigger className="h-8"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All statuses</SelectItem>
                <SelectItem value="pending">Queued</SelectItem>
                <SelectItem value="running">Running</SelectItem>
                <SelectItem value="done">Ready</SelectItem>
                <SelectItem value="failed">Failed</SelectItem>
                <SelectItem value="expired">Expired</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="grid gap-1">
            <Label className="text-[11px] text-muted-foreground">From</Label>
            <Input
              type="date"
              className="h-8"
              value={filters.from}
              onChange={(e) => setFilters((f) => ({ ...f, from: e.target.value }))}
            />
          </div>
          <div className="grid gap-1">
            <Label className="text-[11px] text-muted-foreground">To</Label>
            <Input
              type="date"
              className="h-8"
              value={filters.to}
              onChange={(e) => setFilters((f) => ({ ...f, to: e.target.value }))}
            />
          </div>
          <div className="grid gap-1">
            <Label className="text-[11px] text-muted-foreground">Filename contains</Label>
            <div className="flex gap-1">
              <Input
                className="h-8"
                placeholder="e.g. evidence-2026"
                value={filters.search}
                onChange={(e) => setFilters((f) => ({ ...f, search: e.target.value }))}
              />
              {activeFilterCount > 0 && (
                <Button variant="ghost" size="icon" className="size-8" onClick={clearFilters}>
                  <X className="size-3.5" />
                </Button>
              )}
            </div>
          </div>
        </div>
      )}
      <CardContent className="space-y-2">
        {rows.length === 0 && (
          <p className="rounded-md border border-dashed p-4 text-center text-sm text-muted-foreground">
            {activeFilterCount > 0
              ? "No exports match those filters."
              : "No exports yet. Trigger a CSV, PDF, or bundle to see it stream here."}
          </p>
        )}
        {rows.map((r) => {
          const style = STATUS_STYLE[r.status] ?? STATUS_STYLE.pending;
          const recIds =
            (r.params as { recommendation_ids?: string[] } | null)?.recommendation_ids ?? [];
          const tmpl =
            (r.params as { template?: { id: string | null; version: number | null } | null } | null)
              ?.template ?? null;
          const isActive = r.status === "pending" || r.status === "running";
          const hint = r.status === "failed" ? errorHint(r.error) : null;
          const isExpired = r.status === "expired";
          return (
            <div
              key={r.id}
              className="flex flex-wrap items-start gap-3 rounded-md border p-2.5 text-sm"
            >
              <div className="pt-1">
                <Checkbox
                  checked={selected.has(r.id)}
                  onCheckedChange={() => toggleSelect(r.id)}
                  aria-label="Select export"
                />
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  <Badge className={`gap-1 ${style.className}`} variant="outline">
                    {style.icon}
                    {style.label}
                  </Badge>
                  <span className="inline-flex items-center gap-1 font-medium">
                    {KIND_ICON[r.kind]}
                    {KIND_LABEL[r.kind] ?? r.kind}
                  </span>
                  {recIds.length > 0 && (
                    <span className="text-xs text-muted-foreground">
                      {recIds.length} rec{recIds.length === 1 ? "" : "s"}
                    </span>
                  )}
                  {r.row_count != null && r.status === "done" && (
                    <span className="text-xs text-muted-foreground">
                      · {r.row_count} row{r.row_count === 1 ? "" : "s"}
                    </span>
                  )}
                  {r.size_bytes != null && r.status === "done" && (
                    <span className="text-xs text-muted-foreground">· {humanBytes(r.size_bytes)}</span>
                  )}
                  {tmpl && (tmpl.id || tmpl.version != null) && (
                    <a
                      href={tmpl.id ? `#template=${tmpl.id}${tmpl.version != null ? `&version=${tmpl.version}` : ""}` : undefined}
                      title={
                        tmpl.id
                          ? `Locked template ${tmpl.id} · v${tmpl.version ?? "?"} — open in template builder`
                          : `Inline template config${tmpl.version != null ? ` v${tmpl.version}` : ""}`
                      }
                      className={tmpl.id ? "no-underline" : "pointer-events-none"}
                    >
                      <Badge
                        variant="outline"
                        className="gap-1 font-mono text-[10px] hover:bg-muted"
                      >
                        tmpl{tmpl.version != null ? ` v${tmpl.version}` : ""}
                        {tmpl.id ? `· ${tmpl.id.slice(0, 8)}` : " · inline"}
                      </Badge>
                    </a>
                  )}
                </div>
                {r.filename && (
                  <p className="mt-0.5 truncate font-mono text-[11px] text-muted-foreground">
                    {r.filename}
                  </p>
                )}
                {hint && (
                  <div className="mt-1.5 rounded border border-rose-500/30 bg-rose-500/5 p-2 text-xs">
                    <div className="flex items-start gap-1.5">
                      <AlertTriangle className="mt-0.5 size-3 shrink-0 text-rose-500" />
                      <div className="min-w-0">
                        <p className="font-medium text-rose-700 dark:text-rose-400">
                          {hint.title}
                        </p>
                        <p className="mt-0.5 flex items-start gap-1 text-muted-foreground">
                          <Lightbulb className="mt-0.5 size-3 shrink-0" />
                          <span>{hint.hint}</span>
                        </p>
                        {r.error && (
                          <details className="mt-1">
                            <summary className="cursor-pointer text-[10px] text-muted-foreground">
                              Technical details
                            </summary>
                            <p className="mt-0.5 break-all font-mono text-[10px] text-muted-foreground">
                              {r.error}
                            </p>
                          </details>
                        )}
                      </div>
                    </div>
                  </div>
                )}
                {isExpired && (
                  <p className="mt-1 flex items-center gap-1 text-xs text-amber-600 dark:text-amber-400">
                    <Archive className="size-3" />
                    Artifact was purged by the retention policy. Retry to regenerate.
                  </p>
                )}
                <p className="mt-0.5 text-xs text-muted-foreground">
                  {formatDistanceToNow(new Date(r.updated_at), { addSuffix: true })}
                </p>
                {isActive && <Progress value={r.progress ?? 0} className="mt-2 h-1.5" />}
              </div>
              <div className="flex flex-wrap gap-2">
                <Link
                  to="/dashboard"
                  search={{ auditExportId: r.id } as never}
                  className="inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground"
                  title="Jump to audit trail for this export"
                >
                  <ExternalLink className="size-3" />
                  Audit
                </Link>
                {r.status === "done" && (
                  <>
                    <Button
                      size="sm"
                      onClick={() => onDownload(r)}
                      disabled={downloadingId === r.id}
                    >
                      <Download className="size-3.5" />
                      {downloadingId === r.id ? "…" : "Download"}
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => onShare(r)}
                      title="Create a 24h expiring share link"
                    >
                      <Share2 className="size-3.5" />
                      Share
                    </Button>
                    <ShareLinksDialog
                      exportId={r.id}
                      trigger={
                        <Button size="sm" variant="ghost" title="Manage share links">
                          <Link2 className="size-3.5" /> Links
                        </Button>
                      }
                    />
                  </>
                )}
                {(r.status === "failed" || r.status === "expired") && (
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => retry.mutate(r.id)}
                    disabled={retry.isPending}
                    title="Requeue with the same recommendations and filters"
                  >
                    <RefreshCw className="size-3.5" />
                    Retry
                  </Button>
                )}
              </div>
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
}
