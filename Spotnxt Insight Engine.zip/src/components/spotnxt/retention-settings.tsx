import { useEffect, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { getRetentionSettings, setRetentionSettings } from "@/lib/exports.functions";
import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Clock, Save, Lock } from "lucide-react";
import { toast } from "sonner";

export function RetentionSettings({ orgId }: { orgId: string }) {
  const qc = useQueryClient();
  const getFn = useServerFn(getRetentionSettings);
  const setFn = useServerFn(setRetentionSettings);
  const key = ["retention", orgId];

  const { data } = useQuery({
    queryKey: key,
    queryFn: () =>
      getFn({ data: { orgId } }) as Promise<{
        orgId: string;
        retentionDays: number;
        canEdit: boolean;
        role: string;
      }>,
  });

  const [days, setDays] = useState<string>("");
  useEffect(() => {
    if (data) setDays(String(data.retentionDays));
  }, [data]);

  const save = useMutation({
    mutationFn: () => {
      const n = parseInt(days, 10);
      if (!Number.isInteger(n) || n < 1 || n > 365) {
        throw new Error("Retention must be between 1 and 365 days");
      }
      return setFn({ data: { orgId, retentionDays: n } });
    },
    onSuccess: () => {
      toast.success("Retention updated — older artifacts will be purged");
      qc.invalidateQueries({ queryKey: key });
      qc.invalidateQueries({ queryKey: ["exports"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  if (!data) return null;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-base">
          <Clock className="size-4" />
          Export retention
        </CardTitle>
        <CardDescription>
          Artifacts (CSV / PDF / ZIP) are purged automatically after this many days. The export
          history row stays; only the downloadable file is cleared. Retry regenerates it.
        </CardDescription>
      </CardHeader>
      <CardContent className="flex flex-wrap items-end gap-3">
        <div className="grid gap-1.5">
          <Label htmlFor="retention-days">Retention (days)</Label>
          <Input
            id="retention-days"
            type="number"
            min={1}
            max={365}
            value={days}
            onChange={(e) => setDays(e.target.value)}
            disabled={!data.canEdit}
            className="w-32"
          />
        </div>
        <Button
          onClick={() => save.mutate()}
          disabled={!data.canEdit || save.isPending || days === String(data.retentionDays)}
        >
          <Save className="size-3.5" />
          Save
        </Button>
        {!data.canEdit && (
          <p className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <Lock className="size-3" />
            Only owners and admins can edit retention (you are {data.role}).
          </p>
        )}
      </CardContent>
    </Card>
  );
}
