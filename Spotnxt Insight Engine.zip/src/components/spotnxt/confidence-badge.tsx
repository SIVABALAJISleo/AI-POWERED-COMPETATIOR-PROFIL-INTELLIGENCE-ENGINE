import { cn } from "@/lib/utils";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

type Props = {
  completeness: number; // 0-100
  platform?: string;
  reason?: string | null;
  className?: string;
  size?: "sm" | "md";
};

export function ConfidenceBadge({ completeness, platform, reason, className, size = "sm" }: Props) {
  const level = completeness >= 75 ? "high" : completeness >= 45 ? "medium" : "low";
  const styles: Record<string, string> = {
    high: "bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 border-emerald-500/30",
    medium: "bg-amber-500/15 text-amber-700 dark:text-amber-400 border-amber-500/30",
    low: "bg-rose-500/15 text-rose-700 dark:text-rose-400 border-rose-500/30",
  };
  const label = level === "high" ? "High" : level === "medium" ? "Partial" : "Limited";
  return (
    <TooltipProvider delayDuration={100}>
      <Tooltip>
        <TooltipTrigger asChild>
          <span
            className={cn(
              "inline-flex items-center gap-1.5 rounded-full border font-medium tabular-nums",
              size === "sm" ? "px-2 py-0.5 text-xs" : "px-2.5 py-1 text-sm",
              styles[level],
              className,
            )}
          >
            <span className="size-1.5 rounded-full bg-current opacity-70" />
            {platform ? `${platform} ` : ""}
            {label} · {Math.round(completeness)}%
          </span>
        </TooltipTrigger>
        <TooltipContent side="top" className="max-w-xs">
          <p className="font-semibold mb-1">Data confidence: {label}</p>
          <p className="text-xs opacity-90">
            {reason ??
              "Data completeness reflects what we've been able to observe on this platform for this competitor since tracking began."}
          </p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}
