/**
 * Template builder: pick CSV columns and PDF sections with a live preview.
 * Persists via listExportTemplates / upsertExportTemplate / deleteExportTemplate.
 * Preview uses previewExportTemplate against synthetic evidence rows so it
 * works without a selected recommendation.
 */
import { useEffect, useMemo, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import {
  listExportTemplates,
  upsertExportTemplate,
  deleteExportTemplate,
  previewExportTemplate,
  listExportTemplateVersions,
  rollbackExportTemplate,
} from "@/lib/exports.functions";
import { CSV_COLUMNS, type CsvColumn, type PdfTemplateConfig } from "@/lib/export-helpers";
import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Switch } from "@/components/ui/switch";
import {
  Tabs,
  TabsList,
  TabsTrigger,
  TabsContent,
} from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Save, Trash2, Plus, FileSpreadsheet, FileText, Eye, Star, History, RotateCcw, ChevronDown, ChevronRight, User, Link2 } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { toast } from "sonner";

type Template = {
  id: string;
  org_id: string;
  name: string;
  kind: "csv" | "pdf";
  config: { csv?: { columns?: CsvColumn[] }; pdf?: PdfTemplateConfig };
  is_default: boolean;
  created_at: string;
  updated_at: string;
};

const PDF_SECTIONS: Array<{ key: keyof NonNullable<PdfTemplateConfig["sections"]>; label: string; hint: string }> = [
  { key: "summary", label: "Summary", hint: "Recommendation title, priority, generated-at" },
  { key: "metrics", label: "Metrics", hint: "Engagement rate, likes, comments, shares, views" },
  { key: "thumbnails", label: "Thumbnails", hint: "Media references for each evidence post" },
  { key: "evidenceTable", label: "Evidence table", hint: "One row per evidence link" },
  { key: "snippets", label: "Snippets", hint: "Inline snippets attached to evidence" },
];

type TemplateVersion = {
  id: string;
  template_id: string;
  version: number;
  name: string;
  kind: "csv" | "pdf";
  config: { csv?: { columns?: CsvColumn[] }; pdf?: PdfTemplateConfig };
  is_default: boolean;
  change_type: "create" | "update" | "rollback";
  changed_by: string | null;
  diff: Record<string, { from: unknown; to: unknown }> | Record<string, unknown> | null;
  changed_by_name: string | null;
  created_at: string;
};

export function TemplateBuilder({ orgId }: { orgId: string }) {
  const qc = useQueryClient();
  const listFn = useServerFn(listExportTemplates);
  const upsertFn = useServerFn(upsertExportTemplate);
  const deleteFn = useServerFn(deleteExportTemplate);
  const previewFn = useServerFn(previewExportTemplate);
  const listVersionsFn = useServerFn(listExportTemplateVersions);
  const rollbackFn = useServerFn(rollbackExportTemplate);

  const { data: templates } = useQuery({
    queryKey: ["export-templates", orgId],
    queryFn: () => listFn({ data: { orgId } }) as Promise<Template[]>,
  });

  const [tab, setTab] = useState<"csv" | "pdf">("csv");
  const [name, setName] = useState("Untitled template");
  const [isDefault, setIsDefault] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [openVersionId, setOpenVersionId] = useState<string | null>(null);
  // Deep link targets parsed from `#template=<id>&version=<n>`. When the
  // templates list arrives (or when the hash changes later), we auto-load the
  // matching template and expand the requested version's diff.
  const [pendingHash, setPendingHash] = useState<{ templateId: string; version?: number } | null>(null);
  const [csvCols, setCsvCols] = useState<CsvColumn[]>([...CSV_COLUMNS]);
  const [pdfSections, setPdfSections] = useState<Required<NonNullable<PdfTemplateConfig["sections"]>>>({
    summary: true,
    metrics: true,
    thumbnails: true,
    evidenceTable: true,
    snippets: true,
  });
  const [pdfOrientation, setPdfOrientation] = useState<"portrait" | "landscape">("portrait");
  const [preview, setPreview] = useState<{ csv?: string; sections?: Record<string, boolean>; orientation?: string; sampleRows?: Array<Record<string, unknown>> } | null>(null);

  const config = useMemo(
    () =>
      tab === "csv"
        ? { csv: { columns: csvCols } }
        : { pdf: { sections: pdfSections, orientation: pdfOrientation } },
    [tab, csvCols, pdfSections, pdfOrientation],
  );

  // Live preview (debounced)
  useEffect(() => {
    const t = setTimeout(async () => {
      try {
        const res = await previewFn({ data: { kind: tab, config } });
        setPreview(res as typeof preview);
      } catch {
        /* preview is best-effort */
      }
    }, 250);
    return () => clearTimeout(t);
  }, [tab, config, previewFn]);

  // Parse hash on mount + whenever it changes so links from exports panel or
  // shared incident URLs open the exact template + version diff.
  useEffect(() => {
    const apply = () => {
      const raw = window.location.hash.startsWith("#")
        ? window.location.hash.slice(1)
        : window.location.hash;
      const params = new URLSearchParams(raw);
      const templateId = params.get("template");
      if (!templateId) return;
      const versionRaw = params.get("version");
      const version = versionRaw ? Number(versionRaw) : undefined;
      setPendingHash({ templateId, version: Number.isFinite(version) ? version : undefined });
    };
    apply();
    window.addEventListener("hashchange", apply);
    return () => window.removeEventListener("hashchange", apply);
  }, []);

  const resetForm = () => {
    setEditingId(null);
    setName("Untitled template");
    setIsDefault(false);
    setCsvCols([...CSV_COLUMNS]);
    setPdfSections({ summary: true, metrics: true, thumbnails: true, evidenceTable: true, snippets: true });
    setPdfOrientation("portrait");
  };

  const loadTemplate = (t: Template) => {
    setEditingId(t.id);
    setName(t.name);
    setIsDefault(!!t.is_default);
    setTab(t.kind);
    if (t.kind === "csv") {
      const cols = (t.config?.csv?.columns ?? []) as CsvColumn[];
      setCsvCols(cols.length ? cols : [...CSV_COLUMNS]);
    } else {
      const s = t.config?.pdf?.sections ?? {};
      setPdfSections({
        summary: s.summary ?? true,
        metrics: s.metrics ?? true,
        thumbnails: s.thumbnails ?? true,
        evidenceTable: s.evidenceTable ?? true,
        snippets: s.snippets ?? true,
      });
      setPdfOrientation(t.config?.pdf?.orientation ?? "portrait");
    }
  };

  const save = useMutation({
    mutationFn: () =>
      upsertFn({
        data: {
          id: editingId ?? undefined,
          orgId,
          name: name.trim() || "Untitled template",
          kind: tab,
          isDefault,
          config,
        },
      }),
    onSuccess: () => {
      toast.success(editingId ? "Template updated" : "Template saved");
      qc.invalidateQueries({ queryKey: ["export-templates", orgId] });
      if (editingId) qc.invalidateQueries({ queryKey: ["export-template-versions", editingId] });
      resetForm();
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const { data: versions } = useQuery({
    queryKey: ["export-template-versions", editingId],
    queryFn: () =>
      listVersionsFn({ data: { templateId: editingId! } }) as Promise<TemplateVersion[]>,
    enabled: !!editingId,
  });

  // Load the template referenced by the deep-link hash once the list arrives.
  useEffect(() => {
    if (!pendingHash || !templates) return;
    const t = templates.find((x) => x.id === pendingHash.templateId);
    if (t && editingId !== t.id) loadTemplate(t);
  }, [pendingHash, templates, editingId]);

  // Expand the pinned version's diff once its version list has loaded, then
  // clear the pending hash so future navigation isn't fought by re-runs.
  useEffect(() => {
    if (!pendingHash || pendingHash.version == null || !versions || editingId !== pendingHash.templateId) return;
    const v = versions.find((x) => x.version === pendingHash.version);
    if (v) {
      setOpenVersionId(v.id);
      setPendingHash(null);
      // Bring the timeline into view — the panel is well below the fold.
      requestAnimationFrame(() => {
        document.getElementById(`tmpl-version-${v.id}`)?.scrollIntoView({ behavior: "smooth", block: "center" });
      });
    }
  }, [pendingHash, versions, editingId]);

  const versionLink = (v: TemplateVersion) =>
    `${window.location.pathname}${window.location.search}#template=${v.template_id}&version=${v.version}`;
  const copyVersionLink = async (v: TemplateVersion) => {
    const href = `${window.location.origin}${versionLink(v)}`;
    try {
      await navigator.clipboard.writeText(href);
      toast.success(`Copied link to v${v.version}`);
    } catch {
      toast.error("Copy failed");
    }
    // Also update the URL bar so refresh reopens the same diff.
    window.history.replaceState(null, "", versionLink(v));
  };

  const rollback = useMutation({
    mutationFn: (version: number) =>
      rollbackFn({ data: { templateId: editingId!, version } }),
    onSuccess: () => {
      toast.success("Template rolled back");
      qc.invalidateQueries({ queryKey: ["export-templates", orgId] });
      qc.invalidateQueries({ queryKey: ["export-template-versions", editingId] });
      // Reload editor state from the refreshed template
      if (editingId) {
        listFn({ data: { orgId } }).then((rows) => {
          const t = (rows as Template[]).find((x) => x.id === editingId);
          if (t) loadTemplate(t);
        });
      }
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const del = useMutation({
    mutationFn: (id: string) => deleteFn({ data: { id } }),
    onSuccess: () => {
      toast.success("Template deleted");
      qc.invalidateQueries({ queryKey: ["export-templates", orgId] });
      resetForm();
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const toggleCol = (c: CsvColumn) => {
    setCsvCols((prev) => (prev.includes(c) ? prev.filter((x) => x !== c) : [...prev, c]));
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-base">
          <FileSpreadsheet className="size-4" /> Export templates
        </CardTitle>
        <CardDescription>
          Choose CSV columns and PDF sections. Set one template per kind as the workspace default; new
          exports use it automatically.
        </CardDescription>
      </CardHeader>
      <CardContent className="grid gap-4 md:grid-cols-[240px_1fr]">
        {/* Saved templates */}
        <div className="grid gap-2">
          <div className="flex items-center justify-between">
            <Label className="text-xs uppercase text-muted-foreground">Saved</Label>
            <Button variant="ghost" size="sm" onClick={resetForm}>
              <Plus className="size-3.5" /> New
            </Button>
          </div>
          <div className="grid gap-1">
            {(templates ?? []).map((t) => (
              <button
                key={t.id}
                onClick={() => loadTemplate(t)}
                className={`flex items-start gap-2 rounded-md border p-2 text-left text-xs transition hover:bg-muted/40 ${
                  editingId === t.id ? "border-primary bg-primary/5" : ""
                }`}
              >
                {t.kind === "csv" ? <FileSpreadsheet className="mt-0.5 size-3.5" /> : <FileText className="mt-0.5 size-3.5" />}
                <span className="min-w-0 flex-1">
                  <span className="flex items-center gap-1 font-medium">
                    {t.name}
                    {t.is_default && <Star className="size-3 fill-amber-400 text-amber-400" />}
                  </span>
                  <span className="text-[10px] uppercase text-muted-foreground">{t.kind}</span>
                </span>
              </button>
            ))}
            {(!templates || templates.length === 0) && (
              <p className="rounded-md border border-dashed p-3 text-center text-xs text-muted-foreground">
                No templates yet.
              </p>
            )}
          </div>
        </div>

        {/* Editor + preview */}
        <div className="grid gap-3">
          <div className="grid gap-2 md:grid-cols-[1fr_auto_auto]">
            <div className="grid gap-1">
              <Label className="text-xs">Name</Label>
              <Input value={name} onChange={(e) => setName(e.target.value)} />
            </div>
            <div className="grid gap-1">
              <Label className="text-xs">Default</Label>
              <div className="flex h-9 items-center">
                <Switch checked={isDefault} onCheckedChange={setIsDefault} />
              </div>
            </div>
            <div className="grid gap-1">
              <Label className="text-xs">&nbsp;</Label>
              <div className="flex gap-1">
                <Button onClick={() => save.mutate()} disabled={save.isPending}>
                  <Save className="size-3.5" /> {editingId ? "Update" : "Save"}
                </Button>
                {editingId && (
                  <Button variant="outline" onClick={() => del.mutate(editingId)} disabled={del.isPending}>
                    <Trash2 className="size-3.5" />
                  </Button>
                )}
              </div>
            </div>
          </div>

          <Tabs value={tab} onValueChange={(v) => setTab(v as "csv" | "pdf")}>
            <TabsList>
              <TabsTrigger value="csv"><FileSpreadsheet className="mr-1 size-3.5" />CSV columns</TabsTrigger>
              <TabsTrigger value="pdf"><FileText className="mr-1 size-3.5" />PDF sections</TabsTrigger>
            </TabsList>

            <TabsContent value="csv" className="grid gap-3">
              <div className="grid grid-cols-2 gap-1.5 rounded-md border p-3 md:grid-cols-3">
                {CSV_COLUMNS.map((c) => (
                  <label key={c} className="flex cursor-pointer items-center gap-2 text-xs">
                    <Checkbox checked={csvCols.includes(c)} onCheckedChange={() => toggleCol(c)} />
                    <span className="font-mono">{c}</span>
                  </label>
                ))}
              </div>
              <div>
                <Label className="mb-1 flex items-center gap-1 text-xs text-muted-foreground">
                  <Eye className="size-3" /> Live preview
                </Label>
                <div className="max-h-56 overflow-auto rounded-md border bg-muted/30 p-2 font-mono text-[10px] leading-relaxed">
                  <pre className="whitespace-pre">{preview?.csv ?? "—"}</pre>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="pdf" className="grid gap-3">
              <div className="grid gap-2 rounded-md border p-3">
                {PDF_SECTIONS.map((s) => (
                  <label key={s.key} className="flex cursor-pointer items-start gap-2 text-sm">
                    <Checkbox
                      checked={pdfSections[s.key]}
                      onCheckedChange={(v) =>
                        setPdfSections((prev) => ({ ...prev, [s.key]: !!v }))
                      }
                    />
                    <span className="min-w-0">
                      <span className="font-medium">{s.label}</span>
                      <span className="ml-1 text-xs text-muted-foreground">— {s.hint}</span>
                    </span>
                  </label>
                ))}
                <div className="grid grid-cols-[auto_1fr] items-center gap-2 pt-2">
                  <Label className="text-xs">Orientation</Label>
                  <Select value={pdfOrientation} onValueChange={(v) => setPdfOrientation(v as "portrait" | "landscape")}>
                    <SelectTrigger className="h-8 w-40"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="portrait">Portrait</SelectItem>
                      <SelectItem value="landscape">Landscape</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div>
                <Label className="mb-1 flex items-center gap-1 text-xs text-muted-foreground">
                  <Eye className="size-3" /> Sections in output
                </Label>
                <div className="flex flex-wrap gap-1.5 rounded-md border bg-muted/30 p-3 text-xs">
                  {PDF_SECTIONS.map((s) => (
                    <Badge key={s.key} variant={pdfSections[s.key] ? "default" : "outline"}>
                      {pdfSections[s.key] ? "✓" : "×"} {s.label}
                    </Badge>
                  ))}
                  <Badge variant="secondary">{pdfOrientation}</Badge>
                </div>
              </div>
            </TabsContent>
          </Tabs>

          {editingId && (
            <div className="grid gap-2 rounded-md border p-3">
              <Label className="flex items-center gap-1 text-xs text-muted-foreground">
                <History className="size-3" /> Version history
              </Label>
              {(!versions || versions.length === 0) ? (
                <p className="text-xs text-muted-foreground">No versions recorded yet.</p>
              ) : (
                <div className="grid max-h-56 gap-1 overflow-auto">
                  {versions.map((v) => {
                    const diffEntries = v.diff
                      ? (Object.entries(v.diff) as Array<[string, unknown]>)
                      : [];
                    const isFieldDiff = (val: unknown): val is { from: unknown; to: unknown } =>
                      !!val && typeof val === "object" && "from" in (val as object) && "to" in (val as object);
                    const expanded = openVersionId === v.id;
                    return (
                      <div
                        key={v.id}
                        id={`tmpl-version-${v.id}`}
                        className={`rounded-md border text-xs ${
                          pendingHash?.templateId === v.template_id && pendingHash?.version === v.version
                            ? "ring-2 ring-primary"
                            : ""
                        }`}
                      >
                        <div className="grid grid-cols-[auto_1fr_auto_auto_auto] items-start gap-2 p-2">
                          <Badge
                            variant={
                              v.change_type === "create"
                                ? "default"
                                : v.change_type === "rollback"
                                  ? "secondary"
                                  : "outline"
                            }
                          >
                            v{v.version}
                          </Badge>
                          <div className="min-w-0">
                            <div className="flex flex-wrap items-center gap-1">
                              <span className="font-medium">{v.change_type}</span>
                              <span className="text-muted-foreground">
                                · {formatDistanceToNow(new Date(v.created_at), { addSuffix: true })}
                              </span>
                              {v.is_default && <Star className="size-3 fill-amber-400 text-amber-400" />}
                            </div>
                            <div className="mt-0.5 flex flex-wrap items-center gap-2 text-[10px] text-muted-foreground">
                              <span className="inline-flex items-center gap-1">
                                <User className="size-3" />
                                {v.changed_by_name ?? "system"}
                              </span>
                              <span title={new Date(v.created_at).toISOString()}>
                                {new Date(v.created_at).toLocaleString()}
                              </span>
                              {diffEntries.length > 0 && (
                                <span>· {diffEntries.length} field{diffEntries.length === 1 ? "" : "s"} changed</span>
                              )}
                            </div>
                            {diffEntries.length > 0 && (
                              <div className="mt-1 flex flex-wrap gap-1 text-[10px] text-muted-foreground">
                                {diffEntries.map(([k]) => (
                                  <span key={k} className="rounded bg-muted px-1 font-mono">
                                    {k}
                                  </span>
                                ))}
                              </div>
                            )}
                          </div>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => setOpenVersionId(expanded ? null : v.id)}
                            title={expanded ? "Hide diff" : "Show field-level diff"}
                            disabled={diffEntries.length === 0}
                          >
                            {expanded ? <ChevronDown className="size-3.5" /> : <ChevronRight className="size-3.5" />}
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => {
                              setOpenVersionId(v.id);
                              void copyVersionLink(v);
                            }}
                            title="Copy a deep link to this version's diff"
                          >
                            <Link2 className="size-3.5" />
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            disabled={rollback.isPending}
                            onClick={() => rollback.mutate(v.version)}
                            title="Restore this version as the current template"
                          >
                            <RotateCcw className="size-3.5" /> Rollback
                          </Button>
                        </div>
                        {expanded && diffEntries.length > 0 && (
                          <div className="grid gap-1.5 border-t bg-muted/30 p-2">
                            {diffEntries.map(([field, val]) => {
                              const from = isFieldDiff(val) ? val.from : undefined;
                              const to = isFieldDiff(val) ? val.to : val;
                              return (
                                <div key={field} className="grid gap-1">
                                  <div className="font-mono text-[10px] uppercase text-muted-foreground">{field}</div>
                                  <div className="grid gap-1 sm:grid-cols-2">
                                    <div>
                                      <div className="mb-0.5 text-[10px] text-muted-foreground">before</div>
                                      <pre className="max-h-32 overflow-auto rounded border border-destructive/30 bg-background p-1.5 font-mono text-[10px] leading-relaxed">
                                        {from === undefined ? "(none)" : JSON.stringify(from, null, 2)}
                                      </pre>
                                    </div>
                                    <div>
                                      <div className="mb-0.5 text-[10px] text-muted-foreground">after</div>
                                      <pre className="max-h-32 overflow-auto rounded border border-emerald-500/30 bg-background p-1.5 font-mono text-[10px] leading-relaxed">
                                        {to === undefined ? "(none)" : JSON.stringify(to, null, 2)}
                                      </pre>
                                    </div>
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
