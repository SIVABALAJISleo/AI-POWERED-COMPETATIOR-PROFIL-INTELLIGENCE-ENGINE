import { useQuery } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { getEvidenceDetail } from "@/lib/analytics.functions";
import { PLATFORM_LABEL } from "@/lib/platforms";
import { Skeleton } from "@/components/ui/skeleton";
import { ExternalLink } from "lucide-react";

export type EvidenceRef = {
  id: string;
  source_type: string;
  source_id: string | null;
  snippet: string | null;
} | null;

export function EvidenceModal({
  evidence,
  onOpenChange,
}: {
  evidence: EvidenceRef;
  onOpenChange: (o: boolean) => void;
}) {
  const open = !!evidence;
  const { data, isLoading } = useQuery({
    enabled: open && !!evidence?.source_id,
    queryKey: ["evidence", evidence?.id],
    queryFn: () =>
      getEvidenceDetail({
        data: {
          sourceType: evidence!.source_type,
          sourceId: evidence!.source_id!,
        },
      }),
  });

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            {evidence?.source_type === "post" ? "📄 Underlying post" : "📈 Metric breakdown"}
          </DialogTitle>
          <DialogDescription>
            {evidence?.snippet ?? "The data point supporting this recommendation."}
          </DialogDescription>
        </DialogHeader>

        {isLoading && (
          <div className="space-y-2">
            <Skeleton className="h-40 w-full" />
            <Skeleton className="h-4 w-2/3" />
            <Skeleton className="h-4 w-1/2" />
          </div>
        )}

        {!isLoading && data?.kind === "post" && (
          <div className="space-y-3">
            {data.post.media_url && (
              <img
                src={data.post.media_url}
                alt="Post media"
                className="max-h-72 w-full rounded-md border object-cover"
              />
            )}
            <div className="flex flex-wrap items-center gap-2 text-xs">
              <Badge variant="outline">{PLATFORM_LABEL[data.post.platform] ?? data.post.platform}</Badge>
              <span className="text-muted-foreground">
                {new Date(data.post.posted_at).toLocaleString()}
              </span>
              <span className="ml-auto font-semibold text-primary">
                {Number(data.post.engagement_rate ?? 0).toFixed(2)}% engagement
              </span>
            </div>
            <p className="rounded-md border bg-muted/30 p-3 text-sm">{data.post.caption}</p>
            <div className="grid grid-cols-4 gap-2 text-center text-xs">
              <MetricPill label="Likes" value={data.post.likes} />
              <MetricPill label="Comments" value={data.post.comments} />
              <MetricPill label="Shares" value={data.post.shares} />
              <MetricPill label="Views" value={data.post.views} />
            </div>
            {data.post.url && (
              <a
                href={data.post.url}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1 text-xs text-primary hover:underline"
              >
                Open original <ExternalLink className="size-3" />
              </a>
            )}
          </div>
        )}

        {!isLoading && data?.kind === "metric" && (
          <div className="space-y-3">
            <div className="rounded-md border bg-muted/30 p-3 text-sm">{data.description}</div>
            <div className="grid gap-2">
              {data.breakdown.map((b, i) => (
                <div key={i} className="flex items-center justify-between rounded border px-3 py-2 text-sm">
                  <span className="text-muted-foreground">{b.label}</span>
                  <span className="font-semibold tabular-nums">{b.value}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {!isLoading && !data && open && (
          <p className="text-sm text-muted-foreground">Evidence detail not available.</p>
        )}
      </DialogContent>
    </Dialog>
  );
}

function MetricPill({ label, value }: { label: string; value: number | null }) {
  return (
    <div className="rounded-md border p-2">
      <div className="text-[10px] uppercase tracking-wide text-muted-foreground">{label}</div>
      <div className="font-semibold tabular-nums">{(value ?? 0).toLocaleString()}</div>
    </div>
  );
}
