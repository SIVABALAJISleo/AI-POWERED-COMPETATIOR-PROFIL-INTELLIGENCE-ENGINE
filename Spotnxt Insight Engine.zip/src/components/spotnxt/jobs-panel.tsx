import { useEffect, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { listJobs, retryJob, enqueueRecompute } from "@/lib/ingestion.functions";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  RefreshCw,
  Play,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Loader2,
  Radio,
  WifiOff,
} from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { toast } from "sonner";

const STATUS_STYLE: Record<string, { icon: React.ReactNode; className: string }> = {
  pending: { icon: <Clock className="size-3" />, className: "bg-muted text-foreground" },
  running: { icon: <Loader2 className="size-3 animate-spin" />, className: "bg-blue-500/15 text-blue-700 dark:text-blue-300" },
  done: { icon: <CheckCircle2 className="size-3" />, className: "bg-emerald-500/15 text-emerald-700 dark:text-emerald-400" },
  failed: { icon: <AlertTriangle className="size-3" />, className: "bg-amber-500/15 text-amber-700 dark:text-amber-400" },
  dead: { icon: <AlertTriangle className="size-3" />, className: "bg-rose-500/15 text-rose-700 dark:text-rose-400" },
};

const KIND_LABEL: Record<string, string> = {
  compute_dna: "Creative DNA",
  detect_campaigns: "Campaign detection",
};

export function JobsPanel({ competitorId }: { competitorId: string }) {
  const qc = useQueryClient();
  const listFn = useServerFn(listJobs);
  const retryFn = useServerFn(retryJob);
  const recomputeFn = useServerFn(enqueueRecompute);
  const [connected, setConnected] = useState(true);

  const { data: jobs, isLoading, refetch } = useQuery({
    queryKey: ["jobs", competitorId],
    queryFn: () => listFn({ data: { competitorId, limit: 20 } }),
    // Realtime drives updates; poll fast if the socket dropped, slow otherwise.
    refetchInterval: connected ? 15_000 : 4_000,
    refetchIntervalInBackground: false,
    refetchOnWindowFocus: true,
    refetchOnReconnect: true,
  });

  // Stream job status changes via Supabase Realtime; reconcile on reconnect.
  useEffect(() => {
    const invalidateAll = () => {
      qc.invalidateQueries({ queryKey: ["jobs", competitorId] });
      qc.invalidateQueries({ queryKey: ["creative-dna", competitorId] });
      qc.invalidateQueries({ queryKey: ["campaigns", competitorId] });
      qc.invalidateQueries({ queryKey: ["audit", competitorId] });
    };
    const channel = supabase
      .channel(`jobs:${competitorId}`)
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "jobs" },
        (payload) => {
          const row =
            (payload.new as { payload?: { competitor_id?: string } } | null) ??
            (payload.old as { payload?: { competitor_id?: string } } | null);
          if (row?.payload?.competitor_id === competitorId) invalidateAll();
        },
      )
      .subscribe((status) => {
        setConnected(status === "SUBSCRIBED");
        // Fresh subscription → refetch to catch anything we missed while disconnected.
        if (status === "SUBSCRIBED") invalidateAll();
      });
    const onVisible = () => {
      if (document.visibilityState === "visible") invalidateAll();
    };
    document.addEventListener("visibilitychange", onVisible);
    window.addEventListener("online", invalidateAll);
    return () => {
      supabase.removeChannel(channel);
      document.removeEventListener("visibilitychange", onVisible);
      window.removeEventListener("online", invalidateAll);
    };
  }, [competitorId, qc]);


  const retry = useMutation({
    mutationFn: (jobId: string) => retryFn({ data: { jobId } }),
    onSuccess: () => {
      toast.success("Job requeued");
      qc.invalidateQueries({ queryKey: ["jobs", competitorId] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const recompute = useMutation({
    mutationFn: () => recomputeFn({ data: { competitorId } }),
    onSuccess: () => {
      toast.success("Analysis jobs queued");
      qc.invalidateQueries({ queryKey: ["jobs", competitorId] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0">
        <div>
          <CardTitle className="flex items-center gap-2 text-base">
            Analysis jobs
            {connected ? (
              <Radio className="size-3.5 text-emerald-500" aria-label="Live updates" />
            ) : (
              <WifiOff className="size-3.5 text-amber-500" aria-label="Reconnecting (polling)" />
            )}
          </CardTitle>
          <CardDescription>
            {connected ? "Live updates via realtime; retry failed runs inline." : "Realtime dropped — reconciling via polling."}
          </CardDescription>
        </div>

        <div className="flex gap-2">
          <Button size="sm" variant="outline" onClick={() => refetch()} disabled={isLoading}>
            <RefreshCw className={`size-3.5 ${isLoading ? "animate-spin" : ""}`} />
          </Button>
          <Button size="sm" onClick={() => recompute.mutate()} disabled={recompute.isPending}>
            <Play className="size-3.5" /> Recompute
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-2">
        {(jobs ?? []).length === 0 && (
          <p className="rounded-md border border-dashed p-4 text-center text-sm text-muted-foreground">
            No jobs yet. Ingest posts or click Recompute to kick off analysis.
          </p>
        )}
        {(jobs ?? []).map((j) => {
          const style = STATUS_STYLE[j.status] ?? STATUS_STYLE.pending;
          return (
            <div key={j.id} className="flex items-center justify-between gap-3 rounded-md border p-2.5 text-sm">
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <Badge className={`gap-1 ${style.className}`} variant="outline">
                    {style.icon}
                    {j.status}
                  </Badge>
                  <span className="font-medium">{KIND_LABEL[j.kind] ?? j.kind}</span>
                  {j.attempts > 0 && (
                    <span className="text-xs text-muted-foreground">· try {j.attempts}</span>
                  )}
                </div>
                {j.last_error && (
                  <p className="mt-1 line-clamp-1 text-xs text-rose-500" title={j.last_error}>
                    {j.last_error}
                  </p>
                )}
                <p className="mt-0.5 text-xs text-muted-foreground">
                  {formatDistanceToNow(new Date(j.updated_at), { addSuffix: true })}
                </p>
              </div>
              {(j.status === "failed" || j.status === "dead") && (
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => retry.mutate(j.id)}
                  disabled={retry.isPending}
                >
                  <RefreshCw className="size-3" /> Retry
                </Button>
              )}
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
}
