export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      audit_events: {
        Row: {
          action: string
          actor_user_id: string | null
          created_at: string
          id: string
          metadata: Json | null
          org_id: string
          target_id: string | null
          target_type: string | null
        }
        Insert: {
          action: string
          actor_user_id?: string | null
          created_at?: string
          id?: string
          metadata?: Json | null
          org_id: string
          target_id?: string | null
          target_type?: string | null
        }
        Update: {
          action?: string
          actor_user_id?: string | null
          created_at?: string
          id?: string
          metadata?: Json | null
          org_id?: string
          target_id?: string | null
          target_type?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "audit_events_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      campaign_detections: {
        Row: {
          competitor_id: string
          confidence: number | null
          created_at: string
          cross_platform_sync: number | null
          end_date: string | null
          hashtag_cluster: Json | null
          id: string
          name: string | null
          start_date: string | null
        }
        Insert: {
          competitor_id: string
          confidence?: number | null
          created_at?: string
          cross_platform_sync?: number | null
          end_date?: string | null
          hashtag_cluster?: Json | null
          id?: string
          name?: string | null
          start_date?: string | null
        }
        Update: {
          competitor_id?: string
          confidence?: number | null
          created_at?: string
          cross_platform_sync?: number | null
          end_date?: string | null
          hashtag_cluster?: Json | null
          id?: string
          name?: string | null
          start_date?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "campaign_detections_competitor_id_fkey"
            columns: ["competitor_id"]
            isOneToOne: false
            referencedRelation: "competitors"
            referencedColumns: ["id"]
          },
        ]
      }
      competitor_handles: {
        Row: {
          competitor_id: string
          connected_at: string
          external_id: string | null
          handle: string
          id: string
          platform: Database["public"]["Enums"]["platform"]
        }
        Insert: {
          competitor_id: string
          connected_at?: string
          external_id?: string | null
          handle: string
          id?: string
          platform: Database["public"]["Enums"]["platform"]
        }
        Update: {
          competitor_id?: string
          connected_at?: string
          external_id?: string | null
          handle?: string
          id?: string
          platform?: Database["public"]["Enums"]["platform"]
        }
        Relationships: [
          {
            foreignKeyName: "competitor_handles_competitor_id_fkey"
            columns: ["competitor_id"]
            isOneToOne: false
            referencedRelation: "competitors"
            referencedColumns: ["id"]
          },
        ]
      }
      competitors: {
        Row: {
          created_at: string
          id: string
          industry: string | null
          logo_url: string | null
          name: string
          org_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          industry?: string | null
          logo_url?: string | null
          name: string
          org_id: string
        }
        Update: {
          created_at?: string
          id?: string
          industry?: string | null
          logo_url?: string | null
          name?: string
          org_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "competitors_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      content_pillars: {
        Row: {
          color: string | null
          id: string
          name: string
          org_id: string
        }
        Insert: {
          color?: string | null
          id?: string
          name: string
          org_id: string
        }
        Update: {
          color?: string | null
          id?: string
          name?: string
          org_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "content_pillars_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      creative_fingerprints: {
        Row: {
          competitor_id: string
          computed_at: string
          dominant_palette: Json | null
          face_product_ratio: number | null
          logo_consistency: number | null
          style_embedding: Json | null
          text_overlay_density: number | null
        }
        Insert: {
          competitor_id: string
          computed_at?: string
          dominant_palette?: Json | null
          face_product_ratio?: number | null
          logo_consistency?: number | null
          style_embedding?: Json | null
          text_overlay_density?: number | null
        }
        Update: {
          competitor_id?: string
          computed_at?: string
          dominant_palette?: Json | null
          face_product_ratio?: number | null
          logo_consistency?: number | null
          style_embedding?: Json | null
          text_overlay_density?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "creative_fingerprints_competitor_id_fkey"
            columns: ["competitor_id"]
            isOneToOne: true
            referencedRelation: "competitors"
            referencedColumns: ["id"]
          },
        ]
      }
      creative_tags: {
        Row: {
          face_ratio: number | null
          has_text_overlay: boolean | null
          palette: Json | null
          post_id: string
          product_ratio: number | null
          style_embedding: Json | null
          tagged_at: string
        }
        Insert: {
          face_ratio?: number | null
          has_text_overlay?: boolean | null
          palette?: Json | null
          post_id: string
          product_ratio?: number | null
          style_embedding?: Json | null
          tagged_at?: string
        }
        Update: {
          face_ratio?: number | null
          has_text_overlay?: boolean | null
          palette?: Json | null
          post_id?: string
          product_ratio?: number | null
          style_embedding?: Json | null
          tagged_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "creative_tags_post_id_fkey"
            columns: ["post_id"]
            isOneToOne: true
            referencedRelation: "posts"
            referencedColumns: ["id"]
          },
        ]
      }
      data_confidence_scores: {
        Row: {
          competitor_id: string
          completeness_pct: number
          limitations: Json | null
          platform: Database["public"]["Enums"]["platform"]
          tracking_start_date: string | null
          updated_at: string
        }
        Insert: {
          competitor_id: string
          completeness_pct?: number
          limitations?: Json | null
          platform: Database["public"]["Enums"]["platform"]
          tracking_start_date?: string | null
          updated_at?: string
        }
        Update: {
          competitor_id?: string
          completeness_pct?: number
          limitations?: Json | null
          platform?: Database["public"]["Enums"]["platform"]
          tracking_start_date?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "data_confidence_scores_competitor_id_fkey"
            columns: ["competitor_id"]
            isOneToOne: false
            referencedRelation: "competitors"
            referencedColumns: ["id"]
          },
        ]
      }
      evidence_links: {
        Row: {
          id: string
          recommendation_id: string
          snippet: string | null
          source_id: string | null
          source_type: string
        }
        Insert: {
          id?: string
          recommendation_id: string
          snippet?: string | null
          source_id?: string | null
          source_type: string
        }
        Update: {
          id?: string
          recommendation_id?: string
          snippet?: string | null
          source_id?: string | null
          source_type?: string
        }
        Relationships: [
          {
            foreignKeyName: "evidence_links_recommendation_id_fkey"
            columns: ["recommendation_id"]
            isOneToOne: false
            referencedRelation: "recommendations"
            referencedColumns: ["id"]
          },
        ]
      }
      export_share_links: {
        Row: {
          created_at: string
          created_by: string | null
          download_count: number
          download_limit_per_min: number
          expires_at: string
          export_id: string
          id: string
          max_downloads: number
          org_id: string
          revoked_at: string | null
          token: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          download_count?: number
          download_limit_per_min?: number
          expires_at: string
          export_id: string
          id?: string
          max_downloads?: number
          org_id: string
          revoked_at?: string | null
          token: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          download_count?: number
          download_limit_per_min?: number
          expires_at?: string
          export_id?: string
          id?: string
          max_downloads?: number
          org_id?: string
          revoked_at?: string | null
          token?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "export_share_links_export_id_fkey"
            columns: ["export_id"]
            isOneToOne: false
            referencedRelation: "exports"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "export_share_links_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      export_template_versions: {
        Row: {
          change_type: string
          changed_by: string | null
          config: Json
          created_at: string
          diff: Json
          id: string
          is_default: boolean
          kind: string
          name: string
          org_id: string
          template_id: string
          version: number
        }
        Insert: {
          change_type?: string
          changed_by?: string | null
          config?: Json
          created_at?: string
          diff?: Json
          id?: string
          is_default?: boolean
          kind: string
          name: string
          org_id: string
          template_id: string
          version: number
        }
        Update: {
          change_type?: string
          changed_by?: string | null
          config?: Json
          created_at?: string
          diff?: Json
          id?: string
          is_default?: boolean
          kind?: string
          name?: string
          org_id?: string
          template_id?: string
          version?: number
        }
        Relationships: [
          {
            foreignKeyName: "export_template_versions_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "export_template_versions_template_id_fkey"
            columns: ["template_id"]
            isOneToOne: false
            referencedRelation: "export_templates"
            referencedColumns: ["id"]
          },
        ]
      }
      export_templates: {
        Row: {
          config: Json
          created_at: string
          created_by: string | null
          current_version: number
          id: string
          is_default: boolean
          kind: string
          name: string
          org_id: string
          updated_at: string
        }
        Insert: {
          config?: Json
          created_at?: string
          created_by?: string | null
          current_version?: number
          id?: string
          is_default?: boolean
          kind: string
          name: string
          org_id: string
          updated_at?: string
        }
        Update: {
          config?: Json
          created_at?: string
          created_by?: string | null
          current_version?: number
          id?: string
          is_default?: boolean
          kind?: string
          name?: string
          org_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "export_templates_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      export_webhook_deliveries: {
        Row: {
          attempts: number
          correlation_id: string | null
          created_at: string
          dead_lettered: boolean
          delivered_at: string | null
          error: string | null
          event: string
          export_id: string
          id: string
          idempotency_key: string | null
          next_retry_at: string | null
          org_id: string
          payload: Json | null
          response_body: string | null
          signed_timestamp: number | null
          status: string
          status_code: number | null
          updated_at: string
          webhook_id: string
        }
        Insert: {
          attempts?: number
          correlation_id?: string | null
          created_at?: string
          dead_lettered?: boolean
          delivered_at?: string | null
          error?: string | null
          event: string
          export_id: string
          id?: string
          idempotency_key?: string | null
          next_retry_at?: string | null
          org_id: string
          payload?: Json | null
          response_body?: string | null
          signed_timestamp?: number | null
          status?: string
          status_code?: number | null
          updated_at?: string
          webhook_id: string
        }
        Update: {
          attempts?: number
          correlation_id?: string | null
          created_at?: string
          dead_lettered?: boolean
          delivered_at?: string | null
          error?: string | null
          event?: string
          export_id?: string
          id?: string
          idempotency_key?: string | null
          next_retry_at?: string | null
          org_id?: string
          payload?: Json | null
          response_body?: string | null
          signed_timestamp?: number | null
          status?: string
          status_code?: number | null
          updated_at?: string
          webhook_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "export_webhook_deliveries_export_id_fkey"
            columns: ["export_id"]
            isOneToOne: false
            referencedRelation: "exports"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "export_webhook_deliveries_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "export_webhook_deliveries_webhook_id_fkey"
            columns: ["webhook_id"]
            isOneToOne: false
            referencedRelation: "export_webhooks"
            referencedColumns: ["id"]
          },
        ]
      }
      export_webhooks: {
        Row: {
          consecutive_failures: number
          created_at: string
          created_by: string | null
          enabled: boolean
          events: string[]
          id: string
          last_failure_at: string | null
          last_failure_reason: string | null
          max_attempts: number
          org_id: string
          require_timestamp: boolean
          secret: string
          signing_version: string
          timestamp_tolerance_seconds: number
          updated_at: string
          url: string
        }
        Insert: {
          consecutive_failures?: number
          created_at?: string
          created_by?: string | null
          enabled?: boolean
          events?: string[]
          id?: string
          last_failure_at?: string | null
          last_failure_reason?: string | null
          max_attempts?: number
          org_id: string
          require_timestamp?: boolean
          secret: string
          signing_version?: string
          timestamp_tolerance_seconds?: number
          updated_at?: string
          url: string
        }
        Update: {
          consecutive_failures?: number
          created_at?: string
          created_by?: string | null
          enabled?: boolean
          events?: string[]
          id?: string
          last_failure_at?: string | null
          last_failure_reason?: string | null
          max_attempts?: number
          org_id?: string
          require_timestamp?: boolean
          secret?: string
          signing_version?: string
          timestamp_tolerance_seconds?: number
          updated_at?: string
          url?: string
        }
        Relationships: [
          {
            foreignKeyName: "export_webhooks_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      exports: {
        Row: {
          artifact: string | null
          competitor_id: string | null
          completed_at: string | null
          created_at: string
          error: string | null
          filename: string | null
          format: string
          id: string
          kind: string
          mime_type: string | null
          org_id: string
          params: Json
          progress: number
          requested_by: string | null
          row_count: number | null
          size_bytes: number | null
          status: string
          updated_at: string
        }
        Insert: {
          artifact?: string | null
          competitor_id?: string | null
          completed_at?: string | null
          created_at?: string
          error?: string | null
          filename?: string | null
          format: string
          id?: string
          kind: string
          mime_type?: string | null
          org_id: string
          params?: Json
          progress?: number
          requested_by?: string | null
          row_count?: number | null
          size_bytes?: number | null
          status?: string
          updated_at?: string
        }
        Update: {
          artifact?: string | null
          competitor_id?: string | null
          completed_at?: string | null
          created_at?: string
          error?: string | null
          filename?: string | null
          format?: string
          id?: string
          kind?: string
          mime_type?: string | null
          org_id?: string
          params?: Json
          progress?: number
          requested_by?: string | null
          row_count?: number | null
          size_bytes?: number | null
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "exports_competitor_id_fkey"
            columns: ["competitor_id"]
            isOneToOne: false
            referencedRelation: "competitors"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "exports_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      feature_flags: {
        Row: {
          config: Json | null
          enabled: boolean
          key: string
          org_id: string
        }
        Insert: {
          config?: Json | null
          enabled?: boolean
          key: string
          org_id: string
        }
        Update: {
          config?: Json | null
          enabled?: boolean
          key?: string
          org_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "feature_flags_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      ingest_quarantine: {
        Row: {
          batch_id: string | null
          competitor_id: string
          created_at: string
          id: string
          issues: Json
          org_id: string
          raw: Json
          resolved_at: string | null
          resolved_by: string | null
          row_index: number | null
          source: string
          status: string
          submitted_by: string | null
          updated_at: string
        }
        Insert: {
          batch_id?: string | null
          competitor_id: string
          created_at?: string
          id?: string
          issues?: Json
          org_id: string
          raw: Json
          resolved_at?: string | null
          resolved_by?: string | null
          row_index?: number | null
          source: string
          status?: string
          submitted_by?: string | null
          updated_at?: string
        }
        Update: {
          batch_id?: string | null
          competitor_id?: string
          created_at?: string
          id?: string
          issues?: Json
          org_id?: string
          raw?: Json
          resolved_at?: string | null
          resolved_by?: string | null
          row_index?: number | null
          source?: string
          status?: string
          submitted_by?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "ingest_quarantine_competitor_id_fkey"
            columns: ["competitor_id"]
            isOneToOne: false
            referencedRelation: "competitors"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ingest_quarantine_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      jobs: {
        Row: {
          attempts: number
          created_at: string
          id: string
          kind: string
          last_error: string | null
          payload: Json | null
          run_after: string
          status: Database["public"]["Enums"]["job_status"]
          updated_at: string
        }
        Insert: {
          attempts?: number
          created_at?: string
          id?: string
          kind: string
          last_error?: string | null
          payload?: Json | null
          run_after?: string
          status?: Database["public"]["Enums"]["job_status"]
          updated_at?: string
        }
        Update: {
          attempts?: number
          created_at?: string
          id?: string
          kind?: string
          last_error?: string | null
          payload?: Json | null
          run_after?: string
          status?: Database["public"]["Enums"]["job_status"]
          updated_at?: string
        }
        Relationships: []
      }
      notifications: {
        Row: {
          body: string | null
          created_at: string
          id: string
          kind: string
          metadata: Json
          org_id: string | null
          read_at: string | null
          target_id: string | null
          target_type: string | null
          title: string
          user_id: string
        }
        Insert: {
          body?: string | null
          created_at?: string
          id?: string
          kind: string
          metadata?: Json
          org_id?: string | null
          read_at?: string | null
          target_id?: string | null
          target_type?: string | null
          title: string
          user_id: string
        }
        Update: {
          body?: string | null
          created_at?: string
          id?: string
          kind?: string
          metadata?: Json
          org_id?: string | null
          read_at?: string | null
          target_id?: string | null
          target_type?: string | null
          title?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "notifications_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      organization_members: {
        Row: {
          created_at: string
          org_id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          org_id: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          org_id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "organization_members_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      organizations: {
        Row: {
          created_at: string
          export_retention_days: number
          id: string
          is_demo: boolean
          name: string
          slug: string
        }
        Insert: {
          created_at?: string
          export_retention_days?: number
          id?: string
          is_demo?: boolean
          name: string
          slug: string
        }
        Update: {
          created_at?: string
          export_retention_days?: number
          id?: string
          is_demo?: boolean
          name?: string
          slug?: string
        }
        Relationships: []
      }
      post_pillars: {
        Row: {
          confidence: number
          pillar_id: string
          post_id: string
        }
        Insert: {
          confidence?: number
          pillar_id: string
          post_id: string
        }
        Update: {
          confidence?: number
          pillar_id?: string
          post_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "post_pillars_pillar_id_fkey"
            columns: ["pillar_id"]
            isOneToOne: false
            referencedRelation: "content_pillars"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "post_pillars_post_id_fkey"
            columns: ["post_id"]
            isOneToOne: false
            referencedRelation: "posts"
            referencedColumns: ["id"]
          },
        ]
      }
      posts: {
        Row: {
          caption: string | null
          comments: number
          competitor_id: string
          created_at: string
          engagement_rate: number
          external_id: string | null
          hashtags: string[] | null
          id: string
          likes: number
          media_url: string | null
          platform: Database["public"]["Enums"]["platform"]
          posted_at: string
          raw: Json | null
          shares: number
          url: string | null
          views: number
        }
        Insert: {
          caption?: string | null
          comments?: number
          competitor_id: string
          created_at?: string
          engagement_rate?: number
          external_id?: string | null
          hashtags?: string[] | null
          id?: string
          likes?: number
          media_url?: string | null
          platform: Database["public"]["Enums"]["platform"]
          posted_at: string
          raw?: Json | null
          shares?: number
          url?: string | null
          views?: number
        }
        Update: {
          caption?: string | null
          comments?: number
          competitor_id?: string
          created_at?: string
          engagement_rate?: number
          external_id?: string | null
          hashtags?: string[] | null
          id?: string
          likes?: number
          media_url?: string | null
          platform?: Database["public"]["Enums"]["platform"]
          posted_at?: string
          raw?: Json | null
          shares?: number
          url?: string | null
          views?: number
        }
        Relationships: [
          {
            foreignKeyName: "posts_competitor_id_fkey"
            columns: ["competitor_id"]
            isOneToOne: false
            referencedRelation: "competitors"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          avatar_url: string | null
          created_at: string
          display_name: string | null
          id: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          display_name?: string | null
          id: string
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          display_name?: string | null
          id?: string
        }
        Relationships: []
      }
      promo_classifications: {
        Row: {
          confidence: number
          post_id: string
          promo_type: Database["public"]["Enums"]["promo_type"]
        }
        Insert: {
          confidence?: number
          post_id: string
          promo_type?: Database["public"]["Enums"]["promo_type"]
        }
        Update: {
          confidence?: number
          post_id?: string
          promo_type?: Database["public"]["Enums"]["promo_type"]
        }
        Relationships: [
          {
            foreignKeyName: "promo_classifications_post_id_fkey"
            columns: ["post_id"]
            isOneToOne: true
            referencedRelation: "posts"
            referencedColumns: ["id"]
          },
        ]
      }
      recommendations: {
        Row: {
          body: string
          created_at: string
          id: string
          org_id: string
          priority: string
          status: string
          title: string
        }
        Insert: {
          body: string
          created_at?: string
          id?: string
          org_id: string
          priority?: string
          status?: string
          title: string
        }
        Update: {
          body?: string
          created_at?: string
          id?: string
          org_id?: string
          priority?: string
          status?: string
          title?: string
        }
        Relationships: [
          {
            foreignKeyName: "recommendations_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      reports: {
        Row: {
          created_at: string
          id: string
          kind: string
          org_id: string
          params: Json | null
          payload: Json | null
          pdf_url: string | null
          status: string
        }
        Insert: {
          created_at?: string
          id?: string
          kind: string
          org_id: string
          params?: Json | null
          payload?: Json | null
          pdf_url?: string | null
          status?: string
        }
        Update: {
          created_at?: string
          id?: string
          kind?: string
          org_id?: string
          params?: Json | null
          payload?: Json | null
          pdf_url?: string | null
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "reports_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      share_link_rate_hits: {
        Row: {
          hits: number
          ip_hash: string
          token: string
          updated_at: string
          window_start: string
        }
        Insert: {
          hits?: number
          ip_hash: string
          token: string
          updated_at?: string
          window_start: string
        }
        Update: {
          hits?: number
          ip_hash?: string
          token?: string
          updated_at?: string
          window_start?: string
        }
        Relationships: []
      }
      whitespace_gaps: {
        Row: {
          competitor_set_hash: string
          description: string | null
          evidence: Json | null
          gap_type: string
          generated_at: string
          id: string
          org_id: string
        }
        Insert: {
          competitor_set_hash: string
          description?: string | null
          evidence?: Json | null
          gap_type: string
          generated_at?: string
          id?: string
          org_id: string
        }
        Update: {
          competitor_set_hash?: string
          description?: string | null
          evidence?: Json | null
          gap_type?: string
          generated_at?: string
          id?: string
          org_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "whitespace_gaps_org_id_fkey"
            columns: ["org_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      purge_expired_exports: { Args: never; Returns: number }
    }
    Enums: {
      app_role: "owner" | "admin" | "analyst" | "viewer"
      job_status: "pending" | "running" | "done" | "failed" | "dead"
      platform:
        | "instagram"
        | "facebook"
        | "linkedin"
        | "x"
        | "youtube"
        | "tiktok"
      promo_type: "discount" | "launch" | "giveaway" | "awareness" | "none"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["owner", "admin", "analyst", "viewer"],
      job_status: ["pending", "running", "done", "failed", "dead"],
      platform: ["instagram", "facebook", "linkedin", "x", "youtube", "tiktok"],
      promo_type: ["discount", "launch", "giveaway", "awareness", "none"],
    },
  },
} as const
