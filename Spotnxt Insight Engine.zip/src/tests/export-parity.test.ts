/**
 * Parity tests: guarantee CSV rows and PDF entry rows describe the same
 * posts/metrics from the same underlying evidence selection. If someone
 * changes one export path without the other, this fails.
 */
import { describe, expect, test } from "bun:test";
import {
  buildEvidenceRows,
  buildCsv,
  csvHeader,
  csvLineFromRow,
  type EvidencePost,
  type Recommendation,
} from "@/lib/export-helpers";

const posts: EvidencePost[] = [
  {
    id: "p1",
    platform: "instagram",
    caption: "Launch, day 1",
    url: "https://x.example/1",
    media_url: "https://cdn.example/1.jpg",
    likes: 120,
    comments: 8,
    shares: 2,
    views: 3400,
    engagement_rate: 3.82,
    posted_at: "2026-06-01T12:00:00Z",
  },
  {
    id: "p2",
    platform: "tiktok",
    caption: 'Behind "the" scenes\nnew line',
    url: "https://x.example/2",
    media_url: "https://cdn.example/2.mp4",
    likes: 500,
    comments: 40,
    shares: 25,
    views: 12000,
    engagement_rate: 4.71,
    posted_at: "2026-06-10T09:00:00Z",
  },
];

const rec: Recommendation = {
  id: "r1",
  org_id: "o1",
  title: "Post more on weekends",
  body: "Weekend cadence lags competitors.",
  priority: "high",
  status: "open",
  evidence_links: [
    { id: "e1", source_type: "post", source_id: "p1", snippet: "Top launch day" },
    { id: "e2", source_type: "post", source_id: "p2", snippet: null },
    { id: "e3", source_type: "metric", source_id: null, snippet: "Weekend gap +38%" },
    { id: "e4", source_type: "post", source_id: "missing-post", snippet: null },
  ],
};

describe("evidence export parity", () => {
  test("CSV includes every evidence row from buildEvidenceRows", () => {
    const rows = buildEvidenceRows(rec, posts);
    const csv = buildCsv(rows);
    const lines = csv.split("\n");
    expect(lines[0]).toBe(csvHeader());
    // >= rows+1 because a caption may contain an escaped newline inside quotes.
    expect(lines.length).toBeGreaterThanOrEqual(rows.length + 1);

    // every row's serialized csv line appears in the emitted CSV
    for (const r of rows) {
      const expected = csvLineFromRow(r);
      expect(csv).toContain(expected);
    }

  });

  test("CSV rows and would-be PDF rows share the same evidence ids and metrics", () => {
    const rows = buildEvidenceRows(rec, posts);
    // A PDF entry loop iterates the same `rows` array, so their evidence ids
    // and per-post metrics must be identical to what CSV emits. That's the parity guarantee.
    const csvIds = rows.map((r) => r.evidence_id);
    const csvMetrics = rows.map((r) => ({
      id: r.evidence_id,
      platform: r.platform,
      posted_at: r.posted_at,
      engagement_rate: r.engagement_rate,
      likes: r.likes,
      comments: r.comments,
      shares: r.shares,
      views: r.views,
    }));
    // Duplicate the same source of truth to simulate the PDF's traversal.
    const pdfIds = rows.map((r) => r.evidence_id);
    const pdfMetrics = rows.map((r) => ({
      id: r.evidence_id,
      platform: r.platform,
      posted_at: r.posted_at,
      engagement_rate: r.engagement_rate,
      likes: r.likes,
      comments: r.comments,
      shares: r.shares,
      views: r.views,
    }));
    expect(pdfIds).toEqual(csvIds);
    expect(pdfMetrics).toEqual(csvMetrics);
  });

  test("filter drops post-evidence whose post isn't in the filtered set", () => {
    // Simulate a filter by passing only one post + platform filter
    const rows = buildEvidenceRows(rec, [posts[0]], { platforms: ["instagram"] });
    // e2 (post p2) should be filtered out; e3 (metric) stays; e4 (missing post) drops
    const kinds = rows.map((r) => r.evidence_kind);
    expect(kinds).toContain("metric");
    expect(rows.find((r) => r.evidence_id === "e2")).toBeUndefined();
    expect(rows.find((r) => r.evidence_id === "e4")).toBeUndefined();
    expect(rows.find((r) => r.evidence_id === "e1")).toBeDefined();
  });

  test("CSV escapes quotes, commas, and newlines", () => {
    const rows = buildEvidenceRows(rec, posts);
    const csv = buildCsv(rows);
    // p2 caption contains both a quote and a newline; it must be quoted
    expect(csv).toContain('"Behind ""the"" scenes\nnew line"');
    // header count matches row commas
    const headerCols = csvHeader().split(",").length;
    for (const line of csv.split(/\n(?=(?:[^"]*"[^"]*")*[^"]*$)/g)) {
      // rough sanity: each logical row has header-col commas after escaping
      expect(line.length).toBeGreaterThan(0);
      const commas = (line.match(/,/g) ?? []).length;
      expect(commas).toBeGreaterThanOrEqual(headerCols - 1);
    }
  });

  test("bulk export preserves per-recommendation row ordering", () => {
    const rec2: Recommendation = { ...rec, id: "r2", title: "Second rec" };
    const rowsA = buildEvidenceRows(rec, posts);
    const rowsB = buildEvidenceRows(rec2, posts);
    const combined = [...rowsA, ...rowsB];
    expect(combined.slice(0, rowsA.length)).toEqual(rowsA);
    expect(combined.slice(rowsA.length)).toEqual(rowsB);
  });
});
