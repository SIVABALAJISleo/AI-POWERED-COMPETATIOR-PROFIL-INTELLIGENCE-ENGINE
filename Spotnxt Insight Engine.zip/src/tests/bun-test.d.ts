// Minimal ambient declarations for bun:test used by src/tests/*.
// Avoids adding bun's full global types (which conflict with browser fetch typings).
declare module "bun:test" {
  type Fn = () => void | Promise<void>;
  export const describe: (name: string, fn: Fn) => void;
  export const test: (name: string, fn: Fn) => void;
  export const it: typeof test;
  export const beforeAll: (fn: Fn) => void;
  export const beforeEach: (fn: Fn) => void;
  export const afterAll: (fn: Fn) => void;
  export const afterEach: (fn: Fn) => void;
  interface Matchers<T = unknown> {
    toBe(expected: T): void;
    toEqual(expected: unknown): void;
    toContain(expected: unknown): void;
    toBeGreaterThan(expected: number): void;
    toBeGreaterThanOrEqual(expected: number): void;
    toBeDefined(): void;
    toBeUndefined(): void;
    toBeNull(): void;
    toBeTruthy(): void;
    toBeFalsy(): void;
    toHaveLength(n: number): void;
    toThrow(msg?: string | RegExp): void;
    not: Matchers<T>;
  }
  export function expect<T = unknown>(actual: T): Matchers<T>;
}
