import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Radar,
  Palette,
  Sparkles,
  MapIcon,
  ShieldCheck,
  ArrowRight,
} from "lucide-react";

export const Route = createFileRoute("/")({
  component: Landing,
  head: () => ({
    meta: [
      { title: "Spotnxt — Competitor Profile Intelligence Engine" },
      {
        name: "description",
        content:
          "AI-native competitor social intelligence. Creative DNA fingerprints, automated campaign detection, evidence-linked recommendations, whitespace maps, and honest data confidence.",
      },
      { property: "og:title", content: "Spotnxt — Competitor Profile Intelligence" },
      {
        property: "og:description",
        content: "Track competitors across 6 platforms with evidence-linked AI insights.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
});

const differentiators = [
  {
    icon: Palette,
    title: "Creative DNA Fingerprinting",
    body: "Visual pattern extraction no other tool ships — palette, overlay density, product/face framing ratio, style embedding.",
  },
  {
    icon: Radar,
    title: "Automated Campaign Detection",
    body: "Cluster posts across platforms by hashtag co-occurrence and timing. Zero manual tagging.",
  },
  {
    icon: Sparkles,
    title: "Evidence-linked recommendations",
    body: "Every AI insight cites the exact posts and metrics behind it. No black-box summaries.",
  },
  {
    icon: MapIcon,
    title: "Content Whitespace Mapping",
    body: "Surface what competitors are NOT doing — the unclaimed pillars and formats waiting for you.",
  },
  {
    icon: ShieldCheck,
    title: "Honest Data Confidence Layer",
    body: "Transparent completeness scoring per platform. LinkedIn's competitor API limits are shown, not hidden.",
  },
];

function Landing() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="mx-auto flex max-w-6xl items-center justify-between px-6 py-6">
        <Link to="/" className="flex items-center gap-2 font-semibold tracking-tight">
          <Radar className="size-5 text-primary" />
          Spotnxt
        </Link>
        <div className="flex items-center gap-3">
          <Link to="/auth" className="text-sm text-muted-foreground hover:text-foreground">
            Sign in
          </Link>
          <Button asChild size="sm">
            <Link to="/auth">Get started</Link>
          </Button>
        </div>
      </header>

      <section className="mx-auto max-w-4xl px-6 pt-16 pb-24 text-center">
        <Badge variant="outline" className="mb-6">
          <Sparkles className="size-3" /> Competitor Profile Intelligence Engine
        </Badge>
        <h1 className="text-balance text-5xl font-semibold tracking-tight md:text-6xl">
          Every competitor insight,
          <br />
          <span className="text-primary">traced to its evidence.</span>
        </h1>
        <p className="mx-auto mt-6 max-w-2xl text-lg text-muted-foreground">
          Spotnxt tracks competitor social output across six platforms and combines Creative DNA
          fingerprinting, automated campaign detection, and evidence-linked AI recommendations into
          one honest, auditable pipeline.
        </p>
        <div className="mt-8 flex items-center justify-center gap-3">
          <Button asChild size="lg">
            <Link to="/auth">
              Explore the demo workspace <ArrowRight className="size-4" />
            </Link>
          </Button>
          <span className="text-xs text-muted-foreground">
            5 seeded competitors · 6 months · 6 platforms
          </span>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-6 pb-24">
        <div className="mb-10 max-w-2xl">
          <h2 className="text-3xl font-semibold tracking-tight">Built around five differentiators.</h2>
          <p className="mt-2 text-muted-foreground">
            Hootsuite, Sprout, Buffer, Metricool each cover fragments. Spotnxt fuses the pieces —
            and adds what none of them ship.
          </p>
        </div>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {differentiators.map((d) => (
            <div key={d.title} className="rounded-xl border bg-card p-5">
              <div className="mb-3 flex size-9 items-center justify-center rounded-lg bg-primary/10 text-primary">
                <d.icon className="size-5" />
              </div>
              <h3 className="mb-1 font-semibold">{d.title}</h3>
              <p className="text-sm text-muted-foreground">{d.body}</p>
            </div>
          ))}
        </div>
      </section>

      <footer className="border-t">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-6 text-xs text-muted-foreground">
          <span>© Spotnxt</span>
          <span>Data confidence surfaced everywhere. No black boxes.</span>
        </div>
      </footer>
    </div>
  );
}
