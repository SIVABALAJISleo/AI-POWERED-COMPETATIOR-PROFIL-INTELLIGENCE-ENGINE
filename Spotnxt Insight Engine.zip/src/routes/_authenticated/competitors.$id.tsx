import { createFileRoute, Link } from "@tanstack/react-router";
import { useSuspenseQuery, useQuery, queryOptions } from "@tanstack/react-query";
import { useState, useMemo } from "react";
import { getCompetitor, getFrequency, getTopPosts, getCreativeDNA, getCampaigns } from "@/lib/analytics.functions";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { FrequencyHeatmap } from "@/components/spotnxt/frequency-heatmap";
import { ConfidenceBadge } from "@/components/spotnxt/confidence-badge";
import { CreativeDNA } from "@/components/spotnxt/creative-dna";
import { CampaignTimeline } from "@/components/spotnxt/campaign-timeline";
import { FilterBar, type FilterState } from "@/components/spotnxt/filter-bar";
import { IngestPanel } from "@/components/spotnxt/ingest-panel";
import { JobsPanel } from "@/components/spotnxt/jobs-panel";
import { AuditLogPanel } from "@/components/spotnxt/audit-log-panel";
import { QuarantinePanel } from "@/components/spotnxt/quarantine-panel";

import { PLATFORM_LABEL } from "@/lib/platforms";
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Tooltip as ReTooltip } from "recharts";
import { ArrowLeft, Building2, Palette, Radar } from "lucide-react";

export const Route = createFileRoute("/_authenticated/competitors/$id")({
  loader: ({ context, params }) => {
    const detailQ = queryOptions({
      queryKey: ["competitor", params.id],
      queryFn: () => getCompetitor({ data: { competitorId: params.id } }),
    });
    context.queryClient.ensureQueryData(detailQ);
  },
  component: CompetitorDetail,
});

function CompetitorDetail() {
  const params = Route.useParams();
  const [filters, setFilters] = useState<FilterState>({ platforms: [], from: null, to: null });

  const filterPayload = useMemo(
    () => ({
      competitorId: params.id,
      platforms: filters.platforms.length > 0 ? filters.platforms : undefined,
      from: filters.from ? filters.from.toISOString() : null,
      to: filters.to ? filters.to.toISOString() : null,
    }),
    [params.id, filters],
  );
  const filterKey = [filters.platforms.join(","), filters.from?.toISOString() ?? "", filters.to?.toISOString() ?? ""];

  const { data: detail } = useSuspenseQuery({
    queryKey: ["competitor", params.id],
    queryFn: () => getCompetitor({ data: { competitorId: params.id } }),
  });
  const freqQ = useQuery({
    queryKey: ["frequency", params.id, ...filterKey],
    queryFn: () => getFrequency({ data: filterPayload }),
  });
  const topQ = useQuery({
    queryKey: ["top-posts", params.id, ...filterKey],
    queryFn: () => getTopPosts({ data: filterPayload }),
  });
  const dnaQ = useQuery({
    queryKey: ["creative-dna", params.id, ...filterKey],
    queryFn: () => getCreativeDNA({ data: filterPayload }),
  });
  const campQ = useQuery({
    queryKey: ["campaigns", params.id, ...filterKey],
    queryFn: () => getCampaigns({ data: filterPayload }),
  });

  const freq = freqQ.data;
  const topPosts = topQ.data ?? [];
  const dna = dnaQ.data;
  const campaigns = campQ.data ?? [];

  const availablePlatforms = detail.handles.map((h) => h.platform);
  const confidenceByPlatform = new Map(detail.confidence.map((c) => [c.platform, c]));
  const avgConfidence =
    detail.confidence.length > 0
      ? detail.confidence.reduce((s, c) => s + Number(c.completeness_pct), 0) / detail.confidence.length
      : 0;

  return (
    <div className="space-y-6">
      <div>
        <Link to="/competitors" className="mb-3 inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
          <ArrowLeft className="size-4" /> All competitors
        </Link>
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="flex size-14 items-center justify-center rounded-xl bg-primary/10 text-primary">
              <Building2 className="size-7" />
            </div>
            <div>
              <h1 className="text-3xl font-semibold tracking-tight">{detail.competitor.name}</h1>
              <p className="text-muted-foreground">{detail.competitor.industry ?? "—"}</p>
            </div>
          </div>
          <ConfidenceBadge completeness={avgConfidence} platform="Overall" size="md" />
        </div>
        <div className="mt-4 flex flex-wrap gap-2">
          {detail.handles.map((h) => {
            const conf = confidenceByPlatform.get(h.platform);
            return (
              <div key={h.platform} className="flex items-center gap-2 rounded-md border px-2.5 py-1 text-xs">
                <Badge variant="outline" className="text-[10px]">
                  {PLATFORM_LABEL[h.platform] ?? h.platform}
                </Badge>
                <span className="text-muted-foreground">{h.handle}</span>
                {conf && (
                  <ConfidenceBadge
                    completeness={Number(conf.completeness_pct)}
                    reason={(conf.limitations as { reason?: string } | null)?.reason ?? null}
                  />
                )}
              </div>
            );
          })}
        </div>
      </div>

      <FilterBar availablePlatforms={availablePlatforms} value={filters} onChange={setFilters} />

      <div className="grid gap-3 md:grid-cols-4">
        <StatCard label="Posts (filtered)" value={(freq?.totalPosts ?? 0).toLocaleString()} loading={freqQ.isLoading} />
        <StatCard label="Avg. engagement rate" value={`${(freq?.avgEngagement ?? 0).toFixed(2)}%`} loading={freqQ.isLoading} />
        <StatCard label="Platforms" value={String(freq?.perPlatform.length ?? 0)} loading={freqQ.isLoading} />
        <StatCard
          label="Best-performing post"
          value={freq?.bestPost ? `${freq.bestPost.engagement.toFixed(2)}%` : "—"}
          loading={freqQ.isLoading}
        />
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <IngestPanel competitorId={params.id} />
        <JobsPanel competitorId={params.id} />
      </div>

      <QuarantinePanel competitorId={params.id} />

      <AuditLogPanel competitorId={params.id} title="Activity — this competitor" />



      <Tabs defaultValue="overview">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="creative"><Palette className="size-3.5" /> Creative DNA</TabsTrigger>
          <TabsTrigger value="campaigns"><Radar className="size-3.5" /> Campaigns</TabsTrigger>
          <TabsTrigger value="top">Top content</TabsTrigger>
          <TabsTrigger value="confidence">Confidence</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Posting cadence — day × hour</CardTitle>
              <CardDescription>UTC. Darker = more posts. Reveals a competitor's editorial rhythm.</CardDescription>
            </CardHeader>
            <CardContent>
              {freq ? <FrequencyHeatmap data={freq.heatmap} /> : <p className="text-sm text-muted-foreground">Loading…</p>}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Weekly post volume (last 26 weeks)</CardTitle>
              <CardDescription>Reconstructs how consistently they publish.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={freq?.weeks ?? []}>
                    <XAxis dataKey="week" tick={{ fontSize: 10 }} interval={3} />
                    <YAxis tick={{ fontSize: 10 }} />
                    <ReTooltip
                      contentStyle={{
                        backgroundColor: "var(--popover)",
                        borderColor: "var(--border)",
                        color: "var(--popover-foreground)",
                        fontSize: "12px",
                      }}
                    />
                    <Bar dataKey="count" fill="var(--primary)" radius={[3, 3, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Posts per platform</CardTitle>
              <CardDescription>Where this competitor concentrates output.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-2 sm:grid-cols-2 md:grid-cols-3">
                {(freq?.perPlatform ?? [])
                  .sort((a, b) => b.count - a.count)
                  .map((p) => (
                    <div key={p.platform} className="flex items-center justify-between rounded-md border px-3 py-2">
                      <span className="text-sm">{PLATFORM_LABEL[p.platform] ?? p.platform}</span>
                      <span className="text-sm font-semibold tabular-nums">{p.count}</span>
                    </div>
                  ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="creative">
          {dna ? (
            <CreativeDNA fingerprint={dna.fingerprint} gallery={dna.gallery} promoMix={dna.promoMix} />
          ) : (
            <p className="text-sm text-muted-foreground">Loading Creative DNA…</p>
          )}
        </TabsContent>

        <TabsContent value="campaigns">
          <CampaignTimeline campaigns={campaigns} />
        </TabsContent>

        <TabsContent value="top">
          <Card>
            <CardHeader>
              <CardTitle>Top-performing posts</CardTitle>
              <CardDescription>Ranked by engagement rate.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {topPosts.map((p) => (
                  <div key={p.id} className="overflow-hidden rounded-lg border">
                    {p.media_url && (
                      <img
                        src={p.media_url}
                        alt="Post preview"
                        className="h-40 w-full object-cover"
                        loading="lazy"
                      />
                    )}
                    <div className="space-y-2 p-3">
                      <div className="flex items-center justify-between">
                        <Badge variant="outline" className="text-[10px]">
                          {PLATFORM_LABEL[p.platform] ?? p.platform}
                        </Badge>
                        <span className="text-xs font-semibold text-primary">
                          {Number(p.engagement_rate).toFixed(2)}%
                        </span>
                      </div>
                      <p className="line-clamp-2 text-sm">{p.caption}</p>
                      <div className="flex gap-3 text-xs text-muted-foreground">
                        <span>♥ {p.likes.toLocaleString()}</span>
                        <span>💬 {p.comments.toLocaleString()}</span>
                        <span>↗ {p.shares.toLocaleString()}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="confidence">
          <Card>
            <CardHeader>
              <CardTitle>Data confidence per platform</CardTitle>
              <CardDescription>
                Real APIs constrain what we can see. We surface those limits instead of pretending they don't exist.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {detail.confidence.map((c) => {
                const lim = (c.limitations as { reason?: string } | null)?.reason;
                return (
                  <div key={c.platform} className="flex items-start justify-between gap-4 rounded-md border p-3">
                    <div>
                      <div className="mb-1 flex items-center gap-2">
                        <span className="font-medium">{PLATFORM_LABEL[c.platform] ?? c.platform}</span>
                        <ConfidenceBadge completeness={Number(c.completeness_pct)} />
                      </div>
                      {lim && <p className="text-xs text-muted-foreground">{lim}</p>}
                      {!lim && (
                        <p className="text-xs text-muted-foreground">
                          Tracking since {c.tracking_start_date}
                        </p>
                      )}
                    </div>
                  </div>
                );
              })}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

function StatCard({ label, value, loading }: { label: string; value: string; loading?: boolean }) {
  return (
    <Card>
      <CardContent className="pt-6">
        <div className="text-xs uppercase tracking-wide text-muted-foreground">{label}</div>
        <div className="mt-1 text-2xl font-semibold tabular-nums">
          {loading ? <span className="text-muted-foreground">…</span> : value}
        </div>
      </CardContent>
    </Card>
  );
}
