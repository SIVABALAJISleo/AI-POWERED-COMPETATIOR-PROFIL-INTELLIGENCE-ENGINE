import { createFileRoute, Link } from "@tanstack/react-router";
import { useSuspenseQuery, queryOptions } from "@tanstack/react-query";
import { listCompetitors } from "@/lib/analytics.functions";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { PLATFORM_LABEL } from "@/lib/platforms";
import { Building2 } from "lucide-react";

const q = queryOptions({ queryKey: ["competitors"], queryFn: () => listCompetitors() });

export const Route = createFileRoute("/_authenticated/competitors")({
  loader: ({ context }) => {
    context.queryClient.ensureQueryData(q);
  },
  component: CompetitorsList,
});

function CompetitorsList() {
  const { data } = useSuspenseQuery(q);
  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-3xl font-semibold tracking-tight">Competitors</h1>
        <p className="text-muted-foreground">Every competitor tracked across your workspaces.</p>
      </header>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {data.map((c) => (
          <Link key={c.id} to="/competitors/$id" params={{ id: c.id }} className="group">
            <Card className="h-full transition-colors group-hover:border-primary/50">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex size-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
                    <Building2 className="size-5" />
                  </div>
                  {c.is_demo && <Badge variant="secondary">DEMO</Badge>}
                </div>
                <CardTitle className="mt-3">{c.name}</CardTitle>
                <CardDescription>{c.industry ?? c.org_name}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="mb-3 flex flex-wrap gap-1">
                  {c.platforms.map((p) => (
                    <Badge key={p} variant="outline" className="text-[10px]">
                      {PLATFORM_LABEL[p] ?? p}
                    </Badge>
                  ))}
                </div>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <div className="text-muted-foreground">Posts</div>
                    <div className="text-lg font-semibold tabular-nums">{c.post_count}</div>
                  </div>
                  <div>
                    <div className="text-muted-foreground">Avg. engagement</div>
                    <div className="text-lg font-semibold tabular-nums">{c.avg_engagement.toFixed(2)}%</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
      {data.length === 0 && (
        <p className="rounded-md border border-dashed p-6 text-center text-sm text-muted-foreground">
          No competitors yet.
        </p>
      )}
    </div>
  );
}
