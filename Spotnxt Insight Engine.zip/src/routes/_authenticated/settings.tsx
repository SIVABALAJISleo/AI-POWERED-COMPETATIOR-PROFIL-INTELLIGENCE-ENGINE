import { createFileRoute } from "@tanstack/react-router";
import { useSuspenseQuery, queryOptions } from "@tanstack/react-query";
import { listOrgs } from "@/lib/analytics.functions";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const q = queryOptions({ queryKey: ["orgs"], queryFn: () => listOrgs() });

export const Route = createFileRoute("/_authenticated/settings")({
  loader: ({ context }) => {
    context.queryClient.ensureQueryData(q);
  },
  component: Settings,
});

function Settings() {
  const { data } = useSuspenseQuery(q);
  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-3xl font-semibold tracking-tight">Settings</h1>
        <p className="text-muted-foreground">Workspaces, roles, and integrations.</p>
      </header>
      <Card>
        <CardHeader>
          <CardTitle>Your workspaces</CardTitle>
          <CardDescription>Each workspace scopes its own competitors, roles, and reports.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-2">
          {data.map((m) => (
            <div key={m.org.id} className="flex items-center justify-between rounded-md border p-3">
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-medium">{m.org.name}</span>
                  {m.org.is_demo && <Badge variant="secondary" className="text-[10px]">DEMO</Badge>}
                </div>
                <p className="text-xs text-muted-foreground">/{m.org.slug}</p>
              </div>
              <Badge variant="outline" className="uppercase">{m.role}</Badge>
            </div>
          ))}
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle>Platform integrations</CardTitle>
          <CardDescription>
            Wire real ingestion by adding provider keys — YouTube, X, Meta Graph, TikTok. LinkedIn has no
            competitor-analysis API, so tracking there is manual-only.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">
            Coming in the next phase. Ping to enable a specific platform when you're ready.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
