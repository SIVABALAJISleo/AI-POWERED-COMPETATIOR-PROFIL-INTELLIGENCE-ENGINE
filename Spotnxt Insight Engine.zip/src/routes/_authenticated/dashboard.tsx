import { createFileRoute, Link } from "@tanstack/react-router";
import { useSuspenseQuery, queryOptions } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { listCompetitors, getRecommendations } from "@/lib/analytics.functions";
import { enqueueExport } from "@/lib/exports.functions";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { ArrowUpRight, Download, FileArchive, Lightbulb, Package, Sparkles, TrendingUp } from "lucide-react";
import { PLATFORM_LABEL } from "@/lib/platforms";
import { EvidenceModal, type EvidenceRef } from "@/components/spotnxt/evidence-modal";
import { AuditLogPanel } from "@/components/spotnxt/audit-log-panel";
import { QuarantinePanel } from "@/components/spotnxt/quarantine-panel";
import { ExportsPanel } from "@/components/spotnxt/exports-panel";
import { RetentionSettings } from "@/components/spotnxt/retention-settings";
import { TemplateBuilder } from "@/components/spotnxt/template-builder";
import { WebhooksPanel } from "@/components/spotnxt/webhooks-panel";
import { toast } from "sonner";


const competitorsQuery = queryOptions({
  queryKey: ["competitors"],
  queryFn: () => listCompetitors(),
});
const recsQuery = queryOptions({
  queryKey: ["recommendations"],
  queryFn: () => getRecommendations(),
});

export const Route = createFileRoute("/_authenticated/dashboard")({
  loader: ({ context }) => {
    context.queryClient.ensureQueryData(competitorsQuery);
    context.queryClient.ensureQueryData(recsQuery);
  },
  component: Dashboard,
});

function Dashboard() {
  const { data: comps } = useSuspenseQuery(competitorsQuery);
  const { data: recs } = useSuspenseQuery(recsQuery);
  const [openEvidence, setOpenEvidence] = useState<EvidenceRef>(null);
  const [enqueuingKind, setEnqueuingKind] = useState<string | null>(null);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const enqueueFn = useServerFn(enqueueExport);

  const enqueue = async (
    kind: "csv" | "pdf" | "bulk_pdf" | "zip",
    recommendationIds: string[],
    label: string,
  ) => {
    if (recommendationIds.length === 0) {
      toast.error("Select at least one recommendation");
      return;
    }
    const key = `${kind}:${recommendationIds.join(",")}`;
    setEnqueuingKind(key);
    try {
      await enqueueFn({ data: { kind, recommendationIds } });
      toast.success(`${label} queued — watch Export history below`);
      if (kind === "bulk_pdf" || kind === "zip") setSelected(new Set());
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Export failed");
    } finally {
      setEnqueuingKind(null);
    }
  };

  const isEnq = (kind: string, ids: string[]) =>
    enqueuingKind === `${kind}:${ids.join(",")}`;

  const sorted = [...comps].sort((a, b) => b.avg_engagement - a.avg_engagement);
  const topEng = sorted[0]?.avg_engagement ?? 1;

  return (
    <div className="space-y-8">
      <header className="space-y-1">
        <h1 className="text-3xl font-semibold tracking-tight">Competitor intelligence</h1>
        <p className="text-muted-foreground">
          Tracking {comps.length} competitor{comps.length === 1 ? "" : "s"} across{" "}
          {new Set(comps.flatMap((c) => c.platforms)).size} platforms.
        </p>
      </header>

      <section className="grid gap-4 md:grid-cols-3">
        <Kpi
          icon={<TrendingUp className="size-4" />}
          label="Avg. engagement rate"
          value={`${(sorted.reduce((s, c) => s + c.avg_engagement, 0) / Math.max(1, sorted.length)).toFixed(2)}%`}
          hint="Across all tracked posts"
        />
        <Kpi
          icon={<Sparkles className="size-4" />}
          label="Recommendations"
          value={`${recs.filter((r) => r.status === "open").length} open`}
          hint="Every rec is evidence-linked"
        />
        <Kpi
          icon={<Lightbulb className="size-4" />}
          label="Data confidence"
          value="Live"
          hint="Per-platform completeness surfaced everywhere"
        />
      </section>

      <section className="grid gap-6 lg:grid-cols-[1.6fr_1fr]">
        <Card>
          <CardHeader>
            <CardTitle>Competitor Strength Index</CardTitle>
            <CardDescription>Ranked by average engagement rate across tracked posts.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {sorted.map((c, i) => (
              <Link
                key={c.id}
                to="/competitors/$id"
                params={{ id: c.id }}
                className="group flex items-center gap-4 rounded-lg border p-3 transition-colors hover:bg-accent"
              >
                <div className="flex size-9 items-center justify-center rounded-full bg-primary/10 text-sm font-semibold text-primary">
                  {i + 1}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="truncate font-medium">{c.name}</span>
                    {c.is_demo && <Badge variant="secondary" className="text-[10px]">DEMO</Badge>}
                    {c.industry && <span className="text-xs text-muted-foreground">· {c.industry}</span>}
                  </div>
                  <div className="mt-1 flex items-center gap-3 text-xs text-muted-foreground">
                    <span className="tabular-nums">{c.post_count} posts</span>
                    <span>·</span>
                    <span>{c.platforms.length} platforms</span>
                    <span>·</span>
                    <span>{c.avg_engagement.toFixed(2)}% avg eng.</span>
                  </div>
                  <Progress value={(c.avg_engagement / Math.max(topEng, 0.01)) * 100} className="mt-2 h-1.5" />
                </div>
                <ArrowUpRight className="size-4 text-muted-foreground transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
              </Link>
            ))}
            {sorted.length === 0 && (
              <p className="rounded-md border border-dashed p-6 text-center text-sm text-muted-foreground">
                No competitors yet. Head to the Competitors page to add your first.
              </p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <CardTitle>Latest recommendations</CardTitle>
                <CardDescription>Evidence-linked, not black-box.</CardDescription>
              </div>
              <div className="flex gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => enqueue("bulk_pdf", [...selected], "Bundle PDF")}
                  disabled={isEnq("bulk_pdf", [...selected]) || selected.size === 0}
                  title="Bundle selected recommendations into one PDF"
                >
                  <Package className="size-3.5" />
                  Bundle PDF ({selected.size})
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => enqueue("zip", [...selected], "ZIP bundle")}
                  disabled={isEnq("zip", [...selected]) || selected.size === 0}
                  title="Bundle selected recommendations into a ZIP (CSV + PDF)"
                >
                  <FileArchive className="size-3.5" />
                  ZIP ({selected.size})
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            {recs.slice(0, 4).map((r) => (
              <div key={r.id} className="rounded-lg border p-3">
                <div className="mb-1 flex items-center justify-between gap-2">
                  <div className="flex min-w-0 items-center gap-2">
                    <input
                      type="checkbox"
                      checked={selected.has(r.id)}
                      onChange={(e) =>
                        setSelected((s) => {
                          const n = new Set(s);
                          if (e.target.checked) n.add(r.id);
                          else n.delete(r.id);
                          return n;
                        })
                      }
                      className="accent-primary"
                      aria-label="Include in bundle"
                    />
                    <PriorityDot p={r.priority} />
                    <span className="truncate font-medium text-sm">{r.title}</span>
                  </div>

                  <div className="flex items-center gap-1">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-6 px-2 text-xs"
                      onClick={() => enqueue("csv", [r.id], "CSV export")}
                      disabled={isEnq("csv", [r.id])}
                      title="Queue CSV evidence export"
                    >
                      <Download className="size-3" />
                      CSV
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-6 px-2 text-xs"
                      onClick={() => enqueue("pdf", [r.id], "PDF export")}
                      disabled={isEnq("pdf", [r.id])}
                      title="Queue PDF evidence export"
                    >
                      <Download className="size-3" />
                      PDF
                    </Button>
                  </div>
                </div>
                <p className="mb-2 text-xs text-muted-foreground line-clamp-2">{r.body}</p>
                <div className="flex flex-wrap gap-1">
                  {(r.evidence_links ?? []).slice(0, 4).map((e) => (
                    <button
                      key={e.id}
                      type="button"
                      onClick={() => setOpenEvidence(e as EvidenceRef)}
                      className="inline-flex items-center gap-1 rounded-md border px-1.5 py-0.5 text-[10px] font-normal hover:bg-accent"
                      title={e.snippet ?? ""}
                    >
                      {e.source_type === "post" ? "📄" : "📈"} {e.source_type}
                    </button>
                  ))}
                  {(r.evidence_links ?? []).length > 4 && (
                    <span className="text-[10px] text-muted-foreground">
                      +{(r.evidence_links ?? []).length - 4} more
                    </span>
                  )}
                </div>
              </div>
            ))}
            {recs.length === 0 && (
              <p className="text-sm text-muted-foreground">No recommendations yet.</p>
            )}
          </CardContent>
        </Card>
      </section>

      <section>
        <h2 className="mb-3 text-lg font-semibold">Platforms in play</h2>
        <div className="flex flex-wrap gap-2">
          {[...new Set(comps.flatMap((c) => c.platforms))].map((p) => (
            <Badge key={p} variant="secondary">{PLATFORM_LABEL[p] ?? p}</Badge>
          ))}
        </div>
      </section>

      {comps[0]?.org_id && <RetentionSettings orgId={comps[0].org_id} />}

      <ExportsPanel orgId={comps[0]?.org_id} />

      {comps[0]?.org_id && (
        <div className="grid gap-4 xl:grid-cols-2">
          <TemplateBuilder orgId={comps[0].org_id} />
          <WebhooksPanel orgId={comps[0].org_id} />
        </div>
      )}

      <QuarantinePanel />

      <AuditLogPanel title="Workspace activity" />



      <EvidenceModal evidence={openEvidence} onOpenChange={(o) => !o && setOpenEvidence(null)} />
    </div>
  );
}

function Kpi({ icon, label, value, hint }: { icon: React.ReactNode; label: string; value: string; hint: string }) {
  return (
    <Card>
      <CardContent className="pt-6">
        <div className="mb-2 flex items-center gap-2 text-xs uppercase tracking-wide text-muted-foreground">
          {icon}
          {label}
        </div>
        <div className="text-2xl font-semibold tabular-nums">{value}</div>
        <p className="mt-1 text-xs text-muted-foreground">{hint}</p>
      </CardContent>
    </Card>
  );
}

function PriorityDot({ p }: { p: string }) {
  const color = p === "high" ? "bg-rose-500" : p === "medium" ? "bg-amber-500" : "bg-emerald-500";
  return <span className={`size-2 rounded-full ${color}`} />;
}
