/**
 * Public download endpoint for shared exports.
 * Token-scoped: no user auth needed. Enforces expiration, revocation,
 * per-link total download quota, ad-hoc per-minute rate limit, and light
 * bot filtering. Audit-logs every download.
 *
 * Rate limiting note: backend has no standard rate-limit primitive so this
 * uses share_link_rate_hits, a bucketed counter table keyed on (token,
 * ip_hash, minute). It is best-effort and intended for share-link abuse,
 * not general API protection.
 */
import { createFileRoute } from "@tanstack/react-router";

// Hash IP with a short salt so we don't store raw IPs. Not cryptographic —
// only enough to bucket a client without keeping PII.
async function hashIp(ip: string): Promise<string> {
  const enc = new TextEncoder();
  const data = enc.encode(`${ip}::spotnxt-share`);
  const digest = await crypto.subtle.digest("SHA-256", data);
  return Array.from(new Uint8Array(digest))
    .slice(0, 16)
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

function ipFromHeaders(req: Request): string {
  const h = req.headers;
  const fwd = h.get("x-forwarded-for");
  if (fwd) return fwd.split(",")[0]!.trim();
  return h.get("x-real-ip") ?? h.get("cf-connecting-ip") ?? "unknown";
}

const BLOCKED_UA = /^(curl|wget|python-requests|libwww|scrapy|httpclient)\b/i;
const REQUIRED_ACCEPT = /^\s*(\*\/\*|application\/|text\/|image\/|multipart\/)/i;

export const Route = createFileRoute("/api/public/share/exports/$token")({
  server: {
    handlers: {
      GET: async ({ params, request }) => {
        const token = params.token;
        if (!token || token.length < 16) return new Response("Invalid link", { status: 400 });

        // Cheap bot filter: known scripting UAs and missing/invalid Accept
        // header. Anything looking like a real browser or a well-formed
        // programmatic client (JSON/octet-stream) passes through.
        const ua = request.headers.get("user-agent") ?? "";
        const accept = request.headers.get("accept") ?? "";
        if (!ua || BLOCKED_UA.test(ua)) {
          return new Response("Automated clients are not allowed on share links", { status: 403 });
        }
        if (accept && !REQUIRED_ACCEPT.test(accept)) {
          return new Response("Invalid Accept header", { status: 400 });
        }

        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

        const { data: link } = await supabaseAdmin
          .from("export_share_links")
          .select(
            "id, export_id, org_id, expires_at, revoked_at, max_downloads, download_count, download_limit_per_min",
          )
          .eq("token", token)
          .maybeSingle();
        if (!link) return new Response("Link not found", { status: 404 });
        if (link.revoked_at) return new Response("This share link has been revoked", { status: 410 });
        if (new Date(link.expires_at).getTime() < Date.now())
          return new Response("This share link has expired", { status: 410 });
        if (link.max_downloads && link.max_downloads > 0 && link.download_count >= link.max_downloads)
          return new Response("Download quota reached for this share link", { status: 429 });

        // Ad-hoc rate limit: per (token, ip, minute). Best-effort — the
        // check-then-increment race window is fine for public share abuse.
        const limitPerMin = link.download_limit_per_min ?? 30;
        if (limitPerMin > 0) {
          const ip = ipFromHeaders(request);
          const ipHash = await hashIp(ip);
          const windowStart = new Date(Math.floor(Date.now() / 60_000) * 60_000).toISOString();
          const { data: bucket } = await supabaseAdmin
            .from("share_link_rate_hits")
            .select("hits")
            .eq("token", token)
            .eq("ip_hash", ipHash)
            .eq("window_start", windowStart)
            .maybeSingle();
          const nextHits = (bucket?.hits ?? 0) + 1;
          if (nextHits > limitPerMin) {
            return new Response("Rate limit exceeded — try again in a minute", {
              status: 429,
              headers: { "retry-after": "60" },
            });
          }
          if (bucket) {
            await supabaseAdmin
              .from("share_link_rate_hits")
              .update({ hits: nextHits, updated_at: new Date().toISOString() })
              .eq("token", token)
              .eq("ip_hash", ipHash)
              .eq("window_start", windowStart);
          } else {
            await supabaseAdmin
              .from("share_link_rate_hits")
              .insert({ token, ip_hash: ipHash, window_start: windowStart, hits: 1 });
            // Opportunistic cleanup of buckets older than 1 hour.
            const stale = new Date(Date.now() - 60 * 60_000).toISOString();
            supabaseAdmin
              .from("share_link_rate_hits")
              .delete()
              .lt("window_start", stale)
              .then(() => {}, () => {});
          }
        }

        const { data: exp } = await supabaseAdmin
          .from("exports")
          .select("id, org_id, status, filename, mime_type, artifact, row_count, size_bytes, kind")
          .eq("id", link.export_id)
          .maybeSingle();
        if (!exp) return new Response("Export not found", { status: 404 });
        if (exp.status === "expired")
          return new Response("Artifact was purged by retention policy", { status: 410 });
        if (exp.status !== "done" || !exp.artifact)
          return new Response(`Export not ready (status: ${exp.status})`, { status: 409 });

        await supabaseAdmin
          .from("export_share_links")
          .update({ download_count: (link.download_count ?? 0) + 1 })
          .eq("id", link.id);

        try {
          await supabaseAdmin.from("audit_events").insert({
            org_id: link.org_id,
            actor_user_id: null,
            action: "export.share.download",
            target_type: "export",
            target_id: exp.id,
            metadata: {
              token_id: link.id,
              kind: exp.kind,
              filename: exp.filename,
              size_bytes: exp.size_bytes,
              rows: exp.row_count,
              ua: ua.slice(0, 200),
            },
          });
        } catch {
          /* audit best-effort */
        }

        const base64 = exp.artifact as string;
        const bin = atob(base64);
        const bytes = new Uint8Array(bin.length);
        for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);

        const filename = (exp.filename as string) || `export-${exp.id}.bin`;
        return new Response(bytes, {
          status: 200,
          headers: {
            "content-type": (exp.mime_type as string) || "application/octet-stream",
            "content-disposition": `attachment; filename="${filename.replace(/"/g, "")}"`,
            "cache-control": "no-store",
            "x-robots-tag": "noindex, nofollow",
          },
        });
      },
    },
  },
});
