/**
 * Cron endpoint for retrying failed webhook deliveries. Auth-free (via
 * /api/public/*) but caller must supply x-cron-secret matching CRON_SECRET
 * when set. Safe to poll every minute.
 */
import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/public/hooks/run-webhook-retries")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const secret = process.env.CRON_SECRET;
        if (secret) {
          const hdr = request.headers.get("x-cron-secret");
          if (hdr !== secret) return new Response("Unauthorized", { status: 401 });
        }
        const { processDueWebhookRetries } = await import("@/lib/exports.functions");
        const res = await processDueWebhookRetries(50);
        return Response.json({ ok: true, ...res });
      },
      POST: async ({ request }) => {
        const secret = process.env.CRON_SECRET;
        if (secret) {
          const hdr = request.headers.get("x-cron-secret");
          if (hdr !== secret) return new Response("Unauthorized", { status: 401 });
        }
        const { processDueWebhookRetries } = await import("@/lib/exports.functions");
        const res = await processDueWebhookRetries(50);
        return Response.json({ ok: true, ...res });
      },
    },
  },
});
