import { createFileRoute } from "@tanstack/react-router";
import { runOneJobInternal } from "@/lib/ingestion.functions";

/**
 * Public cron endpoint to drain the job queue. Processes up to N pending jobs per invocation.
 * Called by pg_cron or manually by the UI (via retryJob).
 * Guarded by anon apikey (bypass on /api/public); no PII returned.
 */
export const Route = createFileRoute("/api/public/hooks/run-jobs")({
  server: {
    handlers: {
      POST: async () => {
        const results: Array<Awaited<ReturnType<typeof runOneJobInternal>>> = [];
        for (let i = 0; i < 10; i++) {
          const r = await runOneJobInternal();
          if (r.processed === 0) break;
          results.push(r);
        }
        return Response.json({ ok: true, processed: results.length, results });
      },
    },
  },
});
